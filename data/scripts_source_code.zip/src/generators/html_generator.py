"""
HTML Generator for Nationwide ODCV Prospector Homepage
=======================================================
Generates the complete HTML page with:
- Portfolio Tab: Expandable portfolio cards ranked by OpEx savings
- Building Search Tab: Address search with map
- Vertical toggle filtering
- R-Zero Google authentication
- Auto-backup enabled via Claude Code hooks
"""

import json
import csv
import os
import re
import statistics
from datetime import datetime
import pytz
from html import escape
from src.data.helpers import (
    attr_escape, js_escape, safe_float, safe_int,
    format_currency, format_number, format_sqft, format_carbon,
    slugify, vertical_color, building_type_icon
)
def strip_acronym(name):
    """Remove trailing acronym in parentheses from org name for display."""
    # Match pattern like " (CBRE)" or " (GSA)" at end of string
    return re.sub(r'\s*\([A-Z]+\)\s*$', '', name)

def eui_rating(eui, benchmark):
    """Return full EUI display with number and rating, all in the rating color."""
    if eui is None or benchmark is None or benchmark == 0:
        return f'{eui:.0f}' if eui else ''
    ratio = eui / benchmark
    if ratio <= 1.0:
        return f'<span class="eui-good">{eui:.0f} (Good)</span>'
    elif ratio <= 1.2:
        return f'<span class="eui-ok">{eui:.0f} (OK)</span>'
    else:
        return f'<span class="eui-bad">{eui:.0f} (Bad)</span>'

def savings_color(amount):
    """Return green color based on savings amount - darker = more savings."""
    if amount is None:
        return '#22c55e'  # default medium green
    if amount >= 500000:
        return '#166534'  # dark green
    elif amount >= 100000:
        return '#22c55e'  # medium green
    else:
        return '#4ade80'  # light green


class NationwideHTMLGenerator:
    """Generates the Nationwide ODCV Prospector HTML page."""

    def __init__(self, config, data):
        """
        Initialize the generator.

        Args:
            config: dict with keys:
                - aws_bucket: S3 bucket URL
                - mapbox_token: Mapbox API token
                - google_api_key: Google API key
                - firebase_config: Firebase configuration
            data: dict from load_all_data() with keys:
                - portfolios: List of portfolio dicts
                - all_buildings: List of building dicts
                - stats: Statistics dict
                - image_map: Image lookup
                - coords_map: Coordinates lookup
        """
        self.config = config
        self.data = data
        self.stats = data['stats']
        self.portfolios = data['portfolios']
        self.all_buildings = data['all_buildings']
        self.logo_mappings = data.get('logo_mappings', {})

    def _get_display_name(self, b):
        """Get clean display name for building."""
        import math
        def safe_str(val):
            """Convert value to string, handling NaN/None."""
            if val is None:
                return ''
            if isinstance(val, float) and math.isnan(val):
                return ''
            return str(val).strip()

        tenant_sub_org = safe_str(b.get('org_tenant_subunit'))
        tenant = safe_str(b.get('org_tenant'))
        property_name = safe_str(b.get('id_property_name'))

        def clean(s):
            """Strip trailing punct, (R), (TM), and normalize."""
            s = re.sub(r'\s*\((R|TM)\)\s*', '', s)  # Remove trademark
            s = re.sub(r'[.,;:]+$', '', s)  # Remove trailing punct
            return s.strip()

        # Priority 1: tenant_sub_org
        if tenant_sub_org:
            cleaned_sub = clean(tenant_sub_org)
            # If too short (like "W"), use property_name if available
            if len(cleaned_sub) <= 2 and property_name:
                return clean(property_name)
            return cleaned_sub

        # Strip parens from tenant for base comparison
        # "University Of Chicago (UChicago)" → "University Of Chicago"
        base_tenant = re.sub(r'\s*\([^)]+\)\s*$', '', tenant).strip()

        # If tenant too short (<=2 chars), prefer property_name
        if len(base_tenant) <= 2 and property_name:
            return clean(property_name)

        # If both exist, avoid redundancy
        if base_tenant and property_name:
            base_lower = base_tenant.lower()
            p_lower = property_name.lower()

            # If identical or contained, use the more specific one
            if base_lower == p_lower:
                return clean(base_tenant)
            if base_lower in p_lower:
                return clean(property_name)

            # If any word (>3 chars) from tenant in property_name, use property_name
            words = [w for w in re.split(r'\W+', base_lower) if len(w) > 3]
            if any(w in p_lower for w in words):
                return clean(property_name)

            # Just show property name
            return clean(property_name)

        return clean(base_tenant or property_name)

    def _get_org_display_name(self, org_name):
        """Get display name for an organization, fallback to org_name."""
        if not org_name:
            return ''
        info = self.logo_mappings.get(org_name, {})
        return info.get('display_name', org_name)

    def generate(self):
        """Generate the complete HTML page and external data files."""
        # Generate data files (external JS)
        data_files = self._generate_data_files()

        # Generate HTML (without embedded data)
        html = '\n'.join([
            self._generate_head(),
            self._generate_body_start(),
            self._generate_header(),
            self._generate_portfolio_section(),
            self._generate_all_buildings_section(),
            self._generate_map_panel(),
            self._generate_scripts(),
            self._generate_body_end()
        ])

        return html, data_files

    def _generate_data_files(self):
        """Generate external JS data files."""
        # Portfolio buildings - for expanding portfolios
        portfolio_buildings = {
            i: [{
                'id': b.get('id_building', ''),
                'url': b.get('id_source_url', ''),
                'address': b.get('loc_address', ''),
                'city': b.get('loc_city', ''),
                'state': b.get('loc_state', ''),
                'property_name': self._get_display_name(b),
                'type': b.get('radio_type', ''),
                'bldg_type': b.get('bldg_type', ''),
                'vertical': b.get('bldg_vertical', ''),
                'sqft': safe_float(b.get('sqft')),
                'opex': safe_float(b.get('total_opex')),
                'valuation': safe_float(b.get('valuation_impact')),
                'carbon': safe_float(b.get('carbon_reduction')),
                'eui': safe_float(b.get('energy_site_eui')),
                'eui_benchmark': safe_float(b.get('energy_eui_benchmark')),
                'image': b.get('image', ''),
                'sub_org': b.get('org_tenant_subunit', ''),
                'hq_org': b.get('bldg_hq_org', ''),
            } for b in p['buildings']] for i, p in enumerate(self.portfolios)
        }

        # Map data - for map tab
        map_data = [{
            'id': b['id'],
            'lat': b['lat'],
            'lon': b['lon'],
            'address': b['loc_address'],
            'city': b['loc_city'],
            'state': b['loc_state'],
            'type': b.get('radio_type', ''),
            'vertical': b['bldg_vertical'],
            'opex': b['total_opex'],
            'image': b['image'],
            'owner': self._get_org_display_name(b.get('owner', '')),
            'tenant': self._get_org_display_name(b.get('org_tenant', '')),
            'manager': self._get_org_display_name(b.get('manager', '')),
            'property_name': self._get_display_name(b)
        } for b in self.all_buildings if b['lat'] and b['lon']]

        # Export data - all buildings with full details for CSV export and All Buildings tab
        export_data = [{
            'id': b.get('id', ''),
            'url': b.get('url', ''),
            'address': b.get('loc_address', ''),
            'city': b.get('loc_city', ''),
            'state': b.get('loc_state', ''),
            'property_name': self._get_display_name(b),
            'type': b.get('radio_type', ''),
            'owner': self._get_org_display_name(b.get('owner', '')),
            'tenant': self._get_org_display_name(b.get('org_tenant', '')),
            'manager': self._get_org_display_name(b.get('manager', '')),
            'sqft': safe_float(b.get('sqft')),
            'year_built': b.get('bldg_year_built', ''),
            'opex': safe_float(b.get('total_opex')),
            'valuation': safe_float(b.get('valuation_impact')),
            'carbon': safe_float(b.get('carbon')),
            'site_eui': safe_float(b.get('energy_site_eui')),
            'eui_benchmark': safe_float(b.get('energy_eui_benchmark')),
            'vertical': b.get('bldg_vertical', ''),
            'image': b.get('image', ''),
            'hq_org': b.get('bldg_hq_org', ''),
        } for b in sorted(self.all_buildings, key=lambda x: x.get('total_opex', 0) or 0, reverse=True)]

        # Portfolio card data - for rendering cards on scroll
        # Calculate total sqft for each portfolio
        portfolio_cards = []
        for i, p in enumerate(self.portfolios):
            total_sqft = sum(safe_float(b.get('sqft')) for b in p['buildings'])

            # Build display_name and parent_owned separately for two-line display
            display_name = p.get('display_name', p['org_name'])
            parent_owned = ''
            parent_tenant = p.get('parent_tenant', '')
            if parent_tenant:
                # Get parent's display_name for cleaner output
                parent_display = parent_tenant
                for port in self.portfolios:
                    if port['org_name'] == parent_tenant:
                        parent_display = port.get('display_name', parent_tenant)
                        break
                parent_owned = f"{parent_display} Owned"

            portfolio_cards.append({
                'idx': i,
                'org_name': p['org_name'],
                'display_name': display_name,
                'parent_owned': parent_owned,
                'logo_file': p.get('logo_file', ''),
                'aws_logo_url': p.get('aws_logo_url', ''),
                'org_url': p.get('org_url', ''),
                'building_count': p['building_count'],
                'total_sqft': total_sqft,
                'median_eui': p.get('median_eui', 0) or 0,
                'median_eui_benchmark': p.get('median_eui_benchmark', 0) or 0,
                'total_valuation': p['total_valuation_impact'],
                'total_carbon': p['total_carbon_reduction'],
                'total_opex': p['total_opex_avoidance'],
                'classification': p.get('classification', ''),
                'verticals': list(p.get('verticals', [])),
                'tenants': p.get('tenants', []),
                'tenant_sub_orgs': p.get('tenant_sub_orgs', []),
                'owners': p.get('owners', []),
                'managers': p.get('managers', []),
                'search_aliases': p.get('search_aliases', []),
            })

        # Filter data - aggregated by type|vertical per portfolio (tiny ~75KB)
        # IMPORTANT: Only include buildings with BOTH type AND vertical to ensure accurate filter counts
        filter_data = {}
        for i, p in enumerate(self.portfolios):
            agg = {}
            for b in p['buildings']:
                t = (b.get('radio_type', '') or '').strip()
                v = (b.get('bldg_vertical', '') or '').strip()
                # Skip buildings without complete type/vertical data
                # This ensures filter counts match the actual visible/filterable buildings
                if not t or not v:
                    continue
                key = f'{t}|{v}'
                if key not in agg:
                    # Use objects instead of arrays for clarity and maintainability
                    agg[key] = {'count': 0, 'opex': 0.0, 'valuation': 0.0, 'carbon': 0.0, 'sqft': 0.0}
                agg[key]['count'] += 1
                agg[key]['opex'] += safe_float(b.get('total_opex'))
                agg[key]['valuation'] += safe_float(b.get('valuation_impact'))
                agg[key]['carbon'] += safe_float(b.get('carbon_reduction'))
                agg[key]['sqft'] += safe_float(b.get('sqft'))
            filter_data[i] = agg

        # Compute global totals by type|vertical for header tooltips (instant lookup)
        # This eliminates the need for EXPORT_DATA to be loaded for header tooltip updates
        header_totals = {}
        for b in self.all_buildings:
            t = (b.get('radio_type', '') or '').strip()
            v = (b.get('bldg_vertical', '') or '').strip()
            # Skip buildings without vertical (type is optional for "all" key)
            if not v:
                continue

            # Generate all relevant keys for this building
            keys = [f"|all", f"|{v}"]  # No type filter, and vertical-only filter
            if t:
                keys.extend([f"{t}|all", f"{t}|{v}"])  # Type-only and type+vertical

            for key in keys:
                if key not in header_totals:
                    header_totals[key] = {'count': 0, 'sqft': 0.0, 'opex': 0.0, 'valuation': 0.0, 'carbon': 0.0}
                header_totals[key]['count'] += 1
                header_totals[key]['sqft'] += safe_float(b.get('sqft'))
                header_totals[key]['opex'] += safe_float(b.get('total_opex'))
                header_totals[key]['valuation'] += safe_float(b.get('valuation_impact'))
                header_totals[key]['carbon'] += safe_float(b.get('carbon'))

        data_files = {
            'filter_data.js': f'const FILTER_DATA = {json.dumps(filter_data)};\nconst HEADER_TOTALS = {json.dumps(header_totals)};',
            'map_data.js': f'MAP_DATA = {json.dumps(map_data)};',
            'portfolio_cards.js': f'const PORTFOLIO_CARDS = {json.dumps(portfolio_cards)};',
            'export_data.js': f'EXPORT_DATA = {json.dumps(export_data)};',
        }

        # Individual portfolio building files - loaded on demand
        for idx, buildings in portfolio_buildings.items():
            data_files[f'portfolios/p_{idx}.js'] = f'PORTFOLIO_BUILDINGS[{idx}] = {json.dumps(buildings)};'

        return data_files

    # =========================================================================
    # HEAD SECTION
    # =========================================================================

    def _generate_head(self):
        """Generate HTML head with styles and dependencies."""
        timestamp = datetime.now(pytz.timezone('America/New_York')).strftime('%Y-%m-%d %H:%M:%S EST')

        return f'''<!DOCTYPE html>
<!-- Nationwide ODCV Prospector - Generated: {timestamp} -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nationwide ODCV Prospector | R-Zero</title>
    <link rel="icon" type="image/png" href="https://rzero.com/wp-content/themes/rzero/build/images/favicons/favicon.png">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Mapbox -->
    <link href="https://api.mapbox.com/mapbox-gl-js/v3.3.0/mapbox-gl.css" rel="stylesheet">
    <script src="https://api.mapbox.com/mapbox-gl-js/v3.3.0/mapbox-gl.js"></script>

    <script>
function initMap() {{
    window.__googleMapsReady = true;
    // Retry until setupAddressSearch is available (it's defined in body)
    function trySetup() {{
        if (typeof setupAddressSearch === 'function') {{
            setupAddressSearch();
        }} else {{
            setTimeout(trySetup, 50);
        }}
    }}
    trySetup();
}}
</script>
    <script src="https://maps.googleapis.com/maps/api/js?key={self.config['google_api_key']}&libraries=places&callback=initMap" async defer></script>

    <!-- Google Sign-In -->
    <script src="https://accounts.google.com/gsi/client" async defer></script>

    <!-- Firebase (App + Auth + Firestore, compat) -->
    <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js"></script>
    <script>
      // Firebase web app config — prospector-leaderl-board
      window.firebaseConfig = {{
        apiKey: "AIzaSyAsxPRzyj7z6Nk3QPhOBK5CfyblY2LqAjk",
        authDomain: "prospector-leaderl-board.firebaseapp.com",
        projectId: "prospector-leaderl-board",
        storageBucket: "prospector-leaderl-board.firebasestorage.app",
        messagingSenderId: "70489892630",
        appId: "1:70489892630:web:51052e8b0b5da2e6779237"
      }};

      /* --- Firebase config sanity guard --------------------------------------- */
      (function enforceFirebaseConfig() {{
        try {{
          const EXPECTED_PROJECT_ID   = "prospector-leaderl-board";
          const EXPECTED_AUTH_DOMAIN  = "prospector-leaderl-board.firebaseapp.com";
          const ALT_AUTH_DOMAIN       = "prospector-leaderl-board.web.app";
          const GH_PAGES_HOST         = "fmillerrzero.github.io";

          const c = window.firebaseConfig || {{}};
          const required = ["apiKey","projectId","authDomain"];
          const missing = required.filter(k => !c[k] || String(c[k]).trim()==="");
          if (missing.length) {{
            throw new Error("firebaseConfig missing keys: " + missing.join(", "));
          }}

          const authDomainOk = (
            c.authDomain === EXPECTED_AUTH_DOMAIN ||
            c.authDomain === ALT_AUTH_DOMAIN
          );
          if (!authDomainOk) {{
            console.error("[FirebaseConfig] authDomain mismatch:",
              "got", c.authDomain, "expected", EXPECTED_AUTH_DOMAIN, "or", ALT_AUTH_DOMAIN);
            throw new Error("Wrong firebaseConfig.authDomain (points at a different project).");
          }}

          if (c.projectId !== EXPECTED_PROJECT_ID) {{
            console.error("[FirebaseConfig] projectId mismatch:",
              "got", c.projectId, "expected", EXPECTED_PROJECT_ID);
            throw new Error("Wrong firebaseConfig.projectId (points at a different project).");
          }}

          try {{
            const host = location.host;
            if (!(host.includes(GH_PAGES_HOST) || host.includes("localhost") || host === "127.0.0.1" || host.includes(":8"))) {{
              console.warn("[FirebaseConfig] Page is served from unexpected host:", host);
            }}
          }} catch (e) {{ if(window.DIAG) DIAG.log('warn', 'Firebase host check failed', e); }}

          window.firebaseConfig = Object.freeze({{...c}});
          window.firebaseConfigValidated = true;}} catch (e) {{
          window.firebaseConfigValidated = false;
          const msg = "🚫 Firebase config error: " + e.message +
                      " — Fix window.firebaseConfig to the correct project.";
          console.error(msg);
          throw e;
        }}
      }})();

      function initFirebase() {{
        if (!window.firebaseAppInitialized && typeof firebase !== 'undefined') {{
          firebase.initializeApp(window.firebaseConfig);
          window.db = firebase.firestore();
          window.firebaseAppInitialized = true;
        }}
      }}
      initFirebase();
    </script>

    <script>
      // Auth sanity hook — safe no-op UI, console only
      if (typeof firebase !== 'undefined' && firebase.auth) {{
        firebase.auth().onAuthStateChanged((u) => {{
          if (u) {{}} else {{}}
        }});
      }}
    </script>

    <script>
      // Track HOMEPAGE visits
      setTimeout(function() {{
        if (window.db && window.location.protocol !== 'file:') {{
          // Track homepage visit
          const homeDoc = window.db.collection('visits').doc('NATIONWIDE_HOMEPAGE');
          homeDoc.get().then(doc => {{
            if (doc.exists) {{
              homeDoc.update({{
                count: firebase.firestore.FieldValue.increment(1),
                lastVisit: firebase.firestore.FieldValue.serverTimestamp()
              }});
            }} else {{
              homeDoc.set({{
                bbl: 'NATIONWIDE_HOMEPAGE',
                name: 'Nationwide Homepage',
                count: 1,
                lastVisit: firebase.firestore.FieldValue.serverTimestamp()
              }});
            }}
          }}).catch(err => {{ if(window.DIAG) DIAG.log('error', 'Firebase visit tracking failed', err); }});

          // Auth-based user tracking (names leaderboard)
          (function(){{
            if (typeof firebase === 'undefined' || !firebase.auth || !firebase.firestore) return;
            const db = window.db || firebase.firestore();

            firebase.auth().onAuthStateChanged(async (u)=>{{
              if (!u) return; // only track signed-in users
              const parts = (u.displayName||"").trim().split(/\s+/);
              const first = parts.length ? parts.slice(0,-1).join(" ") || parts[0] : "";
              const last  = parts.length > 1 ? parts.slice(-1).join(" ") : "";

              const id = u.uid;
              const ref = db.collection('nationwideUserActivity').doc(id);

              await ref.set({{
                uid: u.uid,
                email: u.email || null,
                displayName: u.displayName || null,
                firstName: first || null,
                lastName: last || null,
                lastActive: firebase.firestore.FieldValue.serverTimestamp()
              }}, {{ merge: true }});

              // increment homepage visits
              await ref.set({{
                visitCount: firebase.firestore.FieldValue.increment(1),
                homepageVisits: firebase.firestore.FieldValue.increment(1)
              }}, {{ merge: true }});
            }});
          }})()
        }}
      }}, 1000);
    </script>

    {self._generate_styles()}
</head>'''

    def _generate_styles(self):
        """Generate CSS styles."""
        return '''<style>
/* Make Google Places dropdown appear correctly */
.pac-container {
    z-index: 10000 !important;
}

:root {
    --primary: #0066cc;
    --primary-dark: #0052a3;
    --mid-blue: #1b95ff;
    --light-blue: #f0f7fa;
    --success: #16a34a;
    --danger: #dc2626;
    --gray-50: #f9fafb;
    --gray-100: #f3f4f6;
    --gray-200: #e5e7eb;
    --gray-300: #d1d5db;
    --gray-400: #9ca3af;
    --gray-500: #6b7280;
    --gray-600: #4b5563;
    --gray-700: #374151;
    --gray-800: #1f2937;
    --gray-900: #111827;
    --rzero-blue: #0066cc;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: var(--gray-50);
    color: var(--gray-900);
    line-height: 1.5;
    overflow-x: hidden;
}

/* VERTICAL FILTER BAR - horizontal bar below header */
.vertical-filter-bar {
    position: fixed;
    top: 155px;
    left: 0;
    right: 0;
    background: white;
    border-bottom: 1px solid #ccc;
    padding: 15px 32px;
    z-index: 1003;
}

/* City filter bar - identical to vertical filter bar, for Cities tab */
.city-filter-bar {
    position: fixed;
    top: 155px;
    left: 0;
    right: 0;
    background: white;
    border-bottom: 1px solid #ccc;
    padding: 15px 32px;
    z-index: 1003;
    display: none;
}

body.all-buildings-active .city-filter-bar {
    display: block;
}

.city-filter-bar .vertical-filter-inner {
    justify-content: center;
    gap: 32px;
}

.city-btn {
    min-width: 170px;
}

.city-btn .btn-count {
    display: none;
}

.city-btn:hover .btn-count {
    display: inline;
}

.vertical-filter-inner {
    max-width: 1272px;
    margin: 0 auto;
    display: flex;
    gap: 24px;
    align-items: center;
    justify-content: center;
    padding: 0;
}

.vertical-btn {
    padding: 10px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    border: none;
    color: white;
    min-width: 140px;
    text-align: center;
}

.vertical-btn.selected, .building-type-btn.selected {
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}
.building-type-btn.selected {
    outline: 3px solid #FFD700;
    outline-offset: 2px;
    box-shadow: 0 0 12px rgba(255, 215, 0, 0.5);
}
.vertical-btn .btn-x {
    display: none;
    margin-left: 6px;
    font-weight: bold;
    opacity: 0.7;
}
.vertical-btn .btn-x:hover {
    opacity: 1;
}
.vertical-btn.selected .btn-x {
    display: inline;
}

/* Button icon and label for responsive hiding */
.btn-icon {
    margin-right: 6px;
}
.btn-label {
    /* Will be hidden on mobile */
}

/* Building type filter chip */
.building-type-chip {
    display: none;
    background: #e5e7eb;
    color: #374151;
    padding: 6px 12px 6px 8px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 500;
    align-items: center;
    gap: 6px;
    margin-left: 12px;
}
.building-type-chip.visible {
    display: flex;
}
.building-type-chip .chip-x {
    cursor: pointer;
    font-size: 14px;
    font-weight: bold;
    color: #6b7280;
    line-height: 1;
}
.building-type-chip .chip-x:hover {
    color: #111827;
}

/* VERTICAL DROPDOWN FILTERS */
.vertical-buttons-group {
    display: flex;
    gap: 12px;
    align-items: center;
}

.vertical-btn-wrapper {
    position: relative;
    display: inline-flex;
    border-radius: 6px;
    overflow: visible;
}
.vertical-btn-wrapper .vertical-btn {
    border-radius: 6px 0 0 6px;
    padding-right: 12px;
}
.vertical-dropdown-arrow {
    background: rgba(255,255,255,0.2);
    border: none;
    border-left: 1px solid rgba(255,255,255,0.3);
    padding: 0 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    border-radius: 0 6px 6px 0;
    color: white;
    transition: background 0.2s;
}
.vertical-dropdown-arrow:hover {
    background: rgba(255,255,255,0.35);
}
.vertical-dropdown-arrow svg {
    transition: transform 0.2s;
}
.vertical-dropdown-arrow.open svg {
    transform: rotate(180deg);
}
.vertical-dropdown {
    position: absolute;
    top: calc(100% + 6px);
    left: 0;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    min-width: 220px;
    z-index: 2000;
    display: none;
    padding: 8px 0;
    max-height: 320px;
    overflow-y: auto;
}
.vertical-dropdown.show {
    display: block;
}
.vertical-dropdown label {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-700);
    transition: background 0.15s;
}
.vertical-dropdown label:hover {
    background: var(--gray-50);
}
.vertical-dropdown label input[type="radio"] {
    width: 16px;
    height: 16px;
    accent-color: var(--primary);
    cursor: pointer;
}
.vertical-dropdown .dropdown-count {
    margin-left: auto;
    color: var(--gray-400);
    font-size: 12px;
}

/* Leaderboard list styling */
.leaderboard-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.leaderboard-item {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #e0e0e0;
    font-size: 13px;
}

.leaderboard-item:last-child {
    border-bottom: none;
}

.leaderboard-name {
    font-weight: 500;
    color: #333;
}

.leaderboard-count {
    color: #059669;
    font-weight: 600;
}

.sidebar-label {
    font-size: 12px;
    font-weight: 600;
    color: #555;
    margin-bottom: 12px;
    text-transform: uppercase;
}

/* Building type filter buttons - vertical list */
.building-type-filters {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.building-type-btn {
    padding: 10px 14px;
    border-radius: 6px;
    font-size: 13px;
    cursor: pointer;
    border: none;
    color: white;
    display: flex;
    justify-content: space-between;
}

.building-type-btn.hidden {
    display: none;
}

/* Header */
.header {
    background: url('https://rzero.com/wp-content/uploads/2025/02/bg-cta-bottom.jpg') center/cover;
    color: white;
    padding: 24px 32px;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1001;
    max-height: 85px;
    overflow: visible;
}

.header-content {
    display: flex;
    align-items: center;
    width: 100%;
}

.header h1 {
    font-size: 20px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 12px;
    white-space: nowrap;
}

.header h1 img {
    height: 36px;
}

.header-subtitle {
    opacity: 0.9;
    font-size: 14px;
    margin-top: 4px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 14px;
}

.user-info img {
    width: 32px;
    height: 32px;
    border-radius: 50%;
}

.logout-btn {
    background: rgba(255,255,255,0.2);
    border: none;
    color: white;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
}

.logout-btn:hover {
    background: rgba(255,255,255,0.3);
}

/* Stats Cards */
.stats-section {
    background: white;
    border-bottom: 1px solid var(--gray-200);
    padding: 20px 32px;
}

.stats-grid {
    max-width: 1400px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 16px;
}

.stat-card {
    background: var(--gray-50);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
}

.stat-value {
    font-size: 28px;
    font-weight: 700;
    color: var(--rzero-blue);
}

.stat-label {
    font-size: 12px;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 4px;
}

/* Main Tabs */
.main-tabs {
    background: white;
    padding: 12px 32px;
}

.tabs-container {
    max-width: 1400px;
    margin: 0 auto;
    display: flex;
    gap: 0;
}

.main-tab {
    padding: 14px 28px;
    border: 2px solid transparent;
    background: none;
    font-size: 16px;
    font-weight: 700;
    color: var(--gray-500);
    cursor: pointer;
    transition: color 0.2s, border-color 0.2s, background 0.2s;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    position: relative;
    z-index: 1;
}

.main-tab:hover {
    color: var(--gray-700);
    background: var(--gray-50);
}

.main-tab.active {
    color: var(--rzero-blue);
    border: none;
    border-bottom: 3px solid var(--rzero-blue);
    border-radius: 0;
    background: transparent;
}

/* Tab icon and label for responsive */
.tab-icon {
    vertical-align: -3px;
    margin-right: 6px;
    flex-shrink: 0;
}
.tab-label {
    /* Will be hidden on mobile */
}

/* Tab Content */
.tab-content {
    display: none;
    max-width: 1400px;
    margin: 0 auto;
    padding: 24px 32px;
}

.tab-content.active {
    display: block;
}

/* Hide filters when All Buildings tab is active */
body.all-buildings-active .vertical-filter-bar {
    display: none !important;
}

body.all-buildings-active .portfolio-section {
    display: none !important;
}

body.all-buildings-active .main-tabs {
    left: 0 !important;
}

/* Hide everything except methodology iframe when Methodology tab is active */
body.methodology-active .vertical-filter-bar,
body.methodology-active .city-filter-bar,
body.methodology-active .portfolio-section {
    display: none !important;
}

body.methodology-active .main-tabs {
    left: 0 !important;
}

/* All Buildings Tab Styles */
.all-buildings-section {
    padding: 185px 32px 32px 32px;
    max-width: 1400px;
    margin: 0 auto;
    background: var(--gray-50);
}

.all-buildings-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 28px;
}

.ab-stat-card {
    background: white;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid var(--gray-200);
    border-left: 4px solid var(--rzero-blue);
    transition: transform 0.2s, box-shadow 0.2s;
}

.ab-stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.ab-stat-value {
    font-size: 32px;
    font-weight: 700;
    color: var(--rzero-blue);
    margin-bottom: 6px;
}

.ab-stat-value.green { color: var(--success); }

.ab-stat-label {
    font-size: 13px;
    color: var(--gray-500);
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.top-cities-section {
    margin-bottom: 24px;
}

.top-cities-header {
    font-size: 14px;
    font-weight: 600;
    color: var(--gray-700);
    margin-bottom: 12px;
}

.top-cities-grid {
    display: flex;
    gap: 12px;
    overflow-x: auto;
    padding-bottom: 8px;
}

.city-tile {
    flex: 0 0 180px;
    padding: 16px;
    background: white;
    border: 2px solid var(--gray-200);
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.2s;
}

.city-tile:hover {
    border-color: var(--rzero-blue);
    box-shadow: 0 4px 12px rgba(0, 102, 204, 0.15);
    transform: translateY(-2px);
}

.city-tile.selected {
    border-color: var(--rzero-blue);
    background: rgba(0, 102, 204, 0.08);
    box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.2);
}

.city-name {
    font-size: 16px;
    font-weight: 600;
    color: var(--gray-900);
    margin-bottom: 6px;
}

.city-stats {
    font-size: 12px;
    color: var(--gray-500);
}

.city-opex {
    font-size: 15px;
    font-weight: 700;
    color: var(--success);
    margin-top: 6px;
}

.ab-filter-bar {
    display: flex;
    gap: 12px;
    align-items: center;
    flex-wrap: wrap;
    padding: 16px 20px;
    background: var(--gray-50);
    border-radius: 12px;
    margin-bottom: 20px;
    border: 1px solid var(--gray-200);
}

.ab-filter-bar select {
    padding: 10px 14px;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    background: white;
    cursor: pointer;
    min-width: 150px;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.ab-filter-bar select:focus {
    border-color: var(--rzero-blue);
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.15);
}

.ab-filter-bar input[type="text"] {
    padding: 10px 14px;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    min-width: 220px;
    background: white;
    transition: border-color 0.2s, box-shadow 0.2s;
}

.ab-filter-bar input[type="text"]:focus {
    border-color: var(--rzero-blue);
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.15);
}

.ab-clear-btn {
    padding: 10px 18px;
    background: white;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    color: var(--gray-600);
    transition: all 0.2s;
}

.ab-clear-btn:hover {
    background: var(--gray-100);
    border-color: var(--gray-400);
}

/* City Filter Section */
.city-filter-section {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 16px;
}

.city-filter-label {
    font-size: 12px;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 10px;
}

.city-filter-cards {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: center;
}

.city-filter-card {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: white;
    padding: 6px 12px;
    border-radius: 6px;
    border: 1px solid #cbd5e1;
    cursor: pointer;
    transition: all 0.15s;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.city-filter-card:hover {
    background: #f1f5f9;
    border-color: #3b82f6;
    box-shadow: 0 2px 4px rgba(59,130,246,0.15);
}

.city-filter-card.selected {
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.city-filter-card strong {
    font-size: 13px;
    font-weight: 600;
    color: #1e293b;
}

.city-filter-card .city-count {
    font-size: 11px;
    color: #64748b;
    background: #f1f5f9;
    padding: 2px 6px;
    border-radius: 4px;
}

.city-filter-card.selected .city-count {
    background: #bfdbfe;
    color: #1e40af;
}

.city-filter-card .city-opex {
    font-size: 12px;
    color: #059669;
    font-weight: 600;
}


/* Cities tab - blue header bar like Portfolios tab */
.cities-header {
    display: grid;
    grid-template-columns: 60px 24px 1.3fr 110px 70px 55px 1.2fr 1.2fr 85px;
    gap: 12px;
    padding: 8px 16px 8px 0;
    background: var(--rzero-blue);
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    font-size: 12px;
    font-weight: 600;
    color: white;
    text-transform: uppercase;
    align-items: center;
    position: sticky;
    top: 222px;
    z-index: 1002;
}
.cities-header span { cursor: pointer; white-space: nowrap; }
.cities-header span:hover { color: rgba(255,255,255,0.8); }

.cities-row {
    display: grid;
    grid-template-columns: 60px 24px 1.3fr 110px 70px 55px 1.2fr 1.2fr 85px;
    gap: 12px;
    padding: 8px 16px;
    border-bottom: 1px solid #e5e7eb;
    cursor: pointer;
    align-items: center;
    background: white;
    font-size: 12px;
}
.cities-row:hover { background: #f8fafc; }
.cities-row .cell {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
}
.cities-row .cell:has(.hq-badge) {
    white-space: normal;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.cities-row .ext-link-cell {
    margin-left: -4px;
}
.cities-row .addr { display: flex; flex-direction: column; overflow: hidden; min-width: 0; margin-left: 16px; }
.cities-row .addr-main { font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.cities-row .addr-sub { font-size: 11px; color: #6b7280; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.cities-container {
    background: white;
    border-radius: 12px 12px 0 0;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    overflow: hidden;
    margin-top: 8px;
}

.cities-container.fully-loaded {
    border-radius: 12px;
}

.ab-table-wrapper {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    overflow: visible;
    max-height: calc(100vh - 200px);
    overflow-y: auto;
}

.ab-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.ab-table thead {
    background: var(--rzero-blue);
    position: sticky;
    top: 0;
    z-index: 10;
}

.ab-table th {
    padding: 14px 12px;
    text-align: left;
    text-transform: none;
    font-weight: 600;
    font-size: 12px;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    cursor: pointer;
    transition: background 0.15s;
    white-space: nowrap;
}

.ab-table th:hover {
    background: #0052a3;
}

.ab-table th::after {
    content: " ⇵";
    opacity: 0.5;
    font-size: 10px;
}

.ab-table th:first-child::after {
    content: "";
}

.ab-table th.sort-asc::after {
    content: " ▲";
    opacity: 1;
}

.ab-table th.sort-desc::after {
    content: " ▼";
    opacity: 1;
}

.ab-table td {
    padding: 12px;
    border-bottom: 1px solid var(--gray-100);
    vertical-align: middle;
}

.ab-table tbody tr {
    cursor: pointer;
    transition: background 0.15s;
}

.ab-table tbody tr:hover {
    background: rgba(0, 102, 204, 0.04);
}

.ab-table .building-thumb {
    width: 70px;
    height: 52px;
    object-fit: cover;
    border-radius: 6px;
}

.ab-table .building-thumb-placeholder {
    width: 70px;
    height: 52px;
    background: var(--gray-100);
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: var(--gray-400);
}

.ab-loading-trigger {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--gray-400);
    font-size: 14px;
    background: linear-gradient(to bottom, white, #f9fafb);
}

.ab-loading-trigger::before {
    content: '';
    width: 20px;
    height: 20px;
    border: 2px solid var(--gray-300);
    border-top-color: var(--rzero-blue);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-right: 10px;
}

.ab-loading-trigger::after {
    content: 'Loading more buildings...';
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.ab-empty-state {
    padding: 60px 20px;
    text-align: center;
    color: var(--gray-500);
}

.ab-empty-state h3 {
    margin: 0 0 8px 0;
    color: var(--gray-700);
    font-size: 18px;
}

.ab-empty-state p {
    margin: 0;
    font-size: 14px;
}

/* Vertical Toggle */
.vertical-toggle {
    display: flex;
    gap: 8px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}

/* Filter Bar */
.filter-bar {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 12px 0;
    margin-bottom: 16px;
    border-bottom: 1px solid var(--gray-200);
    flex-wrap: wrap;
}

.filter-group {
    display: flex;
    align-items: center;
    gap: 8px;
}

.filter-label {
    font-size: 13px;
    color: var(--gray-600);
    font-weight: 500;
}

.filter-select {
    padding: 8px 12px;
    border: 1px solid var(--gray-300);
    border-radius: 6px;
    font-size: 13px;
    background: white;
    cursor: pointer;
    min-width: 140px;
}

.filter-select:focus {
    border-color: var(--primary);
    outline: none;
}

.export-btn {
    padding: 10px 16px;
    background: var(--gray-700);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
}

.export-btn:hover {
    background: var(--gray-800);
}

.export-dropdown {
    position: relative;
    display: inline-block;
    z-index: 1002;
}

.export-menu {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    margin-top: 4px;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    min-width: 200px;
    z-index: 99999;
}

.export-menu.show {
    display: block;
}

.export-menu button {
    display: block;
    width: 100%;
    padding: 12px 16px;
    background: none;
    border: none;
    text-align: left;
    text-transform: none;
    font-size: 14px;
    color: var(--gray-700);
    cursor: pointer;
    transition: background 0.15s;
}

.export-menu button:hover {
    background: var(--gray-100);
}

.export-menu button:first-child {
    border-radius: 8px 8px 0 0;
}

.export-menu button:last-child {
    border-radius: 0 0 8px 8px;
}

/* Leaderboard dropdown - similar to export dropdown */
.leaderboard-dropdown {
    position: relative;
    display: inline-block;
    z-index: 1002;
}

.leaderboard-menu {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    margin-top: 4px;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    width: 280px;
    max-height: 400px;
    overflow-y: auto;
    z-index: 99999;
    padding: 12px;
}

.leaderboard-menu.show {
    display: block;
}

.leaderboard-menu .lb-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--gray-200);
}

.leaderboard-menu .lb-header span {
    font-weight: 600;
    font-size: 14px;
    color: var(--gray-700);
}

.leaderboard-menu .lb-controls {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-bottom: 8px;
}

.leaderboard-menu .lb-refresh {
    padding: 4px 10px;
    border: 1px solid #ddd;
    border-radius: 6px;
    background: white;
    cursor: pointer;
    font-size: 11px;
}

.leaderboard-menu .lb-refresh:hover {
    background: var(--gray-100);
}

.leaderboard-menu .lb-updated {
    font-size: 10px;
    color: #888;
}

.leaderboard-menu .leaderboard-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.leaderboard-menu .leaderboard-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid var(--gray-100);
    font-size: 13px;
}

.leaderboard-menu .leaderboard-item:last-child {
    border-bottom: none;
}

.leaderboard-avatar {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    object-fit: cover;
    flex-shrink: 0;
}

.clear-btn {
    padding: 8px 12px;
    background: transparent;
    color: var(--gray-600);
    border: 1px solid var(--gray-300);
    border-radius: 6px;
    font-size: 13px;
    cursor: pointer;
}

.clear-btn:hover {
    border-color: var(--gray-400);
    color: var(--gray-700);
}

.clear-btn.hidden {
    display: none;
}

.filter-results {
    font-size: 13px;
    color: var(--gray-600);
    margin-left: auto;
}

.filter-results strong {
    color: var(--gray-800);
}

.filter-input {
    padding: 8px 12px;
    border: 1px solid var(--gray-300);
    border-radius: 6px;
    font-size: 13px;
    background: white;
    min-width: 160px;
}

.filter-input:focus {
    border-color: var(--primary);
    outline: none;
}

/* Top Opportunities Tiles */
.top-opportunities {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    overflow-x: auto;
    padding: 4px;
}

.opp-tile {
    flex: 0 0 170px;
    padding: 14px;
    background: white;
    border-radius: 10px;
    border: 2px solid var(--gray-200);
    cursor: pointer;
    transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1), border-color 0.2s, box-shadow 0.2s;
}

.opp-tile:hover {
    border-color: var(--primary);
    box-shadow: 0 4px 12px rgba(0, 118, 157, 0.15);
    transform: translateY(-1px);
}

.opp-tile.selected {
    border-color: var(--primary);
    background: rgba(0, 118, 157, 0.05);
    transform: translateY(-2px);
    box-shadow: 0 0 0 3px rgba(0, 118, 157, 0.25);
}

.opp-logo {
    width: 36px;
    height: 36px;
    object-fit: contain;
    margin-bottom: 8px;
    border-radius: 6px;
    background: #f5f5f5;
    padding: 2px;
}

.opp-logo-placeholder {
    width: 36px;
    height: 36px;
    background: var(--gray-200);
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    color: var(--gray-500);
    margin-bottom: 8px;
}

.opp-name {
    font-weight: 600;
    font-size: 13px;
    color: var(--gray-900);
    margin-bottom: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.opp-stats {
    font-size: 11px;
    color: var(--gray-500);
}

/* Global Search */
.global-search {
    flex: 0 0 400px;
    padding: 10px 14px;
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    font-size: 14px;
    background: white;
    margin-right: 40px;
}

.global-search:focus {
    border-color: var(--primary);
    outline: none;
    box-shadow: 0 0 0 3px rgba(0, 118, 157, 0.1);
}

/* Filter Chips */
.filter-chips {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.filter-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px 10px;
    background: var(--primary);
    color: white;
    border-radius: 16px;
    font-size: 12px;
    font-weight: 500;
}

.filter-chip .remove {
    cursor: pointer;
    opacity: 0.8;
}

.filter-chip .remove:hover {
    opacity: 1;
}

/* Main Building Table */
.main-table-wrapper {
    overflow-x: auto;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    max-height: 600px;
    overflow-y: auto;
    margin-bottom: 24px;
    background: white;
}

.main-building-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.main-building-table thead {
    position: sticky;
    top: 0;
    z-index: 10;
}

.main-building-table th {
    background: var(--primary);
    color: white;
    padding: 12px 10px;
    text-align: left;
    text-transform: none;
    font-weight: 600;
    white-space: nowrap;
}

.main-building-table th:hover {
    background: var(--primary-dark);
}

/* Sort arrow states */
.main-building-table th[data-sort]::after {
    content: " ⇵";
    opacity: 0.5;
    font-size: 0.85em;
}

.main-building-table th[data-sort][data-dir="asc"]::after {
    content: " ▲";
    opacity: 1;
}

.main-building-table th[data-sort][data-dir="desc"]::after {
    content: " ▼";
    opacity: 1;
}

.main-building-table td {
    padding: 10px;
    border-bottom: 1px solid var(--gray-100);
    vertical-align: middle;
}

.main-building-table tr:hover td {
    background: rgba(0, 118, 157, 0.04);
}

.main-building-table .building-row {
    transition: background 0.15s ease;
}

.main-building-table .building-row.hidden {
    display: none;
}

.rank-badge {
    display: inline-block;
    background: var(--primary);
    color: white;
    padding: 3px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

/* Clickable links with expanded hit targets */
.clickable-link {
    color: var(--primary);
    text-decoration: none;
    cursor: pointer;
    display: inline-block;
    padding: 6px 10px;
    margin: -6px -10px;
    border-radius: 4px;
    transition: background 0.15s ease;
}

.clickable-link:hover {
    background: rgba(0, 118, 157, 0.08);
    text-decoration: underline;
}

.filter-link {
    color: var(--primary);
    text-decoration: none;
    cursor: pointer;
}

.filter-link:hover {
    text-decoration: underline;
}

.carbon-cell {
    text-align: right;
    color: var(--gray-600);
}

.portfolio-section {
    background: var(--gray-50);
    max-width: 1400px;
    margin: 0 auto;
}

.portfolio-sort-header,
.portfolio-header {
    display: grid;
    grid-template-columns: 132px 2fr 1fr 1fr 1fr 1fr 1fr 1fr;
    gap: 12px;
    padding: 8px 16px 8px 0;
    align-items: center;
}

.portfolio-sort-header {
    background: var(--rzero-blue);
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    position: sticky;
    top: 225px;
    z-index: 1002;
}

/* Info Tooltip - blue circle i icon */
.info-tooltip {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    margin-left: 6px;
    width: 18px;
    height: 18px;
    background: linear-gradient(135deg, #0066cc 0%, #004494 100%);
    color: white;
    border-radius: 50%;
    font-size: 12px;
    font-weight: 700;
    cursor: help;
    position: relative;
    flex-shrink: 0;
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
    transition: transform 0.15s, box-shadow 0.15s;
    text-transform: lowercase;
}
.info-tooltip:hover {
    transform: scale(1.1);
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.4);
    z-index: 9999;
}
.info-tooltip::after {
    content: attr(data-tooltip);
    position: absolute;
    top: 125%;
    left: 50%;
    transform: translateX(-50%);
    background-color: #1e293b;
    color: white;
    padding: 10px 14px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 400;
    line-height: 1.5;
    white-space: normal;
    width: 280px;
    text-align: left;
    text-transform: none;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s, visibility 0.2s;
    pointer-events: none;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}
.info-tooltip:hover::after {
    opacity: 1;
    visibility: visible;
}
/* Right-aligned tooltip for elements near right edge */
.info-tooltip.tooltip-right::after {
    left: auto;
    right: 0;
    transform: none;
}
.info-tooltip.tooltip-right::before {
    left: auto;
    right: 10px;
}
.info-tooltip::before {
    content: "";
    position: absolute;
    top: 115%;
    left: 50%;
    transform: translateX(-50%);
    border: 6px solid transparent;
    border-bottom-color: #1e293b;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.2s, visibility 0.2s;
}
.info-tooltip:hover::before {
    opacity: 1;
    visibility: visible;
}

.sort-col {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    font-weight: 600;
    font-size: 12px;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    position: relative;
    transition: color 0.15s;
}
.sort-col:hover {
    color: rgba(255,255,255,0.8);
}
.sort-col[data-total]::before {
    content: attr(data-total);
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    background: #333;
    color: white;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 500;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.2s;
    margin-top: 4px;
    text-transform: none;
    z-index: 1000;
}
.sort-col[data-total]:hover::before {
    opacity: 1;
}
/* Savings tooltip - position left so it doesn't overflow right edge */
#header-opex[data-total]::before {
    left: auto;
    right: 0;
    transform: none;
}
.sort-col:nth-child(6),
.sort-col:nth-child(7),
.sort-col:nth-child(8) {
    justify-content: flex-end;
    text-align: right;
}

/* Portfolio Cards */
.portfolios-list {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.portfolio-card {
    background: white;
    border-radius: 12px;
    border: 1px solid var(--gray-200);
    transition: box-shadow 0.2s;
    position: relative;
}

.portfolio-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

.org-logo-stack {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
}
.org-logo-stack .org-name-small {
    font-size: 10px;
    font-weight: 600;
    max-width: 120px;
    color: #666;
    line-height: 1.2;
    text-align: center;
}
.org-logo-stack .org-name-small .parent-owned {
    display: block;
    font-size: 8px;
    font-weight: 400;
    color: #999;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-top: -1px;
}

.building-grid-row .address-cell {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.building-grid-row .address-cell small {
    display: block;
    color: #666;
    font-size: 12px;
}

.org-logo {
    width: 48px;
    height: 48px;
    object-fit: contain;
    opacity: 0;
    animation: logoFadeIn 0.3s ease-out forwards;
}

@keyframes logoFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.org-logo-placeholder {
    width: 48px;
    height: 48px;
    border-radius: 8px;
    background: var(--gray-200);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 600;
    color: var(--gray-500);
}

.portfolio-name {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding-left: 16px;
    overflow: hidden;
}

.portfolio-name h3 {
    font-size: 16px;
    font-weight: 600;
    color: var(--gray-900);
    margin: 0;
    line-height: 1.3;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.stat-cell {
    font-size: 13px;
    font-weight: 400;
    color: var(--gray-900);
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-cell:has(.addr-main),
.stat-cell:has(.hq-badge) {
    flex-direction: column;
    align-items: flex-start;
}

.stat-cell.building-count {
    justify-content: center;
}

.stat-cell.valuation-value,
.stat-cell.carbon-value,
.stat-cell.opex-value {
    justify-content: flex-end;
}

.stat-cell.eui-value {
    justify-content: center;
}

.stat-cell.classification-cell {
    justify-content: center;
}

.stat-cell .label {
    font-weight: 400;
    color: var(--gray-500);
    font-size: 11px;
}

.vertical-badges {
    display: flex;
    gap: 4px;
}

.vertical-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
    text-transform: uppercase;
}

.vertical-badge.commercial { background: #1a3870; color: #ffffff; }
.vertical-badge.education { background: #0088ff; color: #ffffff; }
.vertical-badge.healthcare { background: #7ec8ff; color: #1a3870; }

/* Classification labels - plain text, no background */
.classification-badge {
    font-size: 9px;
    margin-right: 16px;
    font-weight: 600;
    text-transform: uppercase;
    white-space: nowrap;
}
.classification-badge.owner { color: #0066cc; }
.classification-badge.owner-occupier { color: #0891b2; }
.classification-badge.owner-operator { color: #7c3aed; }
.classification-badge.tenant { color: #1a3870; }
.classification-badge.tenant_sub_org { color: #b45309; }
.classification-badge.property-manager { color: #475569; }

.stat-cell.classification-cell {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--gray-600);
}
.classification-cell.classification-owner { color: #0066cc; }
.classification-cell.classification-owner-occupier { color: #0891b2; }
.classification-cell.classification-owner-operator { color: #7c3aed; }
.classification-cell.classification-tenant { color: #1a3870; }
.classification-cell.classification-tenant_sub_org { color: #b45309; }
.classification-cell.classification-property-manager { color: #475569; }

/* TYPE column filter dropdown */
.type-filter-wrapper {
    position: relative;
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 4px;
}
.type-filter-icon {
    margin-left: 6px;
    opacity: 1;
    transition: transform 0.2s, background 0.2s;
    background: rgba(255,255,255,0.3);
    border-radius: 4px;
    padding: 2px;
}
.type-filter-icon:hover {
    background: rgba(255,255,255,0.5);
}
.type-filter-wrapper.active .type-filter-icon {
    transform: rotate(180deg);
}
.type-filter-dropdown {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    min-width: 180px;
    z-index: 1000;
    display: none;
    padding: 8px 0;
}
.type-filter-dropdown.show {
    display: block;
}
.type-filter-option {
    padding: 8px 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-700);
    transition: background 0.15s;
}
.type-filter-option:hover {
    background: var(--gray-50);
}
.type-filter-option input[type="checkbox"] {
    width: 16px;
    height: 16px;
    accent-color: var(--primary);
    cursor: pointer;
}
.type-filter-option label {
    cursor: pointer;
    flex: 1;
}
.type-filter-divider {
    height: 1px;
    background: var(--gray-200);
    margin: 6px 0;
}
.type-active-indicator {
    display: none;
    margin-left: 6px;
    font-size: 14px;
    font-weight: bold;
    color: white;
    background: rgba(255,255,255,0.3);
    border-radius: 50%;
    width: 18px;
    height: 18px;
    line-height: 16px;
    text-align: center;
    cursor: pointer;
}
.type-active-indicator:hover {
    background: rgba(255,255,255,0.5);
}
.type-filter-wrapper.filtering .type-active-indicator {
    display: inline-block;
}

/* EUI Filter - reuses type-filter styles */
.eui-filter-wrapper {
    position: relative;
    display: inline-flex;
    align-items: center;
    padding: 4px 8px;
    border-radius: 4px;
}
.eui-filter-icon {
    margin-left: 6px;
    opacity: 1;
    transition: transform 0.2s, background 0.2s;
    background: rgba(0,0,0,0.15);
    border-radius: 4px;
    padding: 4px;
    color: #333;
}
.eui-filter-icon:hover {
    background: rgba(0,0,0,0.25);
}
.eui-filter-wrapper.active .eui-filter-icon {
    transform: rotate(180deg);
    animation: none;
}
.eui-filter-dropdown {
    position: absolute;
    top: calc(100% + 4px);
    left: 0;
    background: white;
    border: 1px solid var(--gray-200);
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    min-width: 140px;
    z-index: 1000;
    display: none;
    padding: 8px 0;
}
.eui-filter-dropdown.show {
    display: block;
}
.eui-filter-option {
    padding: 8px 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-700);
    transition: background 0.15s;
}
.eui-filter-option:hover {
    background: var(--gray-50);
}
.eui-filter-option input[type="radio"] {
    width: 16px;
    height: 16px;
    accent-color: var(--primary);
    cursor: pointer;
}
.eui-active-indicator {
    display: none;
    margin-left: 6px;
    font-size: 14px;
    font-weight: bold;
    color: #333;
    background: rgba(0,0,0,0.15);
    border-radius: 50%;
    width: 20px;
    height: 20px;
    line-height: 18px;
    text-align: center;
    cursor: pointer;
}
.eui-active-indicator:hover {
    background: rgba(0,0,0,0.25);
}
.eui-filter-wrapper.filtering .eui-active-indicator {
    display: inline-block;
}

.expand-arrow {
    position: absolute;
    right: -30px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 14px;
    color: var(--gray-400);
    transition: transform 0.2s;
}

.portfolio-card.expanded .expand-arrow {
    transform: translateY(-50%) rotate(180deg);
}

/* Portfolio Buildings Table */
.portfolio-buildings {
    display: none;
    border-top: 1px solid var(--gray-200);
}

.portfolio-card.expanded .portfolio-buildings {
    display: block;
}

.buildings-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    table-layout: fixed;
}

.buildings-table th {
    background: var(--gray-200);
    padding: 8px 12px;
    text-align: left;
    text-transform: none;
    font-weight: 500;
    font-size: 11px;
    color: var(--gray-700);
    text-transform: uppercase;
    letter-spacing: 0.3px;
    position: sticky;
    top: 0;
    z-index: 1;
}

.buildings-table td {
    padding: 14px 16px;
    border-bottom: 1px solid var(--gray-100);
    vertical-align: middle;
}

.buildings-table tr:hover td {
    background: var(--gray-50);
}

/* Grid-based building rows - 9 columns: thumb, extLink, address, type, sqft, eui, val, carbon, opex */
.building-grid-row {
    display: grid;
    grid-template-columns: 96px 24px 2fr 1fr 1fr 1fr 1fr 1fr 1fr;
    gap: 12px;
    padding: 8px 16px 8px 0;
    border-bottom: 1px solid #d4e5f7;
    cursor: pointer;
    align-items: center;
    background: #eef6ff;
    border-left: 4px solid #60a5fa;
    font-size: 12px;
}
.building-grid-row:hover {
    background: #dbeafe;
    border-left-color: #2563eb;
}
.building-grid-row .ext-link-cell {
    margin-left: -4px;
}
.building-grid-row > div:first-child {
    display: flex;
    align-items: center;
    justify-content: flex-end;
}
.building-grid-row .stat-cell:not(:first-of-type) {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
}
.building-grid-row .stat-cell:first-of-type {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: center;
    overflow: hidden;
    min-width: 0;
    white-space: normal;
    margin-left: 16px;
}

.addr-main {
    display: block;
    font-weight: 400;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}

.addr-sub {
    display: block;
    font-size: 12px;
    color: #888;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}

.hq-badge {
    display: block;
    font-size: 8px;
    font-weight: 600;
    color: #0066cc;
    background: rgba(0, 102, 204, 0.15);
    padding: 1px 4px;
    border-radius: 2px;
    margin-top: 2px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
}

.row-controls {
    display: flex;
    justify-content: center;
    gap: 12px;
    padding: 8px;
    background: #dbeafe;
    border-top: 1px solid #bfdbfe;
}

.row-arrow {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    background: white;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 16px;
    color: #3b82f6;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    transition: all 0.15s;
}

.row-arrow:hover:not(.disabled) {
    background: #dbeafe;
    border-color: #3b82f6;
    box-shadow: 0 2px 4px rgba(59,130,246,0.2);
}

.row-arrow.disabled {
    color: #cbd5e1;
    cursor: not-allowed;
    background: #f8fafc;
}

.building-rows-container {
    display: block;
}

/* Building sort header - inside expanded portfolio */
.building-sort-header {
    display: grid;
    grid-template-columns: 96px 24px 2fr 1fr 1fr 1fr 1fr 1fr 1fr;
    gap: 12px;
    padding: 10px 16px 10px 0;
    background: #e0ecf8;
    border-bottom: 1px solid #bfdbfe;
    font-size: 11px;
    font-weight: 600;
    color: #0f172a;
    text-transform: uppercase;
    letter-spacing: 0.3px;
    border-left: 4px solid #60a5fa;
    position: sticky;
    top: 269px;
    z-index: 1001;
}

.building-sort-header .l2-org-name {
    grid-column: span 2;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    text-align: center;
}

.building-sort-header .sort-col {
    cursor: pointer;
    user-select: none;
    transition: color 0.15s;
    color: #0f172a;
    font-size: 11px;
    font-weight: 600;
}

.building-sort-header .sort-col:hover {
    color: #2563eb;
}

.building-sort-header .sort-col.sorted-asc::after {
    content: ' ▲';
    font-size: 9px;
}

.building-sort-header .sort-col.sorted-desc::after {
    content: ' ▼';
    font-size: 9px;
}

.building-thumb {
    width: 60px;
    height: 45px;
    min-width: 60px;
    min-height: 45px;
    max-width: 60px;
    max-height: 45px;
    object-fit: cover;
    border-radius: 4px;
    background: var(--gray-300);
    display: block;
}

.building-thumb-placeholder {
    width: 60px;
    height: 45px;
    border-radius: 4px;
    background: var(--gray-200);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.building-address {
    font-weight: 500;
    color: var(--gray-900);
    white-space: nowrap;
}

.building-address a {
    color: var(--primary);
    text-decoration: none;
}

.building-address a:hover {
    text-decoration: underline;
}

.external-link {
    color: var(--primary);
    margin-left: 6px;
    font-size: 14px;
    font-weight: bold;
    background: rgba(0, 102, 204, 0.15);
    padding: 1px 5px;
    border-radius: 3px;
    text-decoration: none;
}

.external-link:hover {
    color: white;
    background: var(--primary);
}

.city-state {
    color: var(--gray-500);
    font-size: 12px;
}

.building-type {
    vertical-align: middle;
}

/* Building type badges - site palette only */
.type-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 500;
    line-height: 1.3;
    text-align: center;
}
.type-badge--blue { background: var(--primary); color: #fff; }
.type-badge--blue-light { background: #e5f0ff; color: var(--primary-dark); }
.type-badge--gray-dark { background: var(--gray-700); color: #fff; }
.type-badge--gray-mid { background: var(--gray-400); color: var(--gray-900); }
.type-badge--gray-light { background: var(--gray-200); color: var(--gray-700); }
.type-badge--gray-xlight { background: var(--gray-100); color: var(--gray-600); }

.money-cell {
    font-weight: 500;
    text-align: right;
}

.money-cell.positive {
    color: var(--success);
}

/* EUI Rating Colors */
.eui-good { color: #22c55e; font-weight: 600; }
.eui-ok { color: #f59e0b; font-weight: 600; }
.eui-bad { color: #ef4444; font-weight: 600; }
.eui-cell { text-align: right; white-space: nowrap; }

/* Unbold EUI in portfolio building rows */
.building-grid-row .eui-good,
.building-grid-row .eui-ok,
.building-grid-row .eui-bad {
    font-weight: normal;
}

/* Spiderfy Markers for Stacked Buildings */
.spiderfy-marker { cursor: pointer; }
.spiderfy-pin {
    width: 24px;
    height: 24px;
    background: #0066cc;
    border: 3px solid white;
    border-radius: 50%;
    box-shadow: 0 2px 6px rgba(0,0,0,0.3);
    transition: transform 0.15s ease;
}
.spiderfy-pin:hover { transform: scale(1.2); }
.spiderfy-leg {
    position: absolute;
    background: rgba(0, 102, 204, 0.5);
    height: 2px;
    transform-origin: left center;
}

/* Building Search Tab */
.search-section {
    margin-bottom: 24px;
}

.search-input-container {
    position: relative;
    max-width: 500px;
}

.search-input {
    width: 100%;
    padding: 14px 20px 14px 48px;
    font-size: 15px;
    border: 2px solid var(--gray-200);
    border-radius: 12px;
    outline: none;
    transition: border-color 0.2s;
}

.search-input:focus {
    border-color: var(--primary);
}

.search-icon {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--gray-400);
    font-size: 18px;
}

.search-results {
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 24px;
    margin-top: 24px;
}

.results-list {
    background: white;
    border-radius: 12px;
    border: 1px solid var(--gray-200);
    overflow: hidden;
}

.results-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--gray-200);
    font-weight: 600;
    color: var(--gray-700);
}

.results-table-container {
    max-height: 600px;
    overflow-y: auto;
}

.results-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.results-table th {
    background: var(--gray-100);
    padding: 10px 12px;
    text-align: left;
    text-transform: none;
    font-weight: 600;
    color: var(--gray-600);
    position: sticky;
    top: 0;
}

.results-table td {
    padding: 10px 12px;
    border-bottom: 1px solid var(--gray-100);
}

.results-table tr:hover td {
    background: var(--gray-50);
    cursor: pointer;
}

.distance-cell {
    color: var(--gray-500);
    font-size: 12px;
}

/* Map Container */
.map-container {
    background: white;
    border-radius: 12px;
    border: 1px solid var(--gray-200);
    overflow: hidden;
    height: 600px;
}

#search-map {
    width: 100%;
    height: 100%;
}

/* Map Panel (for full map view) */
.map-panel {
    position: fixed;
    top: 0;
    right: 0;
    width: 50%;
    height: 100%;
    background: white;
    z-index: 9999;
    transform: translateX(100%);
    transition: transform 0.3s ease;
    box-shadow: -4px 0 20px rgba(0,0,0,0.1);
    will-change: transform;
}

.map-panel.open {
    transform: translateX(0);
}

.map-panel-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--gray-200);
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.map-panel-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: var(--gray-500);
}

.map-panel-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.map-panel-reset {
    background: var(--gray-100);
    border: 1px solid var(--gray-300);
    border-radius: 6px;
    padding: 6px 14px;
    font-size: 13px;
    font-weight: 500;
    color: var(--gray-700);
    cursor: pointer;
    transition: background-color 0.15s ease, color 0.15s ease;
}

.map-panel-reset:hover {
    background: var(--gray-200);
    border-color: var(--gray-400);
}

/* Address Search Form Styling - Exact match to NYC */
.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.3rem;
    font-weight: bold;
    font-size: 15px;
    color: #1a202c;
}

#full-map {
    height: calc(100% - 130px);
}

/* Climate Zone Legend */
.climate-legend {
    position: absolute;
    bottom: 4px;
    left: 4px;
    background: rgba(255,255,255,0.95);
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 9px;
    color: #666;
    z-index: 10;
    backdrop-filter: blur(4px);
}
.climate-legend-title {
    font-weight: 500;
    margin-bottom: 4px;
    color: #888;
    font-size: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.climate-legend-items {
    display: flex;
    gap: 6px;
}
.climate-legend-items span {
    display: flex;
    align-items: center;
    gap: 2px;
}
.climate-legend-items i {
    width: 8px;
    height: 8px;
    border-radius: 2px;
    display: inline-block;
}

/* Pin Highlight on Table Row */
tr.pin-highlight {
    background: rgba(0, 118, 157, 0.15) !important;
    outline: 2px solid rgba(0, 118, 157, 0.4);
}

/* Cluster Styling */
.mapboxgl-popup {
    z-index: 1001;
}

/* Building Popup */
.mapboxgl-popup {
    max-width: 320px;
}

.mapboxgl-popup-content {
    padding: 0;
    border-radius: 12px;
    overflow: hidden;
}

/* Pin hover popup styling */
.pin-popup .mapboxgl-popup-content {
    padding: 0;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.popup-content {
    padding: 16px;
}

.popup-content h4 {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 4px;
}

.popup-content p {
    font-size: 12px;
    color: var(--gray-500);
    margin-bottom: 8px;
}

.popup-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
    font-size: 12px;
}

.popup-stat {
    background: var(--gray-50);
    padding: 8px;
    border-radius: 6px;
}

.popup-stat .label {
    color: var(--gray-500);
    font-size: 10px;
    text-transform: uppercase;
}

.popup-stat .value {
    font-weight: 600;
    color: var(--gray-900);
}

/* Responsive */
@media (max-width: 1200px) {
    .header h1 {
        font-size: 24px;
    }
    .vertical-filter-bar {
        padding-left: 320px;
    }
    .btn-count {
        display: none;
    }
    .stats-grid {
        grid-template-columns: repeat(3, 1fr);
    }

    .search-results {
        grid-template-columns: 1fr;
    }

    .map-container {
        height: 400px;
    }
}

@media (max-width: 600px) {
    /* Header stays compact */
    .header {
        padding: 12px 16px;
    }

    /* Hide title on mobile */
    .header h1 {
        display: none;
    }

    /* Center the header content */
    .header-content {
        justify-content: center;
    }

    /* Center and expand search box */
    .global-search {
        flex: 1;
        max-width: 400px;
        margin: 0 auto;
    }

    /* Hide export dropdown on mobile */
    .export-dropdown {
        display: none;
    }

    /* Hide filter chips on mobile */
    .filter-chips {
        display: none;
    }

    /* Vertical filter bar uses full width */
    .vertical-filter-bar {
        padding: 12px 16px;
        overflow-x: auto;
        top: 65px;
    }

    /* Smaller vertical buttons on mobile */
    .vertical-btn {
        padding: 8px 12px;
        font-size: 12px;
        white-space: nowrap;
    }

    /* Hide counts on mobile */
    .btn-count {
        display: none;
    }

}

@media (max-width: 768px) {
    .header h1 {
        font-size: 20px;
    }
    .vertical-filter-bar {
        padding-left: 310px;
    }
    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* Responsive: 768-1024px */
@media (max-width: 1024px) {
    .cities-header,
    .cities-row {
        grid-template-columns: 60px 24px 1.5fr 70px 1.2fr 1.2fr 85px;
    }
    .cities-header span:nth-child(4),
    .cities-header span:nth-child(6),
    .cities-row > *:nth-child(4),
    .cities-row > *:nth-child(6) {
        display: none;
    }
    #userInfo {
        right: 10px !important;
        top: 10px !important;
    }
    #userInfo img {
        width: 32px !important;
        height: 32px !important;
    }
}

@media (max-width: 980px) {
    #userInfo {
        display: none !important;
    }
}

/* Responsive: Compact portfolio view for smaller screens (split-screen/tablet) */
@media (max-width: 1100px) {
    .portfolio-sort-header,
    .portfolio-header {
        display: grid;
        width: 100%;
        grid-template-columns: 96px minmax(70px, 0.7fr) minmax(90px, 1fr) minmax(110px, 1.2fr);
        column-gap: 10px;
        align-items: center;
    }

    /* Hide unused columns using data-col (Type, EUI, Carbon, Valuation) */
    .portfolio-sort-header [data-col="type"],
    .portfolio-sort-header [data-col="eui"],
    .portfolio-sort-header [data-col="carbon"],
    .portfolio-sort-header [data-col="valuation"],
    .portfolio-header [data-col="type"],
    .portfolio-header [data-col="eui"],
    .portfolio-header [data-col="carbon"],
    .portfolio-header [data-col="valuation"] {
        display: none !important;
    }

    /* Explicit grid placement - header */
    .portfolio-sort-header [data-col="portfolio"] { grid-column: 1 !important; }
    .portfolio-sort-header [data-col="buildings"] { grid-column: 2 !important; }
    .portfolio-sort-header [data-col="sqft"] { grid-column: 3 !important; }
    .portfolio-sort-header [data-col="savings"] { grid-column: 4 !important; }

    /* Explicit grid placement - data rows */
    .portfolio-header [data-col="portfolio"] { grid-column: 1 !important; }
    .portfolio-header [data-col="buildings"] { grid-column: 2 !important; }
    .portfolio-header [data-col="sqft"] { grid-column: 3 !important; }
    .portfolio-header [data-col="savings"] { grid-column: 4 !important; }

    /* Right-align numbers */
    .portfolio-sort-header [data-col="buildings"],
    .portfolio-sort-header [data-col="sqft"],
    .portfolio-sort-header [data-col="savings"],
    .portfolio-header [data-col="buildings"],
    .portfolio-header [data-col="sqft"],
    .portfolio-header [data-col="savings"] {
        text-align: right;
        justify-content: flex-end;
    }

    /* Prevent org name overflow */
    .portfolio-header [data-col="portfolio"] .org-name-small,
    .portfolio-sort-header [data-col="portfolio"] {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    /* Ensure visible cells display properly */
    .portfolio-header [data-col="buildings"],
    .portfolio-header [data-col="sqft"],
    .portfolio-header [data-col="savings"] {
        display: flex !important;
    }

    /* Compact vertical filter bar */
    .vertical-filter-bar {
        padding: 8px 12px !important;
    }
    .vertical-filter-inner {
        gap: 8px !important;
    }
    .vertical-buttons-group {
        gap: 6px !important;
    }
    .vertical-btn {
        padding: 6px 10px !important;
        font-size: 12px !important;
    }
    .vertical-btn-wrapper .vertical-btn {
        padding-right: 8px !important;
    }
    .vertical-dropdown-arrow {
        padding: 6px 8px !important;
        font-size: 10px !important;
    }
    /* Hide info tooltip on small screens */
    .info-tooltip {
        display: none !important;
    }
    /* Compact export and leaderboard buttons */
    .export-dropdown .export-btn,
    .leaderboard-dropdown .export-btn {
        padding: 6px 10px !important;
        font-size: 12px !important;
    }
    /* Compact main tabs */
    .main-tab {
        padding: 10px 18px !important;
        font-size: 14px !important;
    }
    .main-tabs {
        padding: 8px 16px !important;
    }
}

/* Responsive: below 768px - smaller mobile adjustments */
@media (max-width: 767px) {
    .portfolio-sort-header,
    .portfolio-header {
        grid-template-columns: 70px minmax(50px, 0.7fr) minmax(70px, 1fr) minmax(90px, 1.2fr) !important;
        column-gap: 6px !important;
    }
    .portfolio-header .stat-cell {
        font-size: 11px !important;
    }
    .org-name-small {
        font-size: 10px !important;
    }
    .cities-header,
    .cities-row {
        grid-template-columns: 1fr 80px !important;
    }
    .cities-header > *:nth-child(-n+2),
    .cities-header > *:nth-child(n+4):nth-child(-n+8),
    .cities-row > *:nth-child(-n+2),
    .cities-row > *:nth-child(n+4):nth-child(-n+8) {
        display: none !important;
    }
    .portfolio-section,
    .all-buildings-section {
        padding-left: 8px !important;
        padding-right: 8px !important;
    }
    /* Hide button text labels on mobile - icon only */
    .btn-label {
        display: none !important;
    }
    .btn-icon {
        margin-right: 0 !important;
    }
    .vertical-btn {
        min-width: auto !important;
        padding: 8px 10px !important;
    }
    .vertical-btn-wrapper .vertical-btn {
        padding-right: 6px !important;
    }
    .export-btn {
        padding: 8px 10px !important;
    }
    /* Hide main tab labels on mobile - icon only */
    .tab-label {
        display: none !important;
    }
    .tab-icon {
        margin-right: 0 !important;
    }
    .main-tab {
        padding: 10px 16px !important;
        font-size: 14px !important;
    }
    .main-tabs {
        padding: 8px 12px !important;
    }
}

/* Loading spinner */
.loading {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;
    color: var(--gray-500);
}

.loading::after {
    content: '';
    width: 24px;
    height: 24px;
    border: 3px solid var(--gray-200);
    border-top-color: var(--primary);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin-left: 12px;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Shimmer loading animation - polished skeleton UI */
@keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
}

.loading-shimmer {
    background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s ease-in-out infinite;
}

/* Image skeleton while loading */
.building-thumb.img-loading {
    background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s ease-in-out infinite;
}

.org-logo.img-loading {
    background: linear-gradient(90deg, var(--gray-100) 25%, var(--gray-200) 50%, var(--gray-100) 75%);
    background-size: 200% 100%;
    animation: shimmer 1.5s ease-in-out infinite;
}

/* Instagram-style image loading - NEVER shows empty space */
.img-container {
    position: relative;
    overflow: hidden;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.img-skeleton {
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, #e8e8e8 25%, #f5f5f5 50%, #e8e8e8 75%);
    background-size: 200% 100%;
    animation: shimmer 1.2s ease-in-out infinite;
    z-index: 1;
}
.img-skeleton.logo {
    border-radius: 6px;
    background-color: #f0f0f0;
}
.img-skeleton.thumb {
    border-radius: 4px;
    background-color: #e8e8e8;
}
.img-loaded {
    opacity: 1 !important;
}
.img-hidden {
    display: none !important;
}
/* Ensure placeholder stays positioned correctly */
.img-container .org-logo-placeholder,
.img-container .building-thumb-placeholder {
    position: relative;
    z-index: 0;
}

/* Hidden */
.hidden {
    display: none !important;
}

/* Filtered out - used for optimized filtering */
.filtered-out {
    display: none !important;
}

/* =============================================================================
   TUTORIAL SYSTEM - WalkMe-style Interactive Guide
   ============================================================================= */

/* Tutorial Launch Button - Compact ? icon in gutter */
.tutorial-launch-btn {
    position: fixed;
    bottom: 20px;
    right: 24px;
    z-index: 9998;
    background: linear-gradient(135deg, #0066cc 0%, #004494 100%);
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    padding: 0;
    font-size: 20px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 2px 8px rgba(0, 102, 204, 0.3);
    transition: transform 0.2s, box-shadow 0.2s;
    font-family: 'Inter', sans-serif;
}

.tutorial-launch-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 3px 12px rgba(0, 102, 204, 0.5);
}

.tutorial-icon {
    display: flex;
    align-items: center;
    justify-content: center;
}

.tutorial-text,
.tutorial-pulse {
    display: none;
}

/* Tutorial Overlay System */
.tutorial-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 99998;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s;
}

.tutorial-overlay.active {
    pointer-events: auto;
    opacity: 1;
}

.tutorial-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.75);
    display: none;
}

.tutorial-backdrop.active {
    display: block;
}

.tutorial-spotlight {
    position: absolute;
    border-radius: 8px;
    transition: all 0.2s ease;
    pointer-events: none;
    background: transparent;
}

.tutorial-spotlight.single-target {
    box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.75);
}

/* Spotlight glow effect */
.tutorial-spotlight::after {
    content: '';
    position: absolute;
    top: -4px;
    left: -4px;
    right: -4px;
    bottom: -4px;
    border: 3px solid #0066cc;
    border-radius: 12px;
    animation: spotlight-glow 1.5s ease-in-out infinite;
}

@keyframes spotlight-glow {
    0%, 100% { box-shadow: 0 0 10px rgba(0, 102, 204, 0.5); }
    50% { box-shadow: 0 0 25px rgba(0, 102, 204, 0.8); }
}

.tutorial-spotlight.extra-highlight::after {
    border-color: #ff6600;
    animation: spotlight-glow-orange 1s ease-in-out infinite;
}

@keyframes spotlight-glow-orange {
    0%, 100% { box-shadow: 0 0 15px rgba(255, 102, 0, 0.6); }
    50% { box-shadow: 0 0 35px rgba(255, 102, 0, 0.9); }
}

/* Tutorial Tooltip */
.tutorial-tooltip {
    position: absolute;
    background: white;
    border-radius: 12px;
    padding: 20px 24px;
    max-width: 380px;
    min-width: 320px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
    pointer-events: none;
    transition: opacity 0.15s ease, top 0.15s ease, left 0.15s ease;
    font-family: 'Inter', sans-serif;
    opacity: 0;
}

.tutorial-tooltip.visible {
    opacity: 1;
    pointer-events: auto;
}

.tutorial-tooltip::before {
    content: '';
    position: absolute;
    width: 16px;
    height: 16px;
    background: white;
    transform: rotate(45deg);
}

/* Arrow positions - use CSS variable for dynamic positioning */
.tutorial-tooltip.arrow-top::before { top: -8px; left: var(--arrow-offset, 190px); transform: rotate(45deg); }
.tutorial-tooltip.arrow-bottom::before { bottom: -8px; left: var(--arrow-offset, 190px); transform: rotate(45deg); }
.tutorial-tooltip.arrow-left::before { left: -8px; top: var(--arrow-offset, 100px); transform: rotate(45deg); }
.tutorial-tooltip.arrow-right::before { right: -8px; top: var(--arrow-offset, 100px); transform: rotate(45deg); }

.tutorial-step-indicator {
    font-size: 12px;
    color: var(--gray-500);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 8px;
    font-weight: 500;
}

.tutorial-title {
    font-size: 18px;
    font-weight: 600;
    color: var(--gray-900);
    margin: 0 0 10px 0;
}

.tutorial-content {
    font-size: 14px;
    color: var(--gray-600);
    line-height: 1.6;
    margin: 0 0 20px 0;
}

.tutorial-actions {
    display: flex;
    justify-content: flex-end;
    align-items: center;
}

.tutorial-close {
    position: absolute;
    top: 8px;
    right: 8px;
    background: none;
    border: none;
    color: var(--gray-400);
    font-size: 20px;
    cursor: pointer;
    padding: 4px 8px;
    line-height: 1;
    border-radius: 4px;
}

.tutorial-close:hover {
    color: var(--gray-600);
    background: var(--gray-100);
}

.tutorial-nav {
    display: flex;
    gap: 10px;
}

.tutorial-btn-primary {
    background: linear-gradient(135deg, #0066cc 0%, #004494 100%);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
    font-family: 'Inter', sans-serif;
}

.tutorial-btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0, 102, 204, 0.3);
}

.tutorial-btn-secondary {
    background: var(--gray-100);
    color: var(--gray-700);
    border: 1px solid var(--gray-300);
    border-radius: 8px;
    padding: 10px 16px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    font-family: 'Inter', sans-serif;
}

.tutorial-btn-secondary:hover {
    background: var(--gray-200);
}

.tutorial-btn-secondary:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* ============================================================================
   HARD OVERRIDE: Responsive portfolio grid (placed at END for max specificity)
   ============================================================================ */
@media (max-width: 1100px) {
    #portfolios-tab .portfolio-sort-header,
    #portfolios-tab .portfolio-header {
        display: grid !important;
        width: 100% !important;
        gap: 0 !important;
        column-gap: 10px !important;
        grid-template-columns: 96px minmax(70px, 0.7fr) minmax(90px, 1fr) minmax(110px, 1.2fr) !important;
        align-items: center !important;
    }

    /* HIDE unused columns - nuclear option */
    #portfolios-tab .portfolio-sort-header [data-col="type"],
    #portfolios-tab .portfolio-sort-header [data-col="eui"],
    #portfolios-tab .portfolio-sort-header [data-col="carbon"],
    #portfolios-tab .portfolio-sort-header [data-col="valuation"],
    #portfolios-tab .portfolio-header [data-col="type"],
    #portfolios-tab .portfolio-header [data-col="eui"],
    #portfolios-tab .portfolio-header [data-col="carbon"],
    #portfolios-tab .portfolio-header [data-col="valuation"] {
        display: none !important;
        visibility: hidden !important;
        width: 0 !important;
        height: 0 !important;
        overflow: hidden !important;
        padding: 0 !important;
        margin: 0 !important;
        border: 0 !important;
        position: absolute !important;
        left: -9999px !important;
    }

    /* Explicit column placement */
    #portfolios-tab .portfolio-sort-header [data-col="portfolio"],
    #portfolios-tab .portfolio-header [data-col="portfolio"] { grid-column: 1 !important; }

    #portfolios-tab .portfolio-sort-header [data-col="buildings"],
    #portfolios-tab .portfolio-header [data-col="buildings"] { grid-column: 2 !important; }

    #portfolios-tab .portfolio-sort-header [data-col="sqft"],
    #portfolios-tab .portfolio-header [data-col="sqft"] { grid-column: 3 !important; }

    #portfolios-tab .portfolio-sort-header [data-col="savings"],
    #portfolios-tab .portfolio-header [data-col="savings"] { grid-column: 4 !important; }

    /* Ensure visible cells display properly */
    #portfolios-tab .portfolio-header [data-col="buildings"],
    #portfolios-tab .portfolio-header [data-col="sqft"],
    #portfolios-tab .portfolio-header [data-col="savings"] {
        display: flex !important;
        justify-content: flex-end !important;
    }

    /* Right-align header text */
    #portfolios-tab .portfolio-sort-header [data-col="buildings"],
    #portfolios-tab .portfolio-sort-header [data-col="sqft"],
    #portfolios-tab .portfolio-sort-header [data-col="savings"] {
        text-align: right !important;
    }
}

/* Smaller adjustments for mobile */
@media (max-width: 767px) {
    #portfolios-tab .portfolio-sort-header,
    #portfolios-tab .portfolio-header {
        grid-template-columns: 70px minmax(50px, 0.7fr) minmax(70px, 1fr) minmax(90px, 1.2fr) !important;
        column-gap: 6px !important;
    }
    #portfolios-tab .portfolio-header .stat-cell {
        font-size: 11px !important;
    }
    #portfolios-tab .org-name-small {
        font-size: 10px !important;
    }
}
</style>'''

    # =========================================================================
    # BODY SECTIONS
    # =========================================================================

    def _generate_body_start(self):
        """Generate opening body tag with login overlay and left sidebar."""
        sidebar_html = self._generate_left_sidebar()
        return f'''<body>
    <!-- Define callback BEFORE Google Sign-In loads -->
    <script>
    window.handleCredentialResponse = function(response) {{const base64Url = response.credential.split(".")[1];
        const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
        const jsonPayload = decodeURIComponent(atob(base64).split("").map(function(c) {{
            return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
        }}).join(""));
        const userData = JSON.parse(jsonPayload);if (userData.email && userData.email.endsWith("@rzero.com")) {{localStorage.setItem("rzeroAuth", JSON.stringify({{
                email: userData.email,
                name: userData.name,
                picture: userData.picture,
                expires: Date.now() + 86400000
            }}));
            document.getElementById("loginOverlay").style.display = "none";
            document.getElementById("mainContent").style.display = "block";

            // Set global USER object
            window.USER = {{ name: userData.name || "", email: userData.email || "" }};

            // Sign into Firebase Auth with GIS token
            (function signinToFirebaseWithGISToken() {{
              try {{
                const idToken = response && response.credential ? response.credential : null;
                if (!idToken) {{ console.warn("No GIS idToken found"); return; }}

                const waitForAuthAPI = () => new Promise(res => {{
                  const tick = () => (firebase && firebase.auth ? res() : setTimeout(tick, 75));
                  tick();
                }});

                waitForAuthAPI().then(async () => {{
                  const cred = firebase.auth.GoogleAuthProvider.credential(idToken);
                  await firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL);
                  await firebase.auth().signInWithCredential(cred);
                  // Display user info after Firebase auth
                  displayUserInfo();
                }});
              }} catch (e) {{
                console.error("Firebase Auth sign-in failed", e);
              }}
            }})();

            // Display user profile info
            displayUserInfo();
        }} else {{
            alert("Access restricted to R-Zero employees only");
        }}
    }};

    // Secret bypass: click R-Zero logo 3 times to login as fmiller@rzero.com
    window.logoClickCount = 0;
    window.logoClickTimer = null;
    window.handleLogoClick = function() {{
        window.logoClickCount++;// Visual feedback - flash the logo
        var logo = document.querySelector('#loginOverlay img');
        if (logo) {{
            logo.style.transform = 'scale(0.95)';
            logo.style.transition = 'transform 0.1s';
            setTimeout(function() {{ logo.style.transform = 'scale(1)'; }}, 100);
        }}

        // Show click count as subtle hint
        var hint = document.getElementById('bypassHint');
        if (!hint) {{
            hint = document.createElement('div');
            hint.id = 'bypassHint';
            hint.style.cssText = 'position:fixed;top:10px;left:10px;background:rgba(0,0,0,0.7);color:#0f0;padding:8px 12px;border-radius:4px;font-family:monospace;font-size:12px;z-index:99999;';
            document.body.appendChild(hint);
        }}
        hint.textContent = '[DEBUG] Logo clicks: ' + window.logoClickCount + '/3';
        hint.style.display = 'block';

        // Reset after 2 seconds of inactivity
        if (window.logoClickTimer) clearTimeout(window.logoClickTimer);
        window.logoClickTimer = setTimeout(function() {{
            window.logoClickCount = 0;var h = document.getElementById('bypassHint');
            if (h) h.style.display = 'none';
        }}, 2000);

        if (window.logoClickCount >= 3) {{window.logoClickCount = 0;

            // Show success message
            var hint = document.getElementById('bypassHint');
            if (hint) {{
                hint.textContent = '[DEBUG] BYPASS ACTIVATED - logging in as fmiller@rzero.com';
                hint.style.background = 'rgba(0,128,0,0.9)';
            }}

            // Set auth in localStorage
            localStorage.setItem("rzeroAuth", JSON.stringify({{
                email: "fmiller@rzero.com",
                name: "Forrest Miller",
                picture: null,
                expires: Date.now() + 86400000
            }}));

            // Set global USER object
            window.USER = {{ name: "Forrest Miller", email: "fmiller@rzero.com" }};

            // Hide login, show content
            document.getElementById("loginOverlay").style.display = "none";
            document.getElementById("mainContent").style.display = "block";

            // Hide debug hint after a moment
            setTimeout(function() {{
                var h = document.getElementById('bypassHint');
                if (h) h.style.display = 'none';
            }}, 2000);

            // Display user info
            if (typeof displayUserInfo === "function") displayUserInfo();

            // Track visit in Firestore
            (async function() {{
                try {{
                    if (typeof firebase === 'undefined' || !window.db) return;
                    const ref = window.db.collection('nationwideUserActivity').doc('bypass_fmiller');
                    await ref.set({{
                        email: 'fmiller@rzero.com',
                        displayName: 'Forrest Miller',
                        firstName: 'Forrest',
                        lastName: 'Miller',
                        lastActive: firebase.firestore.FieldValue.serverTimestamp()
                    }}, {{ merge: true }});
                    // Skip visitCount increment for bypass auth
                }} catch(e) {{
                    console.warn("[Bypass] Failed to track visit:", e);
                }}
            }})();
        }}
    }};
    </script>

    <!-- Google Sign-In Overlay -->
    <div id="loginOverlay" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #0066cc 0%, #004494 100%);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    ">
        <div style="
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 400px;
            width: 90%;
        ">
            <img src="https://rzero.com/wp-content/uploads/2021/10/rzero-logo-pad.svg" alt="R-Zero Logo" style="width: 150px; margin-bottom: 20px; cursor: pointer;" onclick="handleLogoClick()">
            <h2 style="margin: 0 0 10px 0; color: #333;">Nationwide ODCV Prospector</h2>
            <p style="color: #666; margin-bottom: 25px;">Sign in with your R-Zero account</p>

            <div id="g_id_onload"
                 data-client_id="70489892630-1j0t3rni5a7f07ng3v3k916lunm9n76d.apps.googleusercontent.com"
                 data-callback="handleCredentialResponse"
                 data-auto_prompt="false">
            </div>
            <div style="display: flex; justify-content: center; width: 100%;">
                <div class="g_id_signin"
                     data-type="standard"
                     data-size="large"
                     data-theme="filled_blue"
                     data-text="sign_in_with"
                     data-shape="pill"
                     data-logo_alignment="center">
                </div>
            </div>
        </div>
    </div>

{sidebar_html}'''

    def _generate_left_sidebar(self):
        """Generate vertical filter bar AND left sidebar with building type filters."""
        by_vertical = self.stats.get('by_vertical', {})
        total = self.stats.get('total_buildings', 0)
        radio_counts = self.stats.get('radio_type_counts', {})
        types_by_vertical = self.stats.get('types_by_vertical', {})
        type_counts_by_vertical = self.stats.get('type_counts_by_vertical', {})

        # Colors: bg color for each vertical
        colors = {
            'all': '#6b7280',       # grey
            'Commercial': '#1e3a5f', # dark navy
            'Education': '#0077cc',  # blue
            'Healthcare': '#5ba3d9', # light blue
        }

        # Map building types to the vertical with the highest count
        # This ensures types like "Office" appear under Commercial (9,756) not Education (135)
        type_to_vertical = {}
        for vertical, types in types_by_vertical.items():
            for t in types:
                if t not in type_to_vertical:
                    type_to_vertical[t] = vertical
                else:
                    # Compare counts - assign to vertical with more buildings of this type
                    current_v = type_to_vertical[t]
                    current_count = type_counts_by_vertical.get(current_v, {}).get(t, 0)
                    new_count = type_counts_by_vertical.get(vertical, {}).get(t, 0)
                    if new_count > current_count:
                        type_to_vertical[t] = vertical

        # Build dropdown options for each vertical (sorted by count descending)
        dropdown_options = {v: [] for v in ['Commercial', 'Education', 'Healthcare']}
        for btype, count in sorted(radio_counts.items(), key=lambda x: -x[1]):
            if not btype or btype == 'bldg_type_filter':
                continue
            v = type_to_vertical.get(btype, 'Commercial')
            if v in dropdown_options:
                dropdown_options[v].append(
                    f'<label><input type="radio" name="building-type-filter" data-type="{attr_escape(btype)}" '
                    f'onchange="selectBuildingTypeFromDropdown(\'{attr_escape(btype)}\', \'{v}\')">'
                    f'{escape(btype)} <span class="dropdown-count">({count:,})</span></label>'
                )

        # Vertical buttons HTML (with dropdown arrows)
        vertical_html = []
        icons = {'Commercial': '¢', 'Education': '✎', 'Healthcare': '✚'}
        for v in ['Commercial', 'Education', 'Healthcare']:
            count = by_vertical.get(v, {}).get('building_count', 0)
            # Add "All" option at top of each dropdown
            all_option = f'<label><input type="radio" name="building-type-filter" data-type="all-{v.lower()}" onchange="selectBuildingTypeFromDropdown(\'all\', \'{v}\')">All <span class="dropdown-count">({count:,})</span></label>'
            dropdown_content = all_option + ''.join(dropdown_options.get(v, []))
            icon = icons.get(v, '')
            vertical_html.append(
                f'<div class="vertical-btn-wrapper">'
                f'<button class="vertical-btn" data-vertical="{v}" '
                f'onclick="selectVertical(\'{v}\')" style="background:{colors[v]}">'
                f'<span class="btn-icon" style="font-size: 14px;">{icon}</span><span class="btn-label">{v}</span>'
                f'<span class="btn-x" onclick="event.stopPropagation(); clearVerticalBuildingTypeFilter(\'{v}\')">✕</span>'
                f'</button>'
                f'<button class="vertical-dropdown-arrow" data-vertical="{v}" '
                f'onclick="toggleVerticalDropdown(event, \'{v}\')" style="background:{colors[v]}">'
                f'<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z"/></svg></button>'
                f'<div class="vertical-dropdown" id="dropdown-{v}">{dropdown_content}</div>'
                f'</div>'
            )

        # Return BOTH the vertical filter bar AND the filter drawer
        return f'''<div class="vertical-filter-bar">
    <div class="vertical-filter-inner">
        <div class="vertical-buttons-group">{''.join(vertical_html)}</div>
        <span class="info-tooltip" style="margin-left: 2px;" data-tooltip="Click the arrow on each button to see building type filters specific to that industry vertical.">i</span>
        <div id="building-type-chip" class="building-type-chip">
            <span class="chip-x" onclick="clearBuildingTypeFilter()">&times;</span>
            <span class="chip-text"></span>
        </div>
        <div class="export-dropdown" style="margin-left: auto;">
            <button class="export-btn" onclick="toggleExportMenu(event)" style="background: #1e3a5f;">
                <span class="btn-icon" style="font-size: 14px;">&#8595;</span><span class="btn-label">Export CSV</span>
            </button>
            <div id="export-menu" class="export-menu">
                <button onclick="exportAllBuildingsCSV()">All Buildings</button>
                <button onclick="exportFilteredCSV()">Filtered Results</button>
                <button onclick="exportPortfolioCSV()">Portfolio Summaries</button>
            </div>
        </div>
        <div class="leaderboard-dropdown" style="margin-left: 8px;">
            <button class="export-btn" onclick="toggleLeaderboardMenu(event)" style="background: #5ba3d9;">
                <span class="btn-icon" style="font-size: 14px;">&#9733;</span><span class="btn-label">Leaderboard</span>
            </button>
            <div id="leaderboard-menu" class="leaderboard-menu">
                <div class="lb-header">
                    <span>Most Active Users</span>
                </div>
                <div class="lb-controls">
                    <button class="lb-refresh" id="lb-refresh-dropdown" onclick="event.stopPropagation(); refreshLeaderboard();">Refresh</button>
                    <span class="lb-updated" id="lb-updated-dropdown"></span>
                </div>
                <ul class="leaderboard-list" id="leaderboard-list">
                    <li class="leaderboard-item" style="color:#888;">Loading...</li>
                </ul>
            </div>
        </div>
        <button class="export-btn" onclick="openMapPanel()" style="margin-left: 8px; background: #0077cc;">
            <span style="font-size: 14px;">&#9678;</span> Map
        </button>
        <span class="info-tooltip tooltip-right" style="margin-left: 2px; z-index: 1010;" data-tooltip="Use the map to see the geographic distribution of a selected portfolio, or check if we have a specific building by searching its address.">i</span>
    </div>
</div>'''

    def _generate_body_end(self):
        """Generate closing body and html tags with auth functions and visitor leaderboard."""
        timestamp = datetime.now(pytz.timezone('America/New_York')).strftime('%Y-%m-%d %H:%M:%S EST')
        sf_timestamp = datetime.now(pytz.timezone('America/Los_Angeles')).strftime('%m/%d/%Y %I:%M %p PST')
        return f'''
    <footer id="visitor-footer" style="margin: 20px auto; max-width: 600px; text-align: center; font-size:12px; color:#666;">
      <div class="build-footer" style="padding-top: 8px; font-size: 10px; color: #aaa;">
        Build: {timestamp}
      </div>
    </footer>

    </div><!-- close mainContent -->

    <!-- Tutorial Overlay System -->
    <div id="tutorial-overlay" class="tutorial-overlay">
        <div class="tutorial-backdrop"></div>
        <div class="tutorial-spotlight" id="tutorial-spotlight"></div>
        <div class="tutorial-spotlight" id="tutorial-spotlight-2"></div>
        <div class="tutorial-tooltip" id="tutorial-tooltip">
            <div class="tutorial-step-indicator">Step <span id="tutorial-step-num">1</span> of <span id="tutorial-total-steps">8</span></div>
            <h3 id="tutorial-title" class="tutorial-title"></h3>
            <button class="tutorial-close" onclick="endTutorial()">&times;</button>
            <p id="tutorial-content" class="tutorial-content"></p>
            <div class="tutorial-actions">
                <div class="tutorial-nav">
                    <button id="tutorial-next" class="tutorial-btn-primary" onclick="nextTutorialStep()">Next</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Auth and User Management JavaScript -->
    <script>
    function checkAuth() {{// Bypass auth for file:// protocol
        if (window.location.protocol === 'file:') {{showMainContent();
            return;
        }}

        const authToken = localStorage.getItem("rzeroAuth");if (authToken) {{
            const authData = JSON.parse(authToken);
            if (Date.now() < authData.expires) {{showMainContent();
                return;
            }}localStorage.removeItem("rzeroAuth");
        }}}}

    function showMainContent() {{const loginOverlay = document.getElementById("loginOverlay");
        const mainContent = document.getElementById("mainContent");if (loginOverlay) loginOverlay.style.display = "none";
        if (mainContent) mainContent.style.display = "block";

        // Display user profile info
        displayUserInfo();
    }}

    // Get profile picture URL based on email
    function getProfilePicture(email) {{
        const profileMap = {{
            'agoodwin@rzero.com': 'Alex_Goodwin.jpg',
            'apires@rzero.com': 'Andy_Pires.jpg',
            'asalvatore@rzero.com': 'Anthony_Salvatore.jpg',
            'bsiegfried@rzero.com': 'Ben_Siegfried.jpg',
            'ben@rzerosystems.com': 'Benjamin_Boyer.jpg',
            'bgreen@rzero.com': 'Benjamin_Green.jpg',
            'bquan@rzero.com': 'Brenda_Quan.jpg',
            'csutherland@rzero.com': 'Chelsea_Sutherland.jpg',
            'ddufrane@rzero.com': 'Dana_DuFrane.jpg',
            'dmorkarnon@rzero.com': 'Dana_Mor_Karnon.jpg',
            'dcox@rzero.com': 'Dave_Cox.jpg',
            'dnuno@rzero.com': 'David_Nuno.jpg',
            'dseniawski@rzero.com': 'David_Seniawski.jpg',
            'dhess@rzero.com': 'Don_Hess.jpg',
            'doliner@rzero.com': 'Drew_Oliner.jpg',
            'eredmond@rzero.com': 'Elizabeth_Redmond.jpg',
            'efoster@rzero.com': 'Eric_Foster.jpg',
            'fmiller@rzero.com': 'Forrest_Miller.jpg',
            'fstamatatos@rzero.com': 'Francis_Stamatatos.jpg',
            'hsverdlik@rzero.com': 'Hannah_Sverdlik.jpg',
            'igendelman@rzero.com': 'Ilya_Gendelman.jpg',
            'jnuckles@rzero.com': 'Jennifer_Nuckles.jpg',
            'jquiros@rzero.com': 'Jorge_Quiros.jpg',
            'jmunoz@rzero.com': 'Julio_Munoz.jpg',
            'kneff@rzero.com': 'Kim_Neff.jpg',
            'laguilar@rzero.com': 'Luis_Aguilar.jpg',
            'mkulkarni@rzero.com': 'Manali_Kulkarni.jpg',
            'mbuffler@rzero.com': 'Martyn_R._Buffler.jpg',
            'mdharmani@rzero.com': 'Mehak_Dharmani.jpg',
            'mchu@rzero.com': 'Michael_Chu.jpg',
            'mdever@rzero.com': 'Michael_Dever.jpg',
            'mhopps@rzero.com': 'Michael_Hopps.jpg',
            'melafifi@rzero.com': 'Mohamed_El-afifi.jpg',
            'mbarash@rzero.com': 'Monique_Barash.jpg',
            'nalvarado@rzero.com': 'Nelson_Alvarado.jpg',
            'nturizo@rzero.com': 'Nestor_Turizo.jpg',
            'nviscuso@rzero.com': 'Nick_Viscuso.jpg',
            'nvannuil@rzero.com': 'Nicolaas_Van_Nuil.jpg',
            'nbanta@rzero.com': 'Nicole_Dianne_Banta.jpg',
            'ppan@rzero.com': 'Priscilla_Pan.jpg',
            'rmartin@rzero.com': 'Rick_Martin.jpg',
            'skarki@rzero.com': 'Sanjil_Karki.jpg',
            'skurgansky@rzero.com': 'Stas_Kurgansky.jpg',
            'ssnow@rzero.com': 'Stephanie_Snow.jpg',
            'tbusbee@rzero.com': 'Thomas_Busbee.jpg',
            'treznik@rzero.com': 'Thomas_Reznik.jpg',
            'tpearce@rzero.com': 'Trish_Pearce.jpg',
            'ukogan@rzero.com': 'Uri_Kogan.jpg',
            'vherico@rzero.com': 'Veronica_Herico.jpg',
            'wiley.wang@rzero.com': 'Wiley_Wang.jpg',
            'wmusat@rzero.com': 'will_musat.jpg'
        }};

        const filename = profileMap[email.toLowerCase()];
        return filename ? `profile-pics/${{filename}}` : null;
    }}

    function displayUserInfo() {{const auth = localStorage.getItem("rzeroAuth");
        if (auth) {{
            const authData = JSON.parse(auth);
            const userEmail = authData.email;
            const userName = authData.name || userEmail.split("@")[0];// Update the header user info
            const userInfoElement = document.getElementById("userInfo");
            const userNameElement = document.getElementById("userName");
            const userProfilePic = document.getElementById("userProfilePic");if (userInfoElement && userNameElement && userProfilePic) {{
                userNameElement.textContent = userName;
                const localPic = getProfilePicture(userEmail);
                const googlePic = authData.picture;userProfilePic.src = localPic || googlePic || 'profile-pics/rzero_default.png';
                userProfilePic.onerror = function() {{
                    // Fallback chain: local pic failed -> try Google pic -> rzero logo
                    if (this.src.includes('profile-pics/') && googlePic && !this.src.includes('rzero_default')) {{this.src = googlePic;
                    }} else {{this.src = 'profile-pics/rzero_default.png';
                    }}
                }};
                userInfoElement.style.display = "block";}} else {{}}
        }} else {{}}
    }}

    function signOut() {{
        localStorage.removeItem("rzeroAuth");
        // Also sign out of Firebase
        if (typeof firebase !== 'undefined' && firebase.auth) {{
            firebase.auth().signOut();
        }}
        location.reload();
    }}

    function showBuildDate() {{
        alert("Build: {sf_timestamp}");
    }}

    // Check auth on page load
    document.addEventListener('DOMContentLoaded', checkAuth);
    </script>

    <!-- Visitor Leaderboard Script (Dropdown) -->
    <script>
    (function(){{
      if (typeof firebase === 'undefined' || !firebase.firestore) return;

      const db   = window.db || firebase.firestore();
      const list = document.getElementById('leaderboard-list');
      const btn  = document.getElementById('lb-refresh-dropdown');
      const info = document.getElementById('lb-updated-dropdown');
      if (!list || !btn) return;

      function render(rows){{
        if (!rows.length) {{
          list.innerHTML = '<li class="leaderboard-item" style="color:#888;">No data yet.</li>';
          return;
        }}
        list.innerHTML = rows.map((r, i) => {{
          const name = [r.firstName, r.lastName].filter(Boolean).join(' ') || r.displayName || r.email || 'Anonymous';
          const n = r.visitCount || 0;
          const pretty = n >= 1000 ? (Math.round(n/100)/10)+'k' : String(n);
          const localPic = getProfilePicture(r.email);
          const googlePic = r.photoURL || '';
          const avatarSrc = localPic || googlePic || 'profile-pics/rzero_default.png';
          // Fallback chain: local pic -> Google pic -> rzero logo
          const onerrorHandler = googlePic
            ? `if(this.src.includes('profile-pics/') && !this.src.includes('rzero_default')){{this.src='${{googlePic}}'}}else{{this.src='profile-pics/rzero_default.png'}}`
            : `this.src='profile-pics/rzero_default.png'`;
          return `<li class="leaderboard-item"><img src="${{avatarSrc}}" class="leaderboard-avatar" onerror="${{onerrorHandler}}"><span class="leaderboard-name">${{i+1}}. ${{name}}</span><span class="leaderboard-count">${{pretty}} visits</span></li>`;
        }}).join('');
      }}

      function stamp(){{
        const d = new Date();
        info.textContent = 'Updated ' + d.toLocaleTimeString([], {{hour:'2-digit', minute:'2-digit'}});
      }}

      window.refreshLeaderboard = async function(){{
        try {{
          await firebase.firestore().enableNetwork().catch((e)=>{{ if(window.DIAG) DIAG.log('warn', 'Firestore enableNetwork failed', e); }});
          btn.disabled = true;
          btn.textContent = 'Refreshing...';

          const q = db.collection('nationwideUserActivity').orderBy('visitCount','desc').limit(30);
          const snap = await q.get({{ source: 'server' }});

          const rows = [];
          snap.forEach(doc => rows.push(doc.data()));
          render(rows);
          stamp();
          btn.textContent = 'Refresh';
        }} catch (e) {{try {{
            const q = db.collection('nationwideUserActivity').orderBy('visitCount','desc').limit(30);
            const snap = await q.get({{ source: 'cache' }});
            const rows = [];
            snap.forEach(doc => rows.push(doc.data()));
            render(rows);
            stamp();
          }} catch(_) {{
            info.textContent = 'Update failed';
          }}
          btn.textContent = 'Refresh';
        }} finally {{
          btn.disabled = false;
        }}
      }}

      btn.addEventListener('click', refreshLeaderboard);
      refreshLeaderboard();
    }})();
    </script>

    <!-- Hidden Diagnostics Button - Triple-click anywhere to reveal -->
    <button id="diag-btn" style="display:none;position:fixed;bottom:10px;right:10px;z-index:99999;
        background:#222;color:#0f0;padding:12px 24px;border:2px solid #0f0;cursor:pointer;font-family:monospace;
        border-radius:4px;box-shadow:0 2px 10px rgba(0,255,0,0.3);font-size:14px;">
        Run Diagnostics
    </button>
    <script>
    (function() {{
        let clickCount = 0;
        let clickTimer = null;
        document.addEventListener('click', function(e) {{
            // Don't trigger on interactive elements
            if (e.target.closest('button, a, input, select, .portfolio-card, .building-row, .leaderboard-dropdown')) return;
            clickCount++;
            clearTimeout(clickTimer);
            clickTimer = setTimeout(() => {{ clickCount = 0; }}, 500);
            if (clickCount >= 3) {{
                clickCount = 0;
                const btn = document.getElementById('diag-btn');
                btn.style.display = btn.style.display === 'none' ? 'block' : 'none';
                if (btn.style.display === 'block') {{
                    DIAG.log('info', 'Diagnostics panel revealed via triple-click');
                }}
            }}
        }});
    }})();
    document.getElementById('diag-btn').onclick = async function(e) {{
        e.stopPropagation();
        this.textContent = 'Running...';
        this.disabled = true;
        this.style.background = '#333';

        const results = await runDiagnostics();

        // Console output with colors
        console.group('=== DIAGNOSTICS RESULTS ===');
        console.log('%c PASSED (' + results.passed.length + ')', 'color: #0f0; font-weight: bold; font-size: 14px');
        results.passed.forEach(t => console.log('  ✓ ' + t));
        if (results.failed.length > 0) {{
            console.log('%c FAILED (' + results.failed.length + ')', 'color: #f00; font-weight: bold; font-size: 14px');
            results.failed.forEach(t => console.error('  ✗ ' + t));
        }}
        if (results.warnings.length > 0) {{
            console.log('%c WARNINGS (' + results.warnings.length + ')', 'color: #ff0; font-weight: bold');
            results.warnings.forEach(t => console.warn('  ⚠ ' + t));
        }}
        console.log('%c DIAG Log (' + DIAG.checks.length + ' entries)', 'color: #888');
        DIAG.checks.slice(-20).forEach(c => console.log('  [' + c.type + '] ' + c.msg));
        console.groupEnd();

        // Alert summary
        const status = results.failed.length === 0 ? '✓ ALL TESTS PASSED' : '✗ SOME TESTS FAILED';
        alert('DIAGNOSTICS COMPLETE\\n\\n' + status + '\\n\\n✓ Passed: ' + results.passed.length + '\\n✗ Failed: ' + results.failed.length + '\\n⚠ Warnings: ' + results.warnings.length + '\\n\\nCheck browser console (F12) for full details');

        this.textContent = 'Run Diagnostics';
        this.disabled = false;
        this.style.background = '#222';
    }};
    </script>

</body>
</html>'''

    def _generate_header(self):
        """Generate page header with tab bar and user profile."""
        return '''
<header class="header" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1001;">
    <!-- User Profile Section -->
    <div id="userInfo" style="position: absolute; top: 15px; right: 20px; color: white; font-size: 14px; display: none; z-index: 10;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <img id="userProfilePic" src="" alt="Profile" style="width: 40px; height: 40px; border-radius: 50%; border: 2px solid rgba(255, 255, 255, 0.5); object-fit: cover; cursor: pointer;" onclick="showBuildDate()">
            <div style="text-align: right;">
                <div id="userName" style="font-weight: 600; margin-bottom: 2px; color: white;"></div>
                <div onclick="signOut()" style="font-size: 12px; color: white; opacity: 0.9; cursor: pointer; text-decoration: underline;">Log out</div>
            </div>
        </div>
    </div>

    <div class="header-content">
        <h1>
            <a href="https://rzero.com" target="_blank" style="display: flex; align-items: center;">
                <img src="https://rzero.com/wp-content/themes/rzero/build/images/favicons/favicon.png" alt="R-Zero">
            </a>
            Nationwide ODCV Prospector
        </h1>
        <input type="text" id="global-search" class="global-search" placeholder="Search owner, tenant, brand..." oninput="globalSearch(this.value)" style="margin-left: 40px;">
        <div id="filter-chips" class="filter-chips"></div>
    </div>
</header>
<div class="main-tabs" style="position: fixed; top: 85px; left: 0; right: 0; z-index: 1002; background: white; border-bottom: 1px solid var(--gray-200); padding: 12px 32px;">
    <div style="max-width: 1400px; margin: 0 auto; display: flex; gap: 0; align-items: stretch;">
        <button class="main-tab active" data-tab="portfolios" onclick="switchMainTab('portfolios')"><svg class="tab-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg><span class="tab-label">Portfolios</span></button>
        <button class="main-tab" data-tab="all-buildings" onclick="switchMainTab('all-buildings')"><svg class="tab-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M9 8h1M9 12h1M9 16h1M14 8h1M14 12h1M14 16h1M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"></path></svg><span class="tab-label">Cities</span></button>
        <button class="main-tab" data-tab="methodology" onclick="switchMainTab('methodology')"><svg class="tab-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg><span class="tab-label">Methodology</span></button>
    </div>
</div>
<div id="mainContent" style="display: none;">
<!-- Tutorial Button - UNMISSABLE -->
<button id="tutorial-btn" onclick="startTutorial()" class="tutorial-launch-btn">
    <span class="tutorial-icon">?</span>
    <span class="tutorial-text">Tutorial</span>
    <span class="tutorial-pulse"></span>
</button>'''

    # =========================================================================
    # PORTFOLIO SECTION
    # =========================================================================

    def _generate_portfolio_section(self):
        """Generate the Portfolio section with first 20 cards only (rest load on scroll)."""
        # Only render first 100 portfolio cards - rest load via JS on scroll
        INITIAL_LOAD = 100
        portfolio_cards = []
        for i, p in enumerate(self.portfolios[:INITIAL_LOAD]):
            portfolio_cards.append(self._generate_portfolio_card(p, i))

        # Get total opex for initial display
        total_opex = self.stats.get('total_opex_avoidance', 0)
        def fmt_money_global(n):
            if n >= 1_000_000_000:
                return f'${n/1_000_000_000:.1f}B'
            if n >= 1_000_000:
                return f'${n/1_000_000:.1f}M'
            if n >= 1_000:
                return f'${int(n/1_000)}K'
            return f'${int(n):,}'

        # Calculate totals for rollup stats
        total_valuation = sum(p.get('total_valuation_impact', 0) or 0 for p in self.portfolios)
        total_carbon = sum(p.get('total_carbon_reduction', 0) or 0 for p in self.portfolios)

        def fmt_valuation(n):
            if n >= 1e9: return f'${n/1e9:.1f}B'
            if n >= 1e6: return f'${n/1e6:.1f}M'
            return f'${int(n):,}'

        def fmt_carbon(n):
            if n >= 1e6: return f'{n/1e6:.1f}M'
            if n >= 1e3: return f'{int(n/1e3)}K'
            return f'{int(n):,}'

        def fmt_sqft(n):
            if n >= 1e9: return f'{n/1e9:.1f}B'
            if n >= 1e6: return f'{n/1e6:.0f}M'
            if n >= 1e3: return f'{int(n/1e3)}K'
            return f'{int(n):,}'

        # Calculate totals for column headers
        num_portfolios = len(self.portfolios)
        total_buildings = self.stats.get('total_buildings', 0)
        total_sqft = sum(p.get('total_sqft', 0) or 0 for p in self.portfolios)

        return f'''
<div id="portfolios-tab" class="tab-content active">
<div class="portfolio-section" style="padding: 210px 0 20px 0;">
    <div class="portfolio-sort-header">
        <span class="sort-col" id="header-name" data-col="portfolio" onclick="sortPortfolios('name')" style="cursor:pointer">Portfolio</span>
        <span class="sort-col" id="header-buildings" data-col="buildings" onclick="sortPortfolios('buildings')" style="cursor:pointer" data-total="{total_buildings:,} Total Buildings">Buildings</span>
        <div class="sort-col type-filter-wrapper" id="typeFilterWrapper" data-col="type">
            <span onclick="sortPortfolios('type')" style="cursor:pointer">Type</span>
            <span class="type-active-indicator" onclick="event.stopPropagation(); clearTypeFilter()">×</span>
            <svg class="type-filter-icon" onclick="toggleTypeFilter(event)" style="cursor:pointer" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z"/></svg>
            <div class="type-filter-dropdown" id="typeFilterDropdown" onclick="event.stopPropagation()">
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="owner" onchange="applyTypeFilter()"> Owner</label>
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="owner/occupier" onchange="applyTypeFilter()"> Owner/Occupier</label>
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="owner/operator" onchange="applyTypeFilter()"> Owner/Operator</label>
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="tenant" onchange="applyTypeFilter()"> Tenant</label>
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="tenant_sub_org" onchange="applyTypeFilter()"> TENANT SUB-ORG</label>
                <label class="type-filter-option"><input type="radio" name="type-filter" data-type="property manager" onchange="applyTypeFilter()"> Prop Manager</label>
            </div>
        </div>
        <span class="sort-col" id="header-sqft" data-col="sqft" onclick="sortPortfolios('sqft')" style="cursor:pointer" data-total="{fmt_sqft(total_sqft)} Total Sq Ft">Sq Ft</span>
        <span class="sort-col" id="header-eui" data-col="eui" onclick="sortPortfolios('eui')" style="cursor:pointer">EUI</span>
        <span class="sort-col" id="header-carbon" data-col="carbon" onclick="sortPortfolios('carbon')" style="cursor:pointer" data-total="{fmt_carbon(total_carbon)} Total tCO2e/yr">tCO2e/yr</span>
        <span class="sort-col" id="header-valuation" data-col="valuation" onclick="sortPortfolios('valuation')" style="cursor:pointer" data-total="{fmt_valuation(total_valuation)} Total Val. Impact">Val. Impact</span>
        <span class="sort-col" id="header-opex" data-col="savings" onclick="sortPortfolios('opex')" style="cursor:pointer" data-total="{fmt_money_global(total_opex)} Total Savings/yr (Avoided utility costs + avoided carbon fines)">Savings/yr</span>
    </div>
    <div class="portfolios-list" id="portfolios-list">
        {''.join(portfolio_cards)}
    </div>
    <div id="load-more-trigger" style="height:1px;"></div>
</div>
</div>'''

    def _generate_all_buildings_section(self):
        """Generate the All Buildings tab with filterable table of all buildings."""
        bucket = self.config['aws_bucket']

        # Calculate summary stats
        total_buildings = len(self.all_buildings)
        total_opex = sum(b.get('total_opex', 0) or 0 for b in self.all_buildings)
        total_carbon = sum(b.get('carbon_reduction', 0) or 0 for b in self.all_buildings)
        total_sqft = sum(b.get('sqft', 0) or 0 for b in self.all_buildings)

        # Calculate top 5 cities by OpEx (from portfolio buildings only)
        city_stats = {}
        for p in self.portfolios:
            for b in p.get('buildings', []):
                city = b.get('loc_city', '')
                if city:
                    if city not in city_stats:
                        city_stats[city] = {'count': 0, 'opex': 0}
                    city_stats[city]['count'] += 1
                    city_stats[city]['opex'] += b.get('total_opex', 0) or 0

        # Top 5 cities by building count (most to least)
        top_cities = sorted(city_stats.items(), key=lambda x: x[1]['count'], reverse=True)[:5]

        # Display names for cities (NYC and D.C. to match table)
        city_display_names = {
            'New York': 'NYC',
            'Washington': 'D.C.',
            'Los Angeles': 'LA',
        }

        # Format functions
        def fmt_money(n):
            if n >= 1_000_000_000:
                return f'${n/1_000_000_000:.1f}B'
            if n >= 1_000_000:
                return f'${n/1_000_000:.1f}M'
            if n >= 1_000:
                return f'${int(n/1_000)}K'
            return f'${int(n):,}'

        def fmt_num(n):
            if n >= 1_000_000_000:
                return f'{n/1_000_000_000:.1f}B'
            if n >= 1_000_000:
                return f'{int(n/1_000_000)}M'
            if n >= 1_000:
                return f'{int(n/1_000)}K'
            return f'{int(n):,}'

        # Generate city filter buttons - matching vertical-btn style
        # Gradient: dark navy (most) → light blue (least)
        city_buttons = []
        colors = ['#1e3a5f', '#2d5a87', '#0077cc', '#4a90c2', '#5ba3d9']
        for i, (city, stats) in enumerate(top_cities):
            color = colors[i] if i < len(colors) else colors[-1]
            display_name = city_display_names.get(city, city)
            city_buttons.append(
                f'<button class="vertical-btn city-btn" data-city="{escape(city)}" '
                f'onclick="filterByCity(\'{escape(city)}\')" style="background:{color}">'
                f'{escape(display_name)} <span class="btn-count">({stats["count"]:,})</span>'
                f'<span class="btn-x" onclick="event.stopPropagation(); clearCityFilter()">✕</span>'
                f'</button>'
            )

        return f'''
<div class="city-filter-bar">
    <div class="vertical-filter-inner">
        {''.join(city_buttons)}
    </div>
</div>
<div id="all-buildings-tab" class="tab-content">
<div class="all-buildings-section" style="padding: 210px 0 20px 0;">
    <!-- Cities Table -->
    <div class="cities-header">
        <span></span>
        <span></span>
        <span onclick="sortAllBuildings('address')">Address</span>
        <span onclick="sortAllBuildings('type')">Type</span>
        <span onclick="sortAllBuildings('sqft')">Sq Ft</span>
        <span onclick="sortAllBuildings('eui')">EUI</span>
        <span onclick="sortAllBuildings('owner')">Owner</span>
        <span onclick="sortAllBuildings('tenant')">Tenant</span>
        <span onclick="sortAllBuildings('opex')">OpEx <span id="cities-total-opex" style="font-weight:700;color:#059669;"></span></span>
    </div>
    <div class="cities-container" id="cities-container">
        <div id="cities-rows">
            <div id="cities-list"></div>
        </div>
        <div id="ab-loading-trigger" class="ab-loading-trigger"></div>
    </div>
</div>
</div>
<div id="methodology-tab" class="tab-content" style="display: none; padding-top: 140px;">
    <iframe id="methodology-iframe" src="" style="width: 100%; height: calc(100vh - 140px); border: none;"></iframe>
</div>'''

    def _generate_main_building_table(self):
        """Generate main building table rows (top 1000 by OpEx)."""
        bucket = self.config['aws_bucket']

        # Sort all buildings by total_opex descending, take top 1000
        sorted_buildings = sorted(
            self.all_buildings,
            key=lambda x: safe_float(x.get('total_opex', 0)),
            reverse=True
        )[:1000]

        rows = []
        for rank, b in enumerate(sorted_buildings, 1):
            # Thumbnail - Instagram-style skeleton + fade-in with console logging
            if b.get('image'):
                thumb_filename = b["image"]
                thumb = f'<div class="img-container building-thumb-container"><div class="img-skeleton thumb"></div><img src="{bucket}/thumbnails/{attr_escape(b["image"])}" alt="" class="building-thumb" style="opacity:0;transition:opacity 0.15s" loading="lazy" decoding="async" onload="this.classList.add(\'img-loaded\');this.previousElementSibling.classList.add(\'img-hidden\')" onerror="console.warn(\'[Thumb] ✗\',\'{thumb_filename}\');this.classList.add(\'img-hidden\');this.previousElementSibling.classList.add(\'img-hidden\');this.nextElementSibling.classList.remove(\'img-hidden\')"><div class="building-thumb-placeholder img-hidden">{building_type_icon(b.get("radio_type", ""))}</div></div>'
            else:
                icon = building_type_icon(b.get('radio_type', ''))
                thumb = f'<div class="building-thumb-placeholder">{icon}</div>'

            # Format values
            opex = safe_float(b.get('total_opex', 0))
            carbon = safe_float(b.get('carbon_reduction', 0))

            if opex >= 1_000_000:
                opex_str = f'${opex/1_000_000:.2f}M'
            elif opex >= 1_000:
                opex_str = f'${opex/1_000:.0f}K'
            else:
                opex_str = f'${opex:,.0f}'

            carbon_str = format_carbon(carbon)

            address = escape(b.get('loc_address', 'Unknown'))
            city = escape(b.get('loc_city', ''))
            city_display = {'New York': 'NYC', 'Washington': 'D.C.', 'Los Angeles': 'LA'}.get(city, city)
            state = escape(b.get('loc_state', ''))
            btype = escape(b.get('bldg_type', ''))
            owner_raw = b.get('owner', '') or b.get('org_name', '')
            owner = escape(self._get_org_display_name(owner_raw))
            manager = escape(b.get('manager', ''))
            tenant = escape(b.get('org_tenant', ''))
            sub_org = escape(b.get('sub_org', ''))
            vertical = b.get('bldg_vertical', '')

            # Data attributes for filtering + row click to external URL
            building_id = b.get('id', '')
            building_url = b.get('url', '')
            row_click = f'''onclick="if (!event.target.closest('a, .clickable-link')) window.open('{attr_escape(building_url)}', '_blank')" style="cursor:pointer"''' if building_url else ''
            radio_type = b.get('radio_type', '') or btype
            row = f'''<tr class="building-row" data-id="{attr_escape(building_id)}" data-city="{attr_escape(city)}" data-type="{attr_escape(btype)}" data-radio-type="{attr_escape(radio_type)}" data-owner="{attr_escape(owner)}" data-manager="{attr_escape(manager)}" data-tenant="{attr_escape(tenant)}" data-sub-org="{attr_escape(sub_org)}" data-vertical="{attr_escape(vertical)}" data-opex="{opex}" data-carbon="{carbon}" data-address="{attr_escape(address)}" data-rank="{rank}" {row_click}>
    <td>{thumb}</td>
    <td><span class="rank-badge">#{rank}</span></td>
    <td><span class="building-address">{address}</span><br><span class="city-state">{city_display}, {state}</span></td>
    <td><a href="javascript:void(0)" onclick="event.stopPropagation(); filterPortfoliosByCity('{js_escape(city)}')" class="clickable-link">{city_display}</a></td>
    <td><a href="javascript:void(0)" onclick="event.stopPropagation(); filterByType('{js_escape(btype)}')" class="clickable-link">{btype}</a></td>
    <td><a href="javascript:void(0)" onclick="event.stopPropagation(); filterByOwner('{js_escape(owner)}')" class="clickable-link">{owner}</a></td>
    <td class="money-cell positive">{opex_str}</td>
    <td class="carbon-cell">{carbon_str}</td>
</tr>'''
            rows.append(row)

        return '\n'.join(rows)

    def _generate_portfolio_card(self, portfolio, index):
        """Generate a single portfolio card."""
        p = portfolio
        bucket = self.config['aws_bucket']

        # Logo - eager loading for first 500, lazy for rest
        # Use aws_logo_url if available, otherwise fall back to constructing from logo_file
        logo_url = p.get('aws_logo_url', '')
        if not logo_url and p['logo_file']:
            logo_url = f"{bucket}/logos/{p['logo_file']}"

        # Check if this is a tenant_sub_org with a parent tenant
        classification = p.get('classification', '')
        parent_tenant = p.get('parent_tenant', '')

        org_url = p.get('org_url', '')
        if logo_url:
            # Use thumbnail for faster loading, fall back to full-size on error
            logo_filename = logo_url.split('/')[-1]
            logo_thumb_url = logo_url.replace('/logos/', '/logo-thumbnails/')
            logo_inner = f'<div class="img-container" style="width:48px;height:48px"><div class="img-skeleton logo"></div><img src="{attr_escape(logo_thumb_url)}" data-fullsize="{attr_escape(logo_url)}" alt="" class="org-logo" style="opacity:0;transition:opacity 0.15s" onload="this.classList.add(\'img-loaded\');this.previousElementSibling.classList.add(\'img-hidden\')" onerror="if(this.dataset.fullsize&&this.src!==this.dataset.fullsize){{this.src=this.dataset.fullsize}}else{{console.warn(\'[Logo] ✗\',\'{logo_filename}\');this.classList.add(\'img-hidden\');this.previousElementSibling.classList.add(\'img-hidden\');this.nextElementSibling.classList.remove(\'img-hidden\')}}"><div class="org-logo-placeholder img-hidden">{p["org_name"][0].upper()}</div></div>'
        else:
            logo_inner = f'<div class="org-logo-placeholder">{p["org_name"][0].upper()}</div>'

        if org_url:
            logo_html = f'<a href="{attr_escape(org_url)}" target="_blank" onclick="event.stopPropagation()" class="org-logo-link">{logo_inner}</a>'
        else:
            logo_html = logo_inner


        # Stats
        def fmt_money(n):
            if n >= 1_000_000_000:
                return f'${n/1_000_000_000:.1f}B'
            if n >= 1_000_000:
                return f'${n/1_000_000:.1f}M'
            if n >= 1_000:
                return f'${int(n/1_000)}K'
            return f'${int(n):,}'

        # Calculate total sqft for display
        total_sqft = sum(b.get('sqft', 0) or 0 for b in p['buildings'])

        verticals_data = ','.join(p['verticals'])
        cities_data = ','.join(p.get('cities', []))
        types_data = ','.join(p.get('building_types', []))
        radio_types_data = ','.join(p.get('radio_types', []))
        tenants_data = ','.join(p.get('tenants', []))
        sub_orgs_data = ','.join(p.get('tenant_sub_orgs', []))

        # Median EUI with rating
        median_eui = p.get('median_eui')
        median_eui_benchmark = p.get('median_eui_benchmark')
        if median_eui:
            eui_display = eui_rating(median_eui, median_eui_benchmark)
            # Calculate EUI rating category for filtering
            if median_eui_benchmark and median_eui_benchmark > 0:
                ratio = median_eui / median_eui_benchmark
                if ratio <= 1.0:
                    eui_rating_cat = 'good'
                elif ratio <= 1.2:
                    eui_rating_cat = 'ok'
                else:
                    eui_rating_cat = 'bad'
            else:
                eui_rating_cat = 'ok'
        else:
            eui_display = '-'
            eui_rating_cat = 'ok'

        # Format median sqft
        def fmt_sqft(sqft):
            sqft = sqft or 0
            if sqft >= 1_000_000:
                return f'{sqft/1_000_000:.1f}M'
            elif sqft >= 10_000:
                return f'{sqft/1_000:.0f}K'
            elif sqft > 0:
                return f'{int(sqft):,}'
            return '-'

        sqft_display = fmt_sqft(total_sqft)

        # Display name with parent info for tenant_sub_orgs (on separate line)
        display_name = p.get('display_name', p['org_name'])
        parent_html = ''
        full_title = display_name
        if parent_tenant:
            # Get parent's display_name for cleaner output
            parent_display = parent_tenant
            for port in self.portfolios:
                if port['org_name'] == parent_tenant:
                    parent_display = port.get('display_name', parent_tenant)
                    break
            parent_html = f'<span class="parent-owned">{escape(parent_display)} Owned</span>'
            full_title = f"{display_name} ({parent_display} Owned)"

        return f'''
<div class="portfolio-card" data-idx="{index}" data-org="{attr_escape(p['org_name'])}" data-displayname="{attr_escape(display_name)}" data-verticals="{verticals_data}" data-cities="{cities_data}" data-types="{types_data}" data-radio-types="{radio_types_data}" data-tenants="{attr_escape(tenants_data)}" data-sub-orgs="{attr_escape(sub_orgs_data)}" data-buildings="{p['building_count']}" data-total-buildings="{p['building_count']}" data-sqft="{total_sqft}" data-eui="{p.get('median_eui', 0) or 0}" data-eui-rating="{eui_rating_cat}" data-opex="{p['total_opex_avoidance']}" data-valuation="{p['total_valuation_impact']}" data-carbon="{p['total_carbon_reduction']}" data-classification="{attr_escape(classification)}">
    <div class="portfolio-header" onclick="togglePortfolio(this)">
        <div class="org-logo-stack" data-col="portfolio">
            <span class="org-name-small" title="{attr_escape(full_title)}">{escape(display_name)}{parent_html}</span>
            {logo_html}
        </div>
        <span class="stat-cell building-count" data-col="buildings"><span class="building-count-value">{p['building_count']}</span></span>
        <span class="stat-cell classification-cell classification-{classification.replace('/', '-').replace(' ', '-') if classification else 'none'}" data-col="type">{'TENANT<br>SUB-ORG' if classification == 'tenant_sub_org' else (classification.replace('/', '<br>').replace(' ', '<br>') if classification else '-')}</span>
        <span class="stat-cell sqft-value" data-col="sqft">{sqft_display}</span>
        <span class="stat-cell eui-value" data-col="eui" title="Median EUI of all buildings in this portfolio">{eui_display}</span>
        <span class="stat-cell carbon-value" data-col="carbon">{format_carbon(p['total_carbon_reduction'])}</span>
        <span class="stat-cell valuation-value" data-col="valuation">{fmt_money(p['total_valuation_impact'])}</span>
        <span class="stat-cell opex-value" data-col="savings">{fmt_money(p['total_opex_avoidance'])}</span>
    </div>
    <div class="portfolio-buildings">
        <div class="building-rows-container"></div>
    </div>
</div>'''

    def _generate_building_row(self, b):
        """Generate a building table row."""
        bucket = self.config['aws_bucket']

        # Thumbnail - Instagram-style skeleton + fade-in with console logging
        if b.get('image'):
            thumb_filename = b["image"]
            thumb = f'<div class="img-container building-thumb-container"><div class="img-skeleton thumb"></div><img src="{bucket}/thumbnails/{attr_escape(b["image"])}" alt="" class="building-thumb" style="opacity:0;transition:opacity 0.15s" loading="lazy" decoding="async" onload="this.classList.add(\'img-loaded\');this.previousElementSibling.classList.add(\'img-hidden\')" onerror="console.warn(\'[Thumb] ✗\',\'{thumb_filename}\');this.classList.add(\'img-hidden\');this.previousElementSibling.classList.add(\'img-hidden\');this.nextElementSibling.classList.remove(\'img-hidden\')"><div class="building-thumb-placeholder img-hidden">{building_type_icon(b.get("radio_type", ""))}</div></div>'
        else:
            icon = building_type_icon(b.get('radio_type', ''))
            thumb = f'<div class="building-thumb-placeholder">{icon}</div>'

        # City, State
        city = b.get('loc_city', '') or ''
        state = b.get('loc_state', '') or ''
        city_state = f"{city}, {state}" if city and state else ''

        # Address - strip city/state if present to avoid duplication
        address_text = b['loc_address'] if b['loc_address'] else 'Unknown'
        if city and address_text != 'Unknown':
            # Remove city, state, and zip from end of address
            import re
            pattern = rf',?\s*{re.escape(city)},?\s*{re.escape(state)}[,\s]*\d{{5}}(-\d{{4}})?$'
            address_text = re.sub(pattern, '', address_text, flags=re.IGNORECASE).strip().rstrip(',')
        address_html = f'<span class="building-address">{escape(address_text)}</span>'

        # External link
        if b['id_source_url']:
            address_html += f' <a href="{attr_escape(b["id_source_url"])}" target="_blank" class="external-link" title="View source">↗</a>'

        # Money formatting
        def fmt_money(n):
            if n >= 1_000_000_000:
                return f'${n/1_000_000_000:.1f}B'
            if n >= 1_000_000:
                return f'${n/1_000_000:.1f}M'
            if n >= 1_000:
                return f'${int(n/1_000)}K'
            return f'${int(n):,}'

        radio_type = b.get('radio_type', '')
        building_id = attr_escape(b['id_building'].replace('/', '_').replace('\\', '_'))
        opex_value = b.get('total_opex', 0)
        valuation_value = b.get('valuation_impact', 0)
        carbon_value = b.get('carbon_reduction', 0)
        odcv_pct = b.get('savings_pct_of_energy_cost', 0)
        odcv_pct_display = f"{odcv_pct*100:.0f}%" if odcv_pct else "-"

        # EUI with rating
        site_eui = b.get('energy_site_eui')
        eui_benchmark = b.get('energy_eui_benchmark')
        if site_eui:
            eui_display = eui_rating(site_eui, eui_benchmark)
        else:
            eui_display = "-"

        # Sqft formatting
        def fmt_sqft(sqft):
            sqft = sqft or 0
            if sqft >= 1_000_000:
                return f'{sqft/1_000_000:.1f}M'
            elif sqft >= 10_000:
                return f'{sqft/1_000:.0f}K'
            elif sqft > 0:
                return f'{int(sqft):,}'
            return '-'

        # Building type badge formatter
        def fmt_building_type(btype):
            if not btype:
                return '<span class="type-badge default">-</span>'
            # Map type to CSS class
            btype_lower = btype.lower()
            if 'office' in btype_lower and 'medical' not in btype_lower:
                css_class = 'office'
            elif 'hotel' in btype_lower:
                css_class = 'hotel'
            elif 'retail' in btype_lower or 'consumer' in btype_lower:
                css_class = 'retail'
            elif 'grocery' in btype_lower or 'supercenter' in btype_lower:
                css_class = 'grocery'
            elif 'gym' in btype_lower:
                css_class = 'gym'
            elif 'hospital' in btype_lower or 'clinic' in btype_lower:
                css_class = 'hospital'
            elif 'medical' in btype_lower or 'lab' in btype_lower:
                css_class = 'medical'
            elif 'higher' in btype_lower:
                css_class = 'higher-ed'
            elif 'k-12' in btype_lower or 'k12' in btype_lower:
                css_class = 'k12'
            elif 'library' in btype_lower or 'museum' in btype_lower:
                css_class = 'library'
            elif 'event' in btype_lower:
                css_class = 'event'
            elif 'mixed' in btype_lower:
                css_class = 'mixed'
            elif 'residential' in btype_lower or 'care' in btype_lower:
                css_class = 'residential'
            else:
                css_class = 'default'
            # Replace / with newline for two-word types
            display_text = escape(btype).replace('/', '<br>')
            return f'<span class="type-badge {css_class}">{display_text}</span>'

        sqft_value = b.get('sqft', 0) or 0
        sqft_display = fmt_sqft(sqft_value)
        type_badge = fmt_building_type(b.get('bldg_type', ''))

        return f'''
<div class="building-grid-row" data-id="{building_id}" data-lat="{b['loc_lat'] or ''}" data-lon="{b['loc_lon'] or ''}" data-radio-type="{attr_escape(radio_type)}" data-vertical="{attr_escape(b.get('bldg_vertical', ''))}" data-opex="{opex_value}" data-valuation="{valuation_value}" data-carbon="{carbon_value}" data-sqft="{sqft_value}" data-tenant="{attr_escape(b.get('org_tenant', ''))}" data-sub-org="{attr_escape(b.get('org_tenant_subunit', ''))}" data-address="{attr_escape(address_text)}" onclick="window.location='buildings/{building_id}.html'">
    <div>{thumb}</div>
    <span class="stat-cell">{address_html}</span>
    <span class="stat-cell">{type_badge}</span>
    <span class="stat-cell">{sqft_display}</span>
    <span class="stat-cell">{eui_display}</span>
    <span class="stat-cell carbon-value">{format_carbon(carbon_value)}</span>
    <span class="stat-cell valuation-value">{fmt_money(valuation_value)}</span>
    <span class="stat-cell opex-value">{fmt_money(opex_value)}</span>
</div>'''

    def _generate_map_panel(self):
        """Generate the full map panel (slide-out drawer)."""
        return '''
<div id="map-panel" class="map-panel">
    <div class="map-panel-header">
        <div id="map-panel-title" style="display:flex;align-items:center;gap:12px;font-size:18px;font-weight:600;">All Buildings</div>
        <div class="map-panel-actions">
            <button class="map-panel-reset" onclick="resetMap()" title="Reset map to default view">Reset</button>
            <button class="map-panel-close" onclick="closeMapPanel()">&times;</button>
        </div>
    </div>
    <div style="padding: 12px 20px; display: flex; align-items: center; gap: 8px;">
        <input type="text" id="addressAutocomplete" placeholder="Enter an address" style="flex: 1; padding: 0.75rem; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem;">
        <span class="info-tooltip" data-tooltip="Search for a specific building by entering its address. Select from the suggested addresses that appear below to navigate directly to that building on the map.">i</span>
    </div>
    <div id="full-map"></div>
    <div class="climate-legend">
        <div class="climate-legend-title">Climate</div>
        <div class="climate-legend-items">
            <span><i style="background:#ff4444"></i>Hot</span>
            <span><i style="background:#ffcc44"></i>Warm</span>
            <span><i style="background:#88cc44"></i>Mild</span>
            <span><i style="background:#44cc88"></i>Cool</span>
            <span><i style="background:#4488cc"></i>Cold</span>
        </div>
    </div>
</div>'''

    # =========================================================================
    # SCRIPTS
    # =========================================================================

    def _generate_scripts(self):
        """Generate all JavaScript code."""
        return f'''
<!-- Load data from external files -->
<script src="data/portfolio_cards.js"></script>
<script src="data/filter_data.js"></script>
<script>const PORTFOLIO_BUILDINGS = {{}};</script>
<!-- map_data.js and portfolio building files loaded on-demand -->

<script>
// =============================================================================
// CONFIGURATION
// =============================================================================

const CONFIG = {{
    awsBucket: '{self.config["aws_bucket"]}',
    mapboxToken: '{self.config["mapbox_token"]}'
}};

// =============================================================================
// DIAGNOSTICS SYSTEM - Triple-click anywhere to reveal diagnostics button
// =============================================================================

window.DIAG = {{
    start: Date.now(),
    checks: [],
    errors: [],
    warnings: [],

    log(type, msg, data) {{
        const entry = {{ time: Date.now() - this.start, type, msg, data: data || null }};
        this.checks.push(entry);
        if (type === 'error') this.errors.push(entry);
        if (type === 'warn') this.warnings.push(entry);
        console.log('[DIAG:' + type + '] ' + msg, data || '');
    }},

    report() {{
        console.group('=== DIAGNOSTIC REPORT ===');
        console.log('Total checks:', this.checks.length);
        console.log('Errors:', this.errors.length);
        console.log('Warnings:', this.warnings.length);
        this.errors.forEach(e => console.error(e.msg, e.data));
        console.groupEnd();
        return {{ errors: this.errors, warnings: this.warnings }};
    }}
}};

// Initialize diagnostics on page load
DIAG.log('info', 'Page load started');

// =============================================================================
// AUTOMATED DIAGNOSTICS TEST SUITE
// =============================================================================

window.runDiagnostics = async function() {{
    const results = {{ passed: [], failed: [], warnings: [] }};

    // Test 1: Data files loaded (note: const vars aren't on window, use typeof)
    const dataTests = [
        {{ name: 'PORTFOLIO_CARDS array loaded', check: () => typeof PORTFOLIO_CARDS !== 'undefined' && Array.isArray(PORTFOLIO_CARDS) && PORTFOLIO_CARDS.length > 0 }},
        {{ name: 'FILTER_DATA object loaded', check: () => typeof FILTER_DATA !== 'undefined' && typeof FILTER_DATA === 'object' && Object.keys(FILTER_DATA).length > 0 }},
        {{ name: 'EXPORT_DATA loaded', check: () => typeof EXPORT_DATA !== 'undefined' && Array.isArray(EXPORT_DATA) && EXPORT_DATA.length > 0 }},
        {{ name: 'MAP_DATA loaded or pending', check: () => typeof MAP_DATA === 'undefined' || MAP_DATA === null || Array.isArray(MAP_DATA) }},
        {{ name: 'PORTFOLIO_BUILDINGS object exists', check: () => typeof PORTFOLIO_BUILDINGS !== 'undefined' && typeof PORTFOLIO_BUILDINGS === 'object' }}
    ];

    // Test 2: Firebase
    const firebaseTests = [
        {{ name: 'Firebase SDK loaded', check: () => typeof firebase !== 'undefined' }},
        {{ name: 'Firestore initialized (window.db)', check: () => !!window.db }},
        {{ name: 'Firebase config validated', check: () => window.firebaseConfigValidated === true }},
        {{ name: 'Firebase app initialized', check: () => window.firebaseAppInitialized === true }}
    ];

    // Test 3: External APIs
    const apiTests = [
        {{ name: 'Google Maps SDK loaded', check: () => typeof google !== 'undefined' && !!google.maps }},
        {{ name: 'Google Places API available', check: () => !!(google?.maps?.places?.Autocomplete) }},
        {{ name: 'Mapbox GL loaded', check: () => typeof mapboxgl !== 'undefined' }},
        {{ name: 'CONFIG object valid', check: () => !!CONFIG && !!CONFIG.awsBucket && !!CONFIG.mapboxToken }}
    ];

    // Test 4: DOM Elements exist
    const domIds = [
        'cities-list', 'portfolios-list', 'map-panel', 'loginOverlay',
        'mainContent', 'global-search', 'filter-chips', 'leaderboard-list',
        'tutorial-overlay', 'ab-loading-trigger'
    ];
    const domTests = domIds.map(id => ({{
        name: 'DOM element #' + id,
        check: () => !!document.getElementById(id)
    }}));

    // Test 5: Image loading stats
    const imageTests = [
        {{ name: 'Preload queue exists', check: () => typeof preloadQueue !== 'undefined' }},
        {{ name: 'Preload failure rate <10%', check: () => {{
            if (typeof preloadQueue === 'undefined') return false;
            const stats = preloadQueue.stats;
            if (stats.completed === 0) return true; // No images loaded yet
            return stats.failed < stats.completed * 0.1;
        }} }},
        {{ name: 'Image loader exists', check: () => typeof imageLoader !== 'undefined' }}
    ];

    // Test 6: Functions defined
    const funcTests = [
        {{ name: 'globalSearch function', check: () => typeof globalSearch === 'function' }},
        {{ name: 'applyFilters function', check: () => typeof applyFilters === 'function' }},
        {{ name: 'togglePortfolio function', check: () => typeof togglePortfolio === 'function' }},
        {{ name: 'openMapPanel function', check: () => typeof openMapPanel === 'function' }},
        {{ name: 'initAllBuildingsTable function', check: () => typeof initAllBuildingsTable === 'function' }},
        {{ name: 'loadScript function', check: () => typeof loadScript === 'function' }}
    ];

    // Run all tests
    const allTests = [...dataTests, ...firebaseTests, ...apiTests, ...domTests, ...imageTests, ...funcTests];
    for (const test of allTests) {{
        try {{
            const result = await test.check();
            (result ? results.passed : results.failed).push(test.name);
        }} catch (e) {{
            results.failed.push(test.name + ': ' + e.message);
        }}
    }}

    // Log DIAG errors/warnings to results
    if (DIAG.errors.length > 0) {{
        results.warnings.push('DIAG recorded ' + DIAG.errors.length + ' errors during page load');
    }}

    return results;
}};

// =============================================================================
// GLOBAL ERROR HANDLING - Prevent page crashes from unhandled errors
// =============================================================================

window.onerror = function(msg, url, line, col, error) {{
    console.error('[Global Error]', msg, 'at', url + ':' + line + ':' + col);
    // Log to console but don't crash the page
    return true;  // Prevents default error handling
}};

window.addEventListener('unhandledrejection', function(event) {{
    console.error('[Unhandled Promise Rejection]', event.reason);
    // Prevent the default handling (which would log to console as an error)
    event.preventDefault();
}});

// =============================================================================
// RELIABLE SCRIPT LOADER WITH RETRY + TIMEOUT
// =============================================================================

function loadScript(url, opts = {{}}) {{
    const {{ maxRetries = 3, timeout = 15000 }} = opts;
    return new Promise((resolve, reject) => {{
        let attempts = 0;
        function tryLoad() {{
            attempts++;
            const script = document.createElement('script');
            // Cache bust on retry to avoid cached failures
            script.src = attempts > 1 ? url + '?v=' + Date.now() : url;

            const timer = setTimeout(() => {{
                script.remove();
                if (attempts < maxRetries) {{setTimeout(tryLoad, 500);
                }} else {{
                    reject(new Error('Timeout after ' + maxRetries + ' attempts'));
                }}
            }}, timeout);

            script.onload = () => {{ clearTimeout(timer); resolve(); }};
            script.onerror = () => {{
                clearTimeout(timer);
                script.remove();
                if (attempts < maxRetries) {{setTimeout(tryLoad, 500);
                }} else {{
                    reject(new Error('Failed after ' + maxRetries + ' attempts'));
                }}
            }};
            document.head.appendChild(script);
        }}
        tryLoad();
    }});
}}

// Track which portfolios have had rows rendered
const loadedPortfolios = new Set();

// =============================================================================
// TAB NAVIGATION
// =============================================================================

function initTabs() {{
    document.querySelectorAll('.main-tab').forEach(tab => {{
        tab.addEventListener('click', function() {{
            const tabId = this.dataset.tab;

            // Update tab buttons
            document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            // Update tab content
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            document.getElementById(tabId + '-tab').classList.add('active');
        }});
    }});

    // Check URL hash and switch to correct tab on page load
    const hash = window.location.hash.replace('#', '');
    if (hash === 'all-buildings' || hash === 'cities') {{
        switchMainTab('all-buildings');
    }} else if (hash === 'portfolios') {{
        switchMainTab('portfolios');
    }}
}}

// Switch main tab (called from tab buttons)
function switchMainTab(tabId) {{
    // Update tab buttons
    document.querySelectorAll('.main-tab').forEach(t => {{
        t.classList.toggle('active', t.dataset.tab === tabId);
    }});

    // Toggle body classes for different tabs
    document.body.classList.toggle('all-buildings-active', tabId === 'all-buildings');
    document.body.classList.toggle('methodology-active', tabId === 'methodology');

    // Show/hide tab content
    document.getElementById('portfolios-tab').style.display = tabId === 'portfolios' ? 'block' : 'none';
    document.getElementById('all-buildings-tab').style.display = tabId === 'all-buildings' ? 'block' : 'none';
    document.getElementById('methodology-tab').style.display = tabId === 'methodology' ? 'block' : 'none';

    // Update search placeholder based on tab
    const searchInput = document.getElementById('global-search');
    if (tabId === 'all-buildings') {{
        searchInput.placeholder = 'Search owner, city, building...';
    }} else {{
        searchInput.placeholder = 'Search owner, tenant, brand...';
    }}

    // Initialize All Buildings tab on first view
    if (tabId === 'all-buildings' && !window.allBuildingsInitialized) {{
        initAllBuildingsTable();
        window.allBuildingsInitialized = true;
    }}

    // FIX: Re-filter All Buildings tab when switching to it (applies current vertical/type filters)
    if (tabId === 'all-buildings' && window.allBuildingsInitialized) {{
        doFilterAllBuildings();
    }}

    // Load methodology iframe on first view (embed mode hides header)
    if (tabId === 'methodology' && !window.methodologyLoaded) {{
        document.getElementById('methodology-iframe').src = 'methodology.html?embed=1';
        window.methodologyLoaded = true;
    }}

    // Show/hide tutorial button - only on portfolios tab
    var tutorialBtn = document.getElementById('tutorial-btn');
    if (tutorialBtn) {{
        tutorialBtn.style.display = tabId === 'portfolios' ? 'flex' : 'none';
    }}
}}

// =============================================================================
// ALL BUILDINGS TAB
// =============================================================================

let allBuildingsData = [];
let filteredBuildingsData = [];
let abCurrentIndex = 0;
const AB_BATCH_SIZE = 100;
let abSortColumn = 'opex';
let abSortDirection = 'desc';
let abInfiniteScrollObserver = null;
let abSearchTimeout = null;
let selectedCityFilter = null;

function initAllBuildingsTable() {{
    DIAG.log('info', 'initAllBuildingsTable called');
    const container = document.getElementById('cities-list');
    if (!container) {{
        DIAG.log('error', 'cities-list element not found');
        return;
    }}
    container.innerHTML = '<div class="loading-shimmer" style="text-align:center;padding:40px;border-radius:4px;">Loading buildings...</div>';

    if (EXPORT_DATA && EXPORT_DATA.length > 0) {{
        DIAG.log('info', 'EXPORT_DATA already loaded', {{ count: EXPORT_DATA.length }});
        onAllBuildingsDataLoaded();
    }} else {{
        DIAG.log('info', 'Loading export_data.js...');
        // Large file - use 30s timeout with retry
        loadScript('data/export_data.js', {{ timeout: 30000 }})
            .then(() => {{
                DIAG.log('info', 'export_data.js loaded', {{ count: EXPORT_DATA?.length || 0 }});
                onAllBuildingsDataLoaded();
            }})
            .catch(err => {{
                DIAG.log('error', 'export_data.js failed to load', err);
                console.error('[AllBuildings] Failed to load:', err);
                container.innerHTML = `<div style="text-align:center;padding:40px;color:#c00;">
                    Failed to load building data.
                    <a href="#" onclick="event.preventDefault();initAllBuildingsTable()" style="color:#0066cc;text-decoration:underline;margin-left:8px;">Try again</a>
                </div>`;
            }});
    }}
}}

function onAllBuildingsDataLoaded() {{
    allBuildingsData = EXPORT_DATA;
    // Apply any existing global search filter
    doFilterAllBuildings();
    setupAbInfiniteScroll();
    updateSortIndicators();
}}

function renderAllBuildingsBatch() {{
    const container = document.getElementById('cities-list');
    const trigger = document.getElementById('ab-loading-trigger');

    if (filteredBuildingsData.length === 0) {{
        container.innerHTML = '<div style="text-align:center;padding:40px;color:#666;">No buildings found</div>';
        trigger.style.display = 'none';
        return;
    }}

    const endIndex = Math.min(abCurrentIndex + AB_BATCH_SIZE, filteredBuildingsData.length);
    const fragment = document.createDocumentFragment();

    for (let i = abCurrentIndex; i < endIndex; i++) {{
        const b = filteredBuildingsData[i];
        const row = createAllBuildingsRow(b, i);
        fragment.appendChild(row);
    }}

    container.appendChild(fragment);
    abCurrentIndex = endIndex;

    // Hide trigger and round corners when all loaded
    const citiesContainer = document.getElementById('cities-container');
    if (abCurrentIndex >= filteredBuildingsData.length) {{
        trigger.style.display = 'none';
        citiesContainer.classList.add('fully-loaded');
    }} else {{
        trigger.style.display = 'flex';
        citiesContainer.classList.remove('fully-loaded');
    }}
}}

function createAllBuildingsRow(b, index) {{
    const row = document.createElement('div');
    row.className = 'cities-row';
    row.onclick = function() {{ window.location = 'buildings/' + b.id + '.html?from=cities'; }};

    const thumb = b.image
        ? `<div class="img-container building-thumb-container"><div class="img-skeleton thumb"></div><img src="${{CONFIG.awsBucket}}/thumbnails/${{b.image}}" class="building-thumb" alt="" style="opacity:0;transition:opacity 0.15s" onload="this.classList.add('img-loaded');this.previousElementSibling.classList.add('img-hidden')" onerror="console.warn('[Thumb] ✗',this.src.split('/').pop());this.classList.add('img-hidden');this.previousElementSibling.classList.add('img-hidden');this.nextElementSibling.classList.remove('img-hidden')"><div class="building-thumb-placeholder img-hidden">🏢</div></div>`
        : '<div class="building-thumb-placeholder">🏢</div>';

    const sqft = formatNumber(b.sqft || 0);
    const opex = formatMoney(b.opex || 0);
    const eui = formatEuiRating(b.site_eui, b.eui_benchmark);
    const propertyName = b.property_name || '';

    // Strip zip code, city, and state from address to get just street
    let addrClean = (b.address || '').replace(/,?\s*\d{{5}}(-\d{{4}})?$/, '').trim();
    if (b.city && b.state) {{
        // Remove ", City, ST" or ", City ST" pattern from end (handles both comma and space before state)
        const cityStatePattern = new RegExp(',?\\\\s*' + b.city.replace(/[.*+?^${{}}()|[\\]\\\\]/g, '\\\\$&') + '[,\\\\s]+' + b.state + '\\\\s*$', 'i');
        addrClean = addrClean.replace(cityStatePattern, '').trim();
    }}

    // Format city name for display (use city column, not from address)
    let cityDisplay = b.city || '';
    if (cityDisplay === 'New York') cityDisplay = 'NYC';
    else if (cityDisplay === 'Washington') cityDisplay = 'D.C.';
    else if (cityDisplay === 'Los Angeles') cityDisplay = 'LA';

    // Combine street + formatted city
    const addrLine = cityDisplay ? addrClean + ', ' + cityDisplay : addrClean;

    const extLink = b.url ? `<a href="${{b.url}}" target="_blank" onclick="event.stopPropagation()" style="color:var(--primary);font-weight:bold;font-size:11px;background:rgba(0,102,204,0.15);padding:1px 4px;border-radius:3px;text-decoration:none">↗</a>` : '';
    const hqBadge = b.hq_org ? `<span class="hq-badge">${{escapeHtml(b.hq_org)}} HQ</span>` : '';

    row.innerHTML = `
        <div>${{thumb}}</div>
        <span class="ext-link-cell">${{extLink}}</span>
        <div class="addr"><span class="addr-main">${{escapeHtml(addrLine)}}</span><span class="addr-sub">${{escapeHtml(propertyName)}}</span></div>
        <div class="cell">${{escapeHtml(b.type || '-')}}${{hqBadge}}</div>
        <div class="cell">${{sqft}}</div>
        <div class="cell">${{eui}}</div>
        <div class="cell">${{escapeHtml(b.owner || '-')}}</div>
        <div class="cell">${{escapeHtml(b.tenant || '-')}}</div>
        <div class="cell">${{opex}}</div>
    `;

    return row;
}}

function setupAbInfiniteScroll() {{
    const trigger = document.getElementById('ab-loading-trigger');

    if (abInfiniteScrollObserver) {{
        abInfiniteScrollObserver.disconnect();
    }}

    abInfiniteScrollObserver = new IntersectionObserver((entries) => {{
        if (entries[0].isIntersecting && abCurrentIndex < filteredBuildingsData.length) {{
            renderAllBuildingsBatch();
        }}
    }}, {{ threshold: 0.1 }});

    abInfiniteScrollObserver.observe(trigger);
}}

// Debounced filter function
function filterAllBuildings() {{
    clearTimeout(abSearchTimeout);
    abSearchTimeout = setTimeout(doFilterAllBuildings, 50);
}}

function doFilterAllBuildings() {{
    // DEBUG: Log filter state
    console.log('=== doFilterAllBuildings DEBUG ===');
    console.log('selectedBuildingType:', selectedBuildingType);
    console.log('activeVertical:', activeVertical);
    console.log('allBuildingsData length:', allBuildingsData?.length);

    // Filter by selected city card AND global search
    let debugMatches = 0;
    let debugMisses = 0;
    let sampleTypes = new Set();
    filteredBuildingsData = allBuildingsData.filter(b => {{
        // FIX: Vertical filter - match Portfolio tab behavior
        if (activeVertical !== 'all' && b.vertical !== activeVertical) return false;

        // FIX: Building type filter - match Portfolio tab behavior
        if (selectedBuildingType) {{
            sampleTypes.add(b.type);
            if (b.type !== selectedBuildingType) {{
                debugMisses++;
                return false;
            }}
            debugMatches++;
        }}

        // City filter
        if (selectedCityFilter && b.city !== selectedCityFilter) return false;

        // Global search filter
        if (globalQuery) {{
            const searchFields = [
                b.address || '',
                b.city || '',
                b.state || '',
                b.type || '',
                b.owner || '',
                b.sub_org || '',
                b.property_name || '',
                b.tenant || '',
                b.property_manager || ''
            ].join(' ').toLowerCase();
            if (!searchFields.includes(globalQuery)) return false;
        }}
        return true;
    }});

    // DEBUG: Log filter results
    if (selectedBuildingType) {{
        console.log('DEBUG type matches:', debugMatches);
        console.log('DEBUG type misses:', debugMisses);
        console.log('DEBUG sample types in data:', Array.from(sampleTypes).slice(0, 10));
        console.log('DEBUG filteredBuildingsData length:', filteredBuildingsData.length);
    }}

    // Apply current sort
    sortFilteredBuildings();

    // Reset and re-render
    abCurrentIndex = 0;
    document.getElementById('cities-list').innerHTML = '';

    // Show the loading trigger again (it may have been hidden)
    const trigger = document.getElementById('ab-loading-trigger');
    const citiesContainer = document.getElementById('cities-container');
    if (trigger) trigger.style.display = 'flex';
    if (citiesContainer) citiesContainer.classList.remove('fully-loaded');

    renderAllBuildingsBatch();

    // Update stats
    updateAllBuildingsStats();
}}

function filterByCity(city) {{
    // Check if this city is already selected - click to deselect
    const currentlySelected = document.querySelector('.city-btn.selected');
    const isAlreadySelected = currentlySelected &&
        currentlySelected.dataset.city === city;

    if (isAlreadySelected) {{
        // Deselect - show all buildings
        clearCityFilter();
        return;
    }}

    // Select this city
    selectedCityFilter = city;
    document.querySelectorAll('.city-btn').forEach(c => {{
        c.classList.remove('selected');
        if (c.dataset.city === city) {{
            c.classList.add('selected');
        }}
    }});

    doFilterAllBuildings();
}}

function clearCityFilter() {{
    selectedCityFilter = null;
    document.querySelectorAll('.city-btn').forEach(c => c.classList.remove('selected'));
    doFilterAllBuildings();
}}

function clearAllBuildingsFilters() {{
    // Clear city card selection (but keep global search)
    clearCityFilter();
}}

function sortAllBuildings(column) {{
    if (abSortColumn === column) {{
        abSortDirection = abSortDirection === 'asc' ? 'desc' : 'asc';
    }} else {{
        abSortColumn = column;
        abSortDirection = column === 'opex' || column === 'carbon' || column === 'sqft' || column === 'eui' ? 'desc' : 'asc';
    }}

    updateSortIndicators();
    sortFilteredBuildings();
    abCurrentIndex = 0;
    document.getElementById('cities-list').innerHTML = '';
    renderAllBuildingsBatch();
}}

function updateSortIndicators() {{
    // Remove all sort classes
    document.querySelectorAll('.ab-table th').forEach(th => {{
        th.classList.remove('sort-asc', 'sort-desc');
    }});

    // Add sort class to current column
    const currentTh = document.querySelector(`.ab-table th[onclick*="${{abSortColumn}}"]`);
    if (currentTh) {{
        currentTh.classList.add(abSortDirection === 'asc' ? 'sort-asc' : 'sort-desc');
    }}
}}

function sortFilteredBuildings() {{
    const col = abSortColumn;
    const dir = abSortDirection === 'asc' ? 1 : -1;

    filteredBuildingsData.sort((a, b) => {{
        let valA, valB;

        // Numeric columns
        if (col === 'sqft') {{
            valA = a.sqft || 0;
            valB = b.sqft || 0;
        }} else if (col === 'eui') {{
            valA = a.site_eui || 0;
            valB = b.site_eui || 0;
        }} else if (col === 'opex') {{
            valA = a.opex || 0;
            valB = b.opex || 0;
        }} else if (col === 'carbon') {{
            valA = a.carbon || 0;
            valB = b.carbon || 0;
        }} else if (col === 'valuation') {{
            valA = a.valuation || 0;
            valB = b.valuation || 0;
        }} else {{
            // String columns: address, type, owner, tenant
            valA = (a[col] || '').toString().toLowerCase();
            valB = (b[col] || '').toString().toLowerCase();
        }}

        // FIXED: Use proper comparison that handles equal values and string/number types
        if (typeof valA === 'string') {{
            return valA.localeCompare(valB) * dir;
        }}
        return (valA - valB) * dir;
    }});
}}

function updateAllBuildingsStats() {{
    // Calculate total OpEx for filtered buildings
    const totalOpex = filteredBuildingsData.reduce((sum, b) => sum + (b.opex || 0), 0);
    const totalEl = document.getElementById('cities-total-opex');
    if (totalEl) {{
        totalEl.textContent = '(' + formatMoney(totalOpex) + ')';
    }}
}}

function formatMoney(n) {{
    n = parseFloat(n) || 0;
    if (n >= 1000000000) return '$' + (n / 1000000000).toFixed(1) + 'B';
    if (n >= 1000000) return '$' + (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return '$' + Math.round(n / 1000) + 'K';
    return '$' + Math.round(n);
}}

function formatNumber(n) {{
    if (n >= 1000000000) return (n / 1000000000).toFixed(1) + 'B';
    if (n >= 1000000) return Math.round(n / 1000000) + 'M';
    if (n >= 1000) return Math.round(n / 1000) + 'K';
    return n.toLocaleString();
}}

function formatCarbon(n) {{
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return Math.round(n / 1000) + 'K';
    return Math.round(n);
}}

function escapeHtml(str) {{
    if (!str) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}}

// =============================================================================
// SAFE VALUE UTILITIES - Robust handling of missing/invalid data
// =============================================================================

/**
 * Safely parse a value to float, with robust null/NaN/undefined handling.
 * @param {{*}} val - Value to parse
 * @param {{number}} fallback - Default value if parsing fails (default: 0)
 * @returns {{number}} Parsed number or fallback
 */
function safeParseFloat(val, fallback) {{
    if (fallback === undefined) fallback = 0;
    if (val === null || val === undefined || val === '' || val === 'NaN' || val === 'undefined' || val === 'null') {{
        return fallback;
    }}
    const n = parseFloat(val);
    return (isNaN(n) || !isFinite(n)) ? fallback : n;
}}

/**
 * Safely display a value with formatting, showing placeholder for missing/invalid data.
 * @param {{*}} val - Value to display
 * @param {{function}} formatter - Optional formatting function
 * @param {{string}} placeholder - Text to show for missing data (default: '--')
 * @returns {{string}} Formatted value or placeholder
 */
function safeDisplay(val, formatter, placeholder) {{
    placeholder = placeholder || '--';
    if (val === null || val === undefined || val === '' || val === 'NaN' || val === 'undefined') {{
        return placeholder;
    }}
    if (typeof val === 'number' && (isNaN(val) || !isFinite(val))) {{
        return placeholder;
    }}
    try {{
        return formatter ? formatter(val) : String(val);
    }} catch (e) {{
        console.warn('[safeDisplay] Format error:', e);
        return placeholder;
    }}
}}

// =============================================================================
// FILTERS - OPTIMIZED
// =============================================================================

let activeVertical = 'all';
let selectedBuildingType = null;
let activeEuiFilter = 'all';  // EUI filter state for building rows
let mapUpdateTimeout = null;
// Data loading state for lazy-loaded files (EXPORT_DATA used for All Buildings tab and CSV export)
let dataLoadState = {{
    exportData: 'pending'  // 'pending' | 'loading' | 'loaded' | 'error'
}};
let currentSortCol = 'opex';      // Track current sort column
let currentSortAsc = false;       // Track sort direction (false = descending)

// Update header tooltips using pre-computed HEADER_TOTALS (instant lookup, no EXPORT_DATA needed)
function updateHeaderTooltips() {{
    // Build lookup key from current filter state
    const typeKey = selectedBuildingType || '';
    const vertKey = activeVertical || 'all';
    const key = `${{typeKey}}|${{vertKey}}`;

    // Look up pre-computed totals (falls back to global totals if key not found)
    const totals = HEADER_TOTALS[key] || HEADER_TOTALS['|all'] || {{count: 0, sqft: 0, opex: 0, valuation: 0, carbon: 0}};

    const headerBuildings = document.getElementById('header-buildings');
    const headerSqft = document.getElementById('header-sqft');
    const headerValuation = document.getElementById('header-valuation');
    const headerCarbon = document.getElementById('header-carbon');
    const headerOpex = document.getElementById('header-opex');

    if (headerBuildings) headerBuildings.dataset.total = totals.count.toLocaleString() + ' Total Buildings';
    if (headerSqft) headerSqft.dataset.total = formatSqftJS(totals.sqft) + ' Total Sq Ft';
    if (headerValuation) headerValuation.dataset.total = formatMoneyJS(totals.valuation) + ' Total Val. Impact';
    if (headerCarbon) headerCarbon.dataset.total = formatCarbonJS(totals.carbon) + ' Total tCO2e/yr';
    if (headerOpex) headerOpex.dataset.total = formatMoneyJS(totals.opex) + ' Total Savings/yr (Avoided utility costs + avoided carbon fines)';
}}

function applyFilters() {{
    // Get classification filter
    const selectedClassification = (() => {{
        const sel = document.querySelector('#typeFilterDropdown input[name="type-filter"]:checked');
        return sel ? sel.dataset.type : 'all';
    }})();

    const container = document.getElementById('portfolios-list');
    if (!container) return;

    // Filter from PORTFOLIO_CARDS data (all portfolios), not DOM
    const filtered = [];
    let totalOpex = 0, totalValuation = 0, totalCarbon = 0, totalBuildings = 0, totalSqft = 0;

    PORTFOLIO_CARDS.forEach((p, idx) => {{
        const agg = FILTER_DATA[idx] || {{}};
        let count = 0, opex = 0, valuation = 0, carbon = 0, sqft = 0;

        for (const [key, vals] of Object.entries(agg)) {{
            const parts = key.split('|');
            if (parts.length !== 2) continue;
            const [t, v] = parts;
            if (selectedBuildingType && t !== selectedBuildingType) continue;
            if (activeVertical !== 'all' && v !== activeVertical) continue;
            if (vals && typeof vals === 'object') {{
                count += vals.count || 0;
                opex += vals.opex || 0;
                valuation += vals.valuation || 0;
                carbon += vals.carbon || 0;
                sqft += vals.sqft || 0;
            }}
        }}

        // Search filter - use searchMatchingIndices if available (populated by globalSearch)
        if (searchMatchingIndices !== null) {{
            if (!searchMatchingIndices.includes(p.idx)) count = 0;
        }} else if (globalQuery) {{
            const searchStr = [p.org_name, p.display_name, ...(p.search_aliases || [])].join(' ').toLowerCase();
            if (!searchStr.includes(globalQuery)) count = 0;
        }}

        // Classification filter
        if (selectedClassification !== 'all') {{
            const cls = (p.classification || '').toLowerCase().trim();
            if (!cls || cls !== selectedClassification.toLowerCase().trim()) count = 0;
        }}

        if (count > 0) {{
            filtered.push({{ p, idx, count, opex, valuation, carbon, sqft, eui: p.median_eui || 0 }});
            totalOpex += opex;
            totalValuation += valuation;
            totalCarbon += carbon;
            totalBuildings += count;
            totalSqft += sqft;
        }}
    }});

    // Sort filtered array
    filtered.sort((a, b) => {{
        let aVal, bVal;
        if (currentSortCol === 'name') {{
            aVal = (a.p.display_name || '').toLowerCase();
            bVal = (b.p.display_name || '').toLowerCase();
        }} else if (currentSortCol === 'buildings') {{
            aVal = a.count || 0;
            bVal = b.count || 0;
        }} else if (currentSortCol === 'sqft') {{
            aVal = a.sqft || 0;
            bVal = b.sqft || 0;
        }} else if (currentSortCol === 'eui') {{
            const aHasEui = a.eui && a.eui > 0;
            const bHasEui = b.eui && b.eui > 0;
            if (!aHasEui && !bHasEui) return 0;
            if (!aHasEui) return 1;
            if (!bHasEui) return -1;
            aVal = a.eui;
            bVal = b.eui;
        }} else if (currentSortCol === 'valuation') {{
            aVal = a.valuation || 0;
            bVal = b.valuation || 0;
        }} else if (currentSortCol === 'carbon') {{
            aVal = a.carbon || 0;
            bVal = b.carbon || 0;
        }} else {{
            aVal = a.opex || 0;
            bVal = b.opex || 0;
        }}
        if (typeof aVal === 'string') {{
            return currentSortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }}
        return currentSortAsc ? (aVal - bVal) : (bVal - aVal);
    }});

    // Clear and re-render from PORTFOLIO_CARDS data with filtered values
    container.innerHTML = '';
    filtered.forEach(f => {{
        const cardHtml = renderPortfolioCard(f.p, {{
            count: f.count,
            sqft: f.sqft,
            opex: f.opex,
            valuation: f.valuation,
            carbon: f.carbon
        }});
        container.insertAdjacentHTML('beforeend', cardHtml);
    }});

    // Update counts
    const countEl = document.getElementById('visible-count');
    if (countEl) countEl.textContent = filtered.length;

    // Update rollup stats
    const rollupValEl = document.getElementById('rollup-valuation');
    const rollupCarbonEl = document.getElementById('rollup-carbon');
    const rollupOpexEl = document.getElementById('rollup-opex');
    if (rollupValEl) rollupValEl.textContent = formatMoneyJS(totalValuation);
    if (rollupCarbonEl) rollupCarbonEl.textContent = formatCarbonJS(totalCarbon);
    if (rollupOpexEl) rollupOpexEl.textContent = formatMoneyJS(totalOpex);

    updateHeaderTooltips();
}}

function selectVertical(v, preserveBuildingType = false) {{
    // Toggle behavior: clicking same vertical deselects it (returns to 'all')
    if (activeVertical === v && v !== 'all') {{
        v = 'all';
    }}
    activeVertical = v;
    document.querySelectorAll('.vertical-btn').forEach(b => {{
        b.classList.toggle('selected', b.dataset.vertical === v);
    }});
    // Show/hide building type buttons based on vertical
    document.querySelectorAll('.building-type-btn').forEach(btn => {{
        const btnVertical = btn.dataset.vertical || '';
        if (v === 'all' || btnVertical === v) {{
            btn.classList.remove('hidden');
        }} else {{
            btn.classList.add('hidden');
            btn.classList.remove('selected');
        }}
    }});
    // Clear building type when switching verticals (unless preserving for dropdown selection)
    if (!preserveBuildingType) {{
        selectedBuildingType = null;
        document.querySelectorAll('.building-type-btn').forEach(b => b.classList.remove('selected'));
        document.querySelectorAll('.vertical-dropdown input[type="radio"]').forEach(r => r.checked = false);
        document.querySelectorAll('#typeFilterDropdown input[name="type-filter"]').forEach(r => r.checked = false);
        const chip = document.getElementById('building-type-chip');
        if (chip) chip.classList.remove('visible');
    }}

    applyFilters();
    // Sync to All Buildings tab
    if (window.allBuildingsInitialized) doFilterAllBuildings();
}}

function toggleBuildingType(btn) {{
    const wasSelected = btn.classList.contains('selected');
    document.querySelectorAll('.building-type-btn').forEach(b => b.classList.remove('selected'));
    if (!wasSelected) {{
        btn.classList.add('selected');
        selectedBuildingType = btn.dataset.type;
    }} else {{
        selectedBuildingType = null;
    }}
    applyFilters();
    // Sync to All Buildings tab
    if (window.allBuildingsInitialized) doFilterAllBuildings();

    // Update filter chip
    const chip = document.getElementById('building-type-chip');
    if (chip) {{
        if (selectedBuildingType) {{
            chip.querySelector('.chip-text').textContent = selectedBuildingType;
            chip.classList.add('visible');
        }} else {{
            chip.classList.remove('visible');
        }}
    }}
}}

function clearBuildingTypeFilter() {{
    document.querySelectorAll('.building-type-btn').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('.vertical-btn').forEach(b => b.classList.remove('selected'));
    document.querySelectorAll('.vertical-dropdown input[type="radio"]').forEach(r => r.checked = false);
    selectedBuildingType = null;
    activeVertical = 'all';
    const chip = document.getElementById('building-type-chip');
    if (chip) chip.classList.remove('visible');
    applyFilters();
    // Sync to All Buildings tab
    if (window.allBuildingsInitialized) doFilterAllBuildings();
}}

function clearVerticalBuildingTypeFilter(vertical) {{
    // Remove selected class from the vertical button
    const verticalBtn = document.querySelector(`.vertical-btn[data-vertical="${{vertical}}"]`);
    if (verticalBtn) {{
        verticalBtn.classList.remove('selected');
    }}

    // Clear the radio selection for this vertical's dropdown
    const dropdown = document.getElementById('dropdown-' + vertical);
    if (dropdown) {{
        dropdown.querySelectorAll('input[type="radio"]').forEach(r => r.checked = false);
    }}

    // Clear the building type filter
    selectedBuildingType = null;

    // FIX: Also reset vertical to 'all' when X is clicked
    activeVertical = 'all';

    // FIX: Update All Buildings tab if initialized
    if (window.allBuildingsInitialized) {{
        doFilterAllBuildings();
    }}

    applyFilters();
}}

function scheduleMapUpdate() {{
    clearTimeout(mapUpdateTimeout);
    mapUpdateTimeout = setTimeout(() => {{
        const mapPanel = document.getElementById('map-panel');
        if (mapPanel && mapPanel.classList.contains('open')) {{
            updateMapData();
        }}
    }}, 300);
}}

function updatePortfolioStats() {{
    applyFilters();
}}

function formatMoneyJS(n) {{
    if (n >= 1000000000) return '$' + (n/1000000000).toFixed(1) + 'B';
    if (n >= 1000000) return '$' + (n/1000000).toFixed(1) + 'M';
    if (n >= 1000) return '$' + Math.round(n/1000) + 'K';
    return '$' + Math.round(n);
}}

function formatCarbonJS(n) {{
    if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
    if (n >= 1000) return Math.round(n/1000) + 'K';
    return Math.round(n);
}}

function formatSqftJS(n) {{
    if (!n || n <= 0) return '-';
    if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
    if (n >= 10000) return Math.round(n/1000) + 'K';
    return Math.round(n).toLocaleString();
}}

function formatEuiRating(eui, benchmark) {{
    if (!eui) return '-';
    const euiRounded = Math.round(eui);
    if (!benchmark || benchmark === 0) return euiRounded;
    const ratio = eui / benchmark;
    if (ratio <= 1.0) return `<span class="eui-good">${{euiRounded}} (Good)</span>`;
    if (ratio <= 1.2) return `<span class="eui-ok">${{euiRounded}} (OK)</span>`;
    return `<span class="eui-bad">${{euiRounded}} (Bad)</span>`;
}}

function formatTypeBadge(type) {{
    if (!type) return '<span class="type-badge type-badge--gray-xlight">-</span>';
    const t = type.toLowerCase();
    let cls = 'type-badge--gray-light';
    if (t.includes('office') && !t.includes('medical')) cls = 'type-badge--blue';
    else if (t.includes('hotel')) cls = 'type-badge--blue-light';
    else if (t.includes('hospital') || t.includes('clinic')) cls = 'type-badge--blue';
    else if (t.includes('medical') || t.includes('lab')) cls = 'type-badge--blue-light';
    else if (t.includes('higher')) cls = 'type-badge--gray-dark';
    else if (t.includes('k-12') || t.includes('k12')) cls = 'type-badge--gray-mid';
    else if (t.includes('gym')) cls = 'type-badge--blue-light';
    else if (t.includes('retail') || t.includes('consumer')) cls = 'type-badge--gray-light';
    else if (t.includes('grocery') || t.includes('supercenter')) cls = 'type-badge--gray-mid';
    else if (t.includes('library') || t.includes('museum')) cls = 'type-badge--gray-dark';
    else if (t.includes('event')) cls = 'type-badge--gray-mid';
    else if (t.includes('mixed')) cls = 'type-badge--blue-light';
    else if (t.includes('residential') || t.includes('care')) cls = 'type-badge--gray-xlight';
    // Split on / for two lines
    const display = type.replace(/\\//g, '<br>');
    return `<span class="type-badge ${{cls}}">${{display}}</span>`;
}}

// Global search
let globalQuery = '';
let selectedOwner = '';
let searchMatchingIndices = null;  // null = show all, array = show only these
let filterTimeout = null;

function globalSearch(query) {{
    globalQuery = query.toLowerCase().trim();

    if (!globalQuery) {{
        searchMatchingIndices = null;
    }} else {{
        searchMatchingIndices = [];
        const isShort = globalQuery.length <= 3;

        PORTFOLIO_CARDS.forEach(p => {{
            const orgLower = (p.org_name || '').toLowerCase();
            const displayLower = (p.display_name || '').toLowerCase();

            let match = false;
            if (isShort) {{
                // Short queries: strict matching
                const displayWords = displayLower.split(/\s+/);
                const orgWords = orgLower.split(/[\s()]+/);
                const aliasExact = (p.search_aliases || []).some(a => a && typeof a === 'string' && a.toLowerCase() === globalQuery);
                match = displayLower.startsWith(globalQuery) ||
                        displayWords.some(w => w.startsWith(globalQuery)) ||
                        orgWords.some(w => w === globalQuery) ||
                        orgLower.includes('(' + globalQuery + ')') ||
                        aliasExact;  // NYC, LA, SF, etc.
            }} else {{
                // Long queries: search all fields (with null-safe element checks)
                const tenantMatch = (p.tenants || []).some(t => t && typeof t === 'string' && t.toLowerCase().includes(globalQuery));
                const subOrgMatch = (p.tenant_sub_orgs || []).some(s => s && typeof s === 'string' && s.toLowerCase().includes(globalQuery));
                const ownerMatch = (p.owners || []).some(o => o && typeof o === 'string' && o.toLowerCase().includes(globalQuery));
                const managerMatch = (p.managers || []).some(m => m && typeof m === 'string' && m.toLowerCase().includes(globalQuery));

                if (subOrgMatch) {{}}

                match = orgLower.includes(globalQuery) ||
                        displayLower.includes(globalQuery) ||
                        tenantMatch || subOrgMatch || ownerMatch || managerMatch;
            }}

            if (match) searchMatchingIndices.push(p.idx);
        }});
    }}

    // Debounce search input only (50ms - fast but prevents every keystroke)
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(() => {{
        requestAnimationFrame(() => {{
            applySearchResults();
            // Also filter All Buildings tab if initialized
            if (window.allBuildingsInitialized) {{
                doFilterAllBuildings();
            }}
        }});
    }}, 50);
}}

function applySearchResults() {{
    // 100% data-based: applyFilters() uses searchMatchingIndices to filter data, then re-renders
    applyFilters();
}}

// Filter by building type (called from table clicks)
function filterByType(type) {{
    // Look up vertical from HEADER_TOTALS data (keys are "type|vertical")
    let vertical = 'Commercial';
    for (const key of Object.keys(HEADER_TOTALS)) {{
        if (key.startsWith(type + '|') && !key.endsWith('|all')) {{
            vertical = key.split('|')[1];
            break;
        }}
    }}
    selectedBuildingType = type;
    selectVertical(vertical, true);
    applyFilters();
    if (window.allBuildingsInitialized) doFilterAllBuildings();
}}

// Filter portfolios by city (called from table clicks)
function filterPortfoliosByCity(city) {{
    // Put city in search box
    const searchBox = document.getElementById('global-search');
    if (searchBox) {{
        searchBox.value = city;
        globalSearch(city);
    }}
}}

// Filter by owner (called from table clicks)
function filterByOwner(owner) {{
    // Put owner in search box
    const searchBox = document.getElementById('global-search');
    if (searchBox) {{
        searchBox.value = owner;
        globalSearch(owner);
    }}
}}

// Legacy function - redirects to optimized version
function applyAllFilters() {{
    applyFilters();
}}

function updateFilterChips() {{
    const container = document.getElementById('filter-chips');
    let chips = '';

    if (selectedOwner) {{
        chips += `<span class="filter-chip">${{selectedOwner}} <span class="remove" onclick="clearOwnerFilter()">✕</span></span>`;
    }}

    container.innerHTML = chips;
}}

function clearOwnerFilter() {{
    selectedOwner = '';
    document.querySelectorAll('.opp-tile').forEach(t => t.classList.remove('selected'));
    updateFilterChips();
    applyAllFilters();
}}

function clearAllFilters() {{
    activeVertical = 'all';
    selectedOwner = '';
    globalQuery = '';
    selectedBuildingType = null;

    // Reset vertical buttons
    document.querySelectorAll('.vertical-btn').forEach(b => b.classList.remove('selected'));
    document.querySelector('.vertical-btn[data-vertical="all"]')?.classList.add('selected');
    // Reset building type buttons and radio buttons
    document.querySelectorAll('.building-type-btn').forEach(b => {{
        b.classList.remove('selected');
        b.classList.remove('hidden');
    }});
    document.querySelectorAll('.vertical-dropdown input[type="radio"]').forEach(r => r.checked = false);
    // Reset typeFilterDropdown radio buttons
    document.querySelectorAll('#typeFilterDropdown input[name="type-filter"]').forEach(r => r.checked = false);

    const cityFilter = document.getElementById('city-filter');
    const typeFilter = document.getElementById('type-filter');
    if (cityFilter) cityFilter.value = 'all';
    if (typeFilter) typeFilter.value = 'all';
    const searchEl = document.getElementById('global-search');
    if (searchEl) searchEl.value = '';
    document.querySelectorAll('.opp-tile').forEach(t => t.classList.remove('selected'));
    // Clear any inline display styles (fixes conflict with applyAllFilters)
    document.querySelectorAll('.portfolio-card').forEach(card => card.style.display = '');

    updateFilterChips();
    applyFilters();
}}

// =============================================================================
// CSV EXPORT FUNCTIONS
// =============================================================================

// Toggle export dropdown menu
function toggleExportMenu(event) {{
    event.stopPropagation();
    const menu = document.getElementById('export-menu');
    menu.classList.toggle('show');

    // Close menu when clicking elsewhere
    const closeMenu = (e) => {{
        if (!e.target.closest('.export-dropdown')) {{
            menu.classList.remove('show');
            document.removeEventListener('click', closeMenu);
        }}
    }};
    document.addEventListener('click', closeMenu);
}}

// Load export data on demand
let EXPORT_DATA = null;

function loadAllBuildingsForExport() {{
    if (EXPORT_DATA) return Promise.resolve(EXPORT_DATA);
    // Large file - use 30s timeout with retry
    return loadScript('data/export_data.js', {{ timeout: 30000 }})
        .then(() => EXPORT_DATA)
        .catch(err => {{
            console.error('[Export] Failed to load export data:', err);
            return []; // Return empty array on failure
        }});
}}

// Helper: Download CSV
function downloadCSV(rows, filename) {{
    const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\\n');
    const blob = new Blob([csv], {{ type: 'text/csv;charset=utf-8;' }});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    document.getElementById('export-menu').classList.remove('show');
}}

// Export All Buildings - NOW LOADS DATA ON DEMAND
async function exportAllBuildingsCSV() {{
    // Load data on demand when user clicks export
    const data = await loadAllBuildingsForExport();
    if (!data || !data.length) {{ alert('Failed to load data for export.'); return; }}

    const headers = ['Rank', 'Address', 'City', 'State', 'Building Type', 'Owner', 'Square Footage', 'Year Built', 'OpEx Savings ($)', 'Valuation Impact ($)', 'Carbon Reduction (tCO2e)', 'Site EUI', 'Vertical'];
    const rows = [headers];

    data.forEach((b, i) => {{
        rows.push([
            i + 1,
            b.address,
            b.city,
            b.state,
            b.type,
            b.owner,
            b.sqft,
            b.year_built || '',
            (b.opex || 0).toFixed(2),
            (b.valuation || 0).toFixed(2),
            (b.carbon || 0).toFixed(2),
            b.site_eui ? b.site_eui.toFixed(1) : '',
            b.vertical
        ]);
    }});

    downloadCSV(rows, 'all_buildings.csv');
}}

// Export Filtered Results (visible rows from the table)
function exportFilteredCSV() {{
    const headers = ['Rank', 'Address', 'City', 'Building Type', 'Owner', 'OpEx Savings', 'Carbon Reduction'];
    const rows = [headers];

    document.querySelectorAll('#main-table-body .building-row:not(.hidden)').forEach(row => {{
        rows.push([
            row.dataset.rank,
            row.dataset.address || '',
            row.dataset.city,
            row.dataset.type,
            row.dataset.owner,
            formatMoneyJS(parseFloat(row.dataset.opex) || 0),
            formatCarbonJS(parseFloat(row.dataset.carbon) || 0)
        ]);
    }});

    downloadCSV(rows, 'filtered_buildings.csv');
}}

// Export Portfolio Summaries
function exportPortfolioCSV() {{
    const headers = ['Organization', 'Building Count', 'Classification', 'Total OpEx Savings ($)', 'Total Valuation Impact ($)', 'Total Carbon Reduction (tCO2e)', 'Median EUI', 'Verticals'];
    const rows = [headers];

    PORTFOLIO_CARDS.forEach(p => {{
        rows.push([
            p.org_name || p.display_name || '',
            p.building_count || 0,
            p.classification || '',
            (p.total_opex || 0).toFixed(2),
            (p.total_valuation || 0).toFixed(2),
            (p.total_carbon || 0).toFixed(2),
            p.median_eui ? p.median_eui.toFixed(1) : '',
            Array.isArray(p.verticals) ? p.verticals.join(', ') : (p.verticals || '')
        ]);
    }});

    downloadCSV(rows, 'portfolio_summaries.csv');
}}

// Legacy export functions (kept for backward compatibility)
function exportTableCSV() {{ exportFilteredCSV(); }}
function exportCSV() {{ exportPortfolioCSV(); }}

// =============================================================================
// PORTFOLIO SORTING
// =============================================================================

let portfolioSortDir = {{}};
window.sortPortfolios = function(col) {{
    // Standardize: first click = descending for numeric columns (show highest first)
    const isNumeric = ['opex', 'valuation', 'carbon', 'sqft', 'buildings', 'eui'].includes(col);
    if (portfolioSortDir[col] === undefined) {{
        portfolioSortDir[col] = isNumeric ? false : true;  // false = descending for numeric
    }} else {{
        portfolioSortDir[col] = !portfolioSortDir[col];
    }}
    const asc = portfolioSortDir[col];

    // Update global sort state so applyFilters respects it
    currentSortCol = col;
    currentSortAsc = asc;

    // Sort the PORTFOLIO_CARDS array (all portfolio data, not just rendered DOM)
    PORTFOLIO_CARDS.sort((a, b) => {{
        let aVal, bVal;
        if (col === 'name') {{
            aVal = (a.org_name || '').toLowerCase();
            bVal = (b.org_name || '').toLowerCase();
        }} else if (col === 'buildings') {{
            aVal = a.building_count || 0;
            bVal = b.building_count || 0;
        }} else if (col === 'sqft') {{
            aVal = a.total_sqft || 0;
            bVal = b.total_sqft || 0;
        }} else if (col === 'eui') {{
            // Put null/0 EUI at bottom regardless of sort direction
            const aHasEui = a.median_eui && a.median_eui > 0;
            const bHasEui = b.median_eui && b.median_eui > 0;
            if (!aHasEui && !bHasEui) return 0;
            if (!aHasEui) return 1;  // a goes to bottom
            if (!bHasEui) return -1; // b goes to bottom
            aVal = a.median_eui;
            bVal = b.median_eui;
        }} else if (col === 'opex') {{
            aVal = a.total_opex || 0;
            bVal = b.total_opex || 0;
        }} else if (col === 'valuation') {{
            aVal = a.total_valuation || 0;
            bVal = b.total_valuation || 0;
        }} else if (col === 'carbon') {{
            aVal = a.total_carbon || 0;
            bVal = b.total_carbon || 0;
        }} else if (col === 'type' || col === 'classification') {{
            aVal = (a.classification || '').toLowerCase();
            bVal = (b.classification || '').toLowerCase();
        }}
        // FIXED: Use proper comparison that handles equal values and string/number types
        if (typeof aVal === 'string') {{
            return asc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }}
        return asc ? (aVal - bVal) : (bVal - aVal);
    }});

    // Clear DOM and reset infinite scroll counter
    const container = document.getElementById('portfolios-list');
    container.innerHTML = '';
    loadedCardCount = 0;

    // Re-render first batch from sorted data
    loadMorePortfolios();

    // FIX: Apply active filters after re-rendering sorted cards
    applyFilters();
}};

// =============================================================================
// BUILDING ROW SORTING (within expanded portfolio)
// =============================================================================

let buildingSortDir = {{}};
window.sortBuildingRows = function(headerEl, col, evt) {{
    // Use passed event or fall back to window.event for legacy compatibility
    if (evt) evt.stopPropagation();
    else if (window.event) window.event.stopPropagation();

    const card = headerEl.closest('.portfolio-card');
    if (!card) return;  // Safety check
    const container = card.querySelector('.building-rows-container');
    if (!container) return;  // Safety check
    const rows = Array.from(container.querySelectorAll('.building-grid-row'));

    // Standardize: first click = descending for numeric columns (show highest first)
    const key = card.dataset.idx + '_' + col;
    const isNumeric = ['opex', 'valuation', 'carbon', 'sqft', 'eui'].includes(col);
    if (buildingSortDir[key] === undefined) {{
        buildingSortDir[key] = isNumeric ? false : true;  // false = descending for numeric
    }} else {{
        buildingSortDir[key] = !buildingSortDir[key];
    }}
    const asc = buildingSortDir[key];

    rows.sort((a, b) => {{
        let aVal, bVal;
        if (col === 'address') {{
            aVal = (a.dataset.address || '').toLowerCase();
            bVal = (b.dataset.address || '').toLowerCase();
        }} else if (col === 'type') {{
            aVal = (a.dataset.radioType || '').toLowerCase();
            bVal = (b.dataset.radioType || '').toLowerCase();
        }} else if (col === 'sqft') {{
            aVal = safeParseFloat(a.dataset.sqft, 0);
            bVal = safeParseFloat(b.dataset.sqft, 0);
        }} else if (col === 'eui') {{
            // Explicit null handling - push missing EUI to bottom regardless of sort direction
            const aRaw = safeParseFloat(a.dataset.eui, NaN);
            const bRaw = safeParseFloat(b.dataset.eui, NaN);
            const aHasEui = !isNaN(aRaw) && aRaw > 0;
            const bHasEui = !isNaN(bRaw) && bRaw > 0;
            if (!aHasEui && !bHasEui) return 0;
            if (!aHasEui) return 1;  // a goes to bottom
            if (!bHasEui) return -1; // b goes to bottom
            aVal = aRaw;
            bVal = bRaw;
        }} else if (col === 'valuation') {{
            aVal = safeParseFloat(a.dataset.valuation, 0);
            bVal = safeParseFloat(b.dataset.valuation, 0);
        }} else if (col === 'carbon') {{
            aVal = safeParseFloat(a.dataset.carbon, 0);
            bVal = safeParseFloat(b.dataset.carbon, 0);
        }} else if (col === 'opex') {{
            aVal = safeParseFloat(a.dataset.opex, 0);
            bVal = safeParseFloat(b.dataset.opex, 0);
        }}

        if (typeof aVal === 'string') {{
            return asc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        }}
        return asc ? aVal - bVal : bVal - aVal;
    }});

    // Re-append sorted rows (preserve sort header and controls)
    const sortHeader = container.querySelector('.building-sort-header');
    const controls = container.querySelector('.row-controls');
    rows.forEach(row => container.insertBefore(row, controls));

    // Update header arrows
    card.querySelectorAll('.building-sort-header .sort-col').forEach(el => {{
        el.classList.remove('sorted-asc', 'sorted-desc');
    }});
    headerEl.classList.add(asc ? 'sorted-asc' : 'sorted-desc');
}};

// =============================================================================
// VERTICAL DROPDOWN FILTERS
// =============================================================================

function toggleVerticalDropdown(event, vertical) {{
    event.stopPropagation();
    const dropdown = document.getElementById('dropdown-' + vertical);
    const arrow = event.currentTarget;

    // Close all other dropdowns first
    document.querySelectorAll('.vertical-dropdown').forEach(d => {{
        if (d.id !== 'dropdown-' + vertical) {{
            d.classList.remove('show');
        }}
    }});
    document.querySelectorAll('.vertical-dropdown-arrow').forEach(a => {{
        if (a !== arrow) a.classList.remove('open');
    }});

    // Toggle this dropdown
    dropdown.classList.toggle('show');
    arrow.classList.toggle('open');
}}

function selectBuildingTypeFromDropdown(buildingType, vertical) {{
    console.log('=== selectBuildingTypeFromDropdown CALLED ===');
    console.log('buildingType:', buildingType);
    console.log('vertical:', vertical);
    // Close all dropdowns
    document.querySelectorAll('.vertical-dropdown').forEach(d => d.classList.remove('show'));
    document.querySelectorAll('.vertical-dropdown-arrow').forEach(a => a.classList.remove('open'));

    // If "all" selected, clear the building type filter and just show the vertical
    if (buildingType === 'all') {{
        // Uncheck all radios
        document.querySelectorAll('.vertical-dropdown input[type="radio"]').forEach(r => r.checked = false);
        // Clear building type filter
        selectedBuildingType = null;
        // Remove selected class from all vertical buttons
        document.querySelectorAll('.vertical-btn').forEach(b => b.classList.remove('selected'));
        // Switch to that vertical
        selectVertical(vertical);
        return;
    }}

    // Set building type BEFORE calling selectVertical
    selectedBuildingType = buildingType;

    // Ensure only this radio is selected (clear all others explicitly)
    document.querySelectorAll('.vertical-dropdown input[type="radio"]').forEach(r => {{
        r.checked = (r.dataset.type === buildingType);
    }});

    // Switch to that vertical, preserving the building type we just set
    selectVertical(vertical, true);

    // Add selected class to the vertical button (shows shadow + X)
    document.querySelectorAll('.vertical-btn').forEach(b => b.classList.remove('selected'));
    const verticalBtn = document.querySelector(`.vertical-btn[data-vertical="${{vertical}}"]`);
    if (verticalBtn) {{
        verticalBtn.classList.add('selected');
    }}

    applyFilters();
    // Sync to All Buildings tab - filter if data is loaded
    console.log('allBuildingsData length:', allBuildingsData?.length);
    if (allBuildingsData && allBuildingsData.length > 0) {{
        console.log('Calling doFilterAllBuildings...');
        doFilterAllBuildings();
    }}
}}

// Close vertical dropdowns when clicking outside
document.addEventListener('click', function(e) {{
    if (!e.target.closest('.vertical-btn-wrapper')) {{
        document.querySelectorAll('.vertical-dropdown').forEach(d => d.classList.remove('show'));
        document.querySelectorAll('.vertical-dropdown-arrow').forEach(a => a.classList.remove('open'));
    }}
}});

function toggleLeaderboardMenu(event) {{
    event.stopPropagation();
    const menu = document.getElementById('leaderboard-menu');
    menu.classList.toggle('show');

    // Load leaderboard data when opening
    if (menu.classList.contains('show')) {{
        refreshLeaderboard();
    }}
}}

// Close leaderboard menu when clicking outside
document.addEventListener('click', function(e) {{
    if (!e.target.closest('.leaderboard-dropdown')) {{
        const menu = document.getElementById('leaderboard-menu');
        if (menu) menu.classList.remove('show');
    }}
}});

// =============================================================================
// TYPE FILTER DROPDOWN
// =============================================================================

function toggleTypeFilter(event) {{
    event.stopPropagation();
    const dropdown = document.getElementById('typeFilterDropdown');
    const wrapper = document.getElementById('typeFilterWrapper');
    dropdown.classList.toggle('show');
    wrapper.classList.toggle('active');
}}

function clearTypeFilter() {{
    // Uncheck all radio buttons
    document.querySelectorAll('#typeFilterDropdown input[name="type-filter"]').forEach(r => r.checked = false);
    const wrapper = document.getElementById('typeFilterWrapper');
    wrapper.classList.remove('filtering');
    applyAllFilters();
}}


function applyTypeFilter() {{
    const selected = document.querySelector('#typeFilterDropdown input[name="type-filter"]:checked');
    const selectedType = selected ? selected.dataset.type : 'all';

    // Update filter indicator
    const wrapper = document.getElementById('typeFilterWrapper');
    if (selectedType === 'all') {{
        wrapper.classList.remove('filtering');
    }} else {{
        wrapper.classList.add('filtering');
    }}

    // Close the dropdown after selection
    document.getElementById('typeFilterDropdown').classList.remove('show');
    wrapper.classList.remove('active');

    // Apply combined filters
    applyAllFilters();
}}

function updatePortfolioVisibleCounts() {{
    // FIXED: Use .hidden class instead of inline style check to match applyFilters()
    const visibleCards = document.querySelectorAll('.portfolio-card:not(.hidden)');
    let totalBuildings = 0;
    let totalSqft = 0;
    let totalOpex = 0;
    let totalCarbon = 0;
    let totalValuation = 0;

    visibleCards.forEach(card => {{
        totalBuildings += parseInt(card.dataset.buildings || 0);
        totalSqft += parseFloat(card.dataset.sqft || 0);
        totalOpex += parseFloat(card.dataset.opex || 0);
        totalCarbon += parseFloat(card.dataset.carbon || 0);
        totalValuation += parseFloat(card.dataset.valuation || 0);
    }});

    // Update header tooltips with filtered totals
    const buildingsHeader = document.getElementById('header-buildings');
    const sqftHeader = document.getElementById('header-sqft');
    const opexHeader = document.getElementById('header-opex');
    const carbonHeader = document.getElementById('header-carbon');
    const valuationHeader = document.getElementById('header-valuation');

    if (buildingsHeader) buildingsHeader.title = `${{totalBuildings.toLocaleString()}} buildings shown`;
    if (sqftHeader) sqftHeader.title = `${{(totalSqft/1e6).toFixed(1)}}M sq ft shown`;
    if (opexHeader) {{
        opexHeader.title = `$${{(totalOpex/1e6).toFixed(1)}}M savings shown (Avoided utility costs + avoided carbon fines)`;}}
    if (carbonHeader) carbonHeader.title = `${{Math.round(totalCarbon/1000)}}K tCO2e shown`;
    if (valuationHeader) valuationHeader.title = `$${{(totalValuation/1e9).toFixed(2)}}B val. impact shown`;
}}

// Close type filter dropdown when clicking outside
document.addEventListener('click', function(e) {{
    if (!e.target.closest('.type-filter-wrapper')) {{
        const dropdown = document.getElementById('typeFilterDropdown');
        const wrapper = document.getElementById('typeFilterWrapper');
        if (dropdown) dropdown.classList.remove('show');
        if (wrapper) wrapper.classList.remove('active');
    }}
}});

// =============================================================================
// EUI FILTER DROPDOWN
// =============================================================================

function toggleEuiFilter(event) {{
    event.stopPropagation();
    const dropdown = document.getElementById('euiFilterDropdown');
    const wrapper = document.getElementById('euiFilterWrapper');
    if (dropdown) dropdown.classList.toggle('show');
    if (wrapper) wrapper.classList.toggle('active');
}}

function clearEuiFilter() {{
    // Uncheck all radio buttons (if dropdown exists)
    document.querySelectorAll('#euiFilterDropdown input[name="eui-filter"]').forEach(r => r.checked = false);
    const wrapper = document.getElementById('euiFilterWrapper');
    if (wrapper) wrapper.classList.remove('filtering');
    // Reset global filter and re-render
    activeEuiFilter = 'all';
    const expanded = document.querySelector('.portfolio-card.expanded');
    if (expanded) {{
        loadPortfolioRows(expanded, true);
    }}
}}

function toggleEuiAll(checkbox) {{
    const isChecked = checkbox.checked;
    document.querySelectorAll('#euiFilterDropdown input[data-eui]').forEach(cb => {{
        cb.checked = isChecked;
    }});
    applyEuiFilter();
}}

function applyEuiFilter() {{
    const selected = document.querySelector('#euiFilterDropdown input[name="eui-filter"]:checked');
    activeEuiFilter = selected ? selected.dataset.eui : 'all';

    // Update filter indicator
    const wrapper = document.getElementById('euiFilterWrapper');
    if (wrapper) {{
        if (activeEuiFilter === 'all') {{
            wrapper.classList.remove('filtering');
        }} else {{
            wrapper.classList.add('filtering');
        }}
    }}

    // Close the dropdown after selection
    const dropdown = document.getElementById('euiFilterDropdown');
    if (dropdown) dropdown.classList.remove('show');
    if (wrapper) wrapper.classList.remove('active');

    // Re-render building rows with EUI filter applied to DATA
    const expanded = document.querySelector('.portfolio-card.expanded');
    if (!expanded) return;
    loadPortfolioRows(expanded, true);
}}

// Close EUI filter dropdown when clicking outside
document.addEventListener('click', function(e) {{
    if (!e.target.closest('.eui-filter-wrapper')) {{
        const dropdown = document.getElementById('euiFilterDropdown');
        const wrapper = document.getElementById('euiFilterWrapper');
        if (dropdown) dropdown.classList.remove('show');
        if (wrapper) wrapper.classList.remove('active');
    }}
}});

// =============================================================================
// PORTFOLIO EXPANSION
// =============================================================================

function togglePortfolio(header) {{
    const card = header.closest('.portfolio-card');

    // Collapse all other expanded portfolios (only one open at a time)
    document.querySelectorAll('.portfolio-card.expanded').forEach(c => {{
        if (c !== card) c.classList.remove('expanded');
    }});

    // Clear EUI filter when any collapse happens (switching portfolios or collapsing)
    clearEuiFilter();

    card.classList.toggle('expanded');

    // Load rows ONLY when expanding (not collapsing)
    if (card.classList.contains('expanded')) {{
        loadPortfolioRows(card);  // Renders rows + sets up lazy image loading
        // Capture the portfolio logo URL for map popups
        const logoImg = card.querySelector('.portfolio-header .org-logo');
        expandedPortfolioLogo = logoImg ? logoImg.src : null;

        // Scroll to show full portfolio data row below sticky header
        setTimeout(() => {{
            const rect = card.getBoundingClientRect();
            const headerOffset = 250; // sticky headers height
            const targetY = window.scrollY + rect.top - headerOffset;
            window.scrollTo({{ top: targetY, behavior: 'smooth' }});
        }}, 50);
    }} else {{
        expandedPortfolioLogo = null;
    }}

    // Update map if it's open (show portfolio buildings or all buildings)
    if (document.getElementById('map-panel').classList.contains('open')) {{
        updateMapData();
        updateMapTitle();
    }}

}}

// =============================================================================
// STICKY HEADER ORG NAME - shows org name when scrolling through expanded portfolio
// =============================================================================

function updateStickyOrgName() {{
    const headerOrgCol = document.getElementById('header-org-col');
    if (!headerOrgCol) return;

    const expanded = document.querySelector('.portfolio-card.expanded');
    if (!expanded) {{
        headerOrgCol.textContent = 'Org';
        return;
    }}

    const sortHeader = document.querySelector('.portfolio-sort-header');
    const sortHeaderBottom = sortHeader.getBoundingClientRect().bottom;
    const portfolioHeader = expanded.querySelector('.portfolio-header');
    const portfolioHeaderBottom = portfolioHeader.getBoundingClientRect().bottom;

    const portfolioCardBottom = expanded.getBoundingClientRect().bottom;

    // Show org name only when: header scrolled off AND still viewing buildings
    if (portfolioHeaderBottom < sortHeaderBottom && portfolioCardBottom > sortHeaderBottom) {{
        const orgNameSpan = expanded.querySelector('.org-name-small');
        const displayName = orgNameSpan ? orgNameSpan.getAttribute('title') : '';
        headerOrgCol.textContent = displayName;
    }} else {{
        headerOrgCol.textContent = 'Org';
    }}
}}

window.addEventListener('scroll', updateStickyOrgName, {{ passive: true }});

// =============================================================================
// ADDRESS SEARCH (NYC-style with 200ft radius)
// =============================================================================

let addressMarker = null;
let searchMarkers = [];
let selectedAddressLocation = null;
const SEARCH_RADIUS_METERS = 61; // 200 feet in meters

// Setup Google Places Autocomplete - simple like /Users/forrestmiller/Desktop/index.html
function setupAddressSearch() {{
    const input = document.getElementById('addressAutocomplete');
    if (!input) return;

    if (typeof google !== 'undefined' && google.maps && google.maps.places) {{
        const autocomplete = new google.maps.places.Autocomplete(input, {{
            types: ['address'],
            componentRestrictions: {{ country: 'us' }}
        }});

        autocomplete.addListener('place_changed', function() {{
            const place = autocomplete.getPlace();
            if (place && place.geometry) {{
                const lat = place.geometry.location.lat();
                const lng = place.geometry.location.lng();
                showNearbyBuildings(lat, lng);
            }}
        }});
    }}
}}

// Haversine distance in meters
function haversineMeters(lat1, lon1, lat2, lon2) {{
    const R = 6371000; // Earth radius in meters
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
}}

// Create GeoJSON circle for radius visualization
function createGeoJSONCircle(center, radiusInKm, points = 64) {{
    const coords = {{ latitude: center[1], longitude: center[0] }};
    const km = radiusInKm;
    const ret = [];
    const distanceX = km / (111.320 * Math.cos(coords.latitude * Math.PI / 180));
    const distanceY = km / 110.574;
    for (let i = 0; i < points; i++) {{
        const theta = (i / points) * (2 * Math.PI);
        const x = distanceX * Math.cos(theta);
        const y = distanceY * Math.sin(theta);
        ret.push([coords.longitude + x, coords.latitude + y]);
    }}
    ret.push(ret[0]);
    return {{ type: 'Feature', geometry: {{ type: 'Polygon', coordinates: [ret] }} }};
}}

// Find and display nearby buildings
function showNearbyBuildings(lat, lng) {{
    // Wait for map to be ready (like NYC implementation)
    const waitForMapAndShow = () => {{
        if (fullMap && fullMap.isStyleLoaded()) {{
            doShowNearbyBuildings(lat, lng);
        }} else if (fullMap) {{
            fullMap.once('load', () => doShowNearbyBuildings(lat, lng));
        }} else {{
            // Map not initialized yet, try again in 100ms
            setTimeout(waitForMapAndShow, 100);
        }}
    }};

    if (!fullMap) {{
        initFullMap();
        waitForMapAndShow();
        return;
    }}

    if (!fullMap.isStyleLoaded()) {{
        fullMap.once('load', () => doShowNearbyBuildings(lat, lng));
        return;
    }}

    doShowNearbyBuildings(lat, lng);
}}

function doShowNearbyBuildings(lat, lng) {{
    if (!fullMap) return;

    // Clear existing markers
    searchMarkers.forEach(m => m.remove());
    searchMarkers = [];
    if (addressMarker) {{
        addressMarker.remove();
        addressMarker = null;
    }}

    // Remove existing radius circle
    if (fullMap.getLayer('radius-circle-layer')) {{
        fullMap.removeLayer('radius-circle-layer');
    }}
    if (fullMap.getSource('radius-circle')) {{
        fullMap.removeSource('radius-circle');
    }}

    // Add 200ft radius circle
    const circleFeature = createGeoJSONCircle([lng, lat], SEARCH_RADIUS_METERS / 1000);
    fullMap.addSource('radius-circle', {{
        type: 'geojson',
        data: {{ type: 'FeatureCollection', features: [circleFeature] }}
    }});
    fullMap.addLayer({{
        id: 'radius-circle-layer',
        type: 'fill',
        source: 'radius-circle',
        paint: {{
            'fill-color': '#1b95ff',
            'fill-opacity': 0.15
        }}
    }});

    // Calculate distances for all buildings (MAP_DATA loaded on demand)
    if (!MAP_DATA) {{ return; }}
    const buildingsWithDistance = MAP_DATA.map(b => {{
        const dist = haversineMeters(lat, lng, b.lat, b.lon);
        return {{ ...b, distance: dist }};
    }}).sort((a, b) => a.distance - b.distance);

    // Find buildings within 200ft (61 meters)
    const nearbyBuildings = buildingsWithDistance.filter(b => b.distance <= SEARCH_RADIUS_METERS);

    if (nearbyBuildings.length > 0) {{
        // Show buildings within radius as blue pins
        nearbyBuildings.forEach((b, idx) => {{
            const el = document.createElement('div');
            el.style.cssText = 'width:20px;height:20px;background:#0066cc;border-radius:50%;border:3px solid white;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3);';

            const popup = new mapboxgl.Popup({{ offset: 25 }}).setHTML(`
                <div style="padding:8px;">
                    <h4 style="margin:0 0 4px 0;font-size:14px;">${{b.address}}</h4>
                    <p style="margin:0 0 8px 0;color:#666;font-size:12px;">${{b.city}}, ${{b.state}} • ${{b.type}}</p>
                    <div style="font-size:12px;">
                        <div><strong>Distance:</strong> ${{(b.distance * 3.28084).toFixed(0)}} ft</div>
                        <div><strong>OpEx Savings:</strong> ${{formatMoney(b.total_opex)}}/yr</div>
                    </div>
                </div>
            `);

            const marker = new mapboxgl.Marker(el)
                .setLngLat([b.lon, b.lat])
                .setPopup(popup)
                .addTo(fullMap);

            searchMarkers.push(marker);
        }});

        // Fly to center of results
        if (nearbyBuildings.length === 1) {{
            fullMap.flyTo({{ center: [nearbyBuildings[0].lon, nearbyBuildings[0].lat], zoom: 18 }});
        }} else {{
            const bounds = new mapboxgl.LngLatBounds();
            nearbyBuildings.forEach(b => bounds.extend([b.lon, b.lat]));
            fullMap.fitBounds(bounds, {{ padding: 60, maxZoom: 18 }});
        }}
    }} else {{
        // No buildings within 200ft - show 10 nearest as blue pins
        const nearest = buildingsWithDistance.slice(0, 10);

        nearest.forEach((b, idx) => {{
            const el = document.createElement('div');
            el.style.cssText = 'width:16px;height:16px;background:#0066cc;border-radius:50%;border:2px solid white;cursor:pointer;';

            const distFeet = (b.distance * 3.28084).toFixed(0);
            const distMiles = (b.distance / 1609.34).toFixed(2);
            const distDisplay = b.distance < 1609 ? `${{distFeet}} ft` : `${{distMiles}} mi`;

            const popup = new mapboxgl.Popup({{ offset: 25 }}).setHTML(`
                <div style="padding:8px;">
                    <h4 style="margin:0 0 4px 0;font-size:14px;">${{b.address}}</h4>
                    <p style="margin:0 0 8px 0;color:#666;font-size:12px;">${{b.city}}, ${{b.state}} • ${{b.type}}</p>
                    <div style="font-size:12px;">
                        <div><strong>Distance:</strong> ${{distDisplay}}</div>
                        <div><strong>OpEx Savings:</strong> ${{formatMoney(b.total_opex)}}/yr</div>
                    </div>
                </div>
            `);

            const marker = new mapboxgl.Marker(el)
                .setLngLat([b.lon, b.lat])
                .setPopup(popup)
                .addTo(fullMap);

            searchMarkers.push(marker);
        }});

        // Add black marker for searched address
        const addrEl = document.createElement('div');
        addrEl.style.cssText = 'width:24px;height:24px;background:#1f2937;border-radius:50%;border:3px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.3);';
        addressMarker = new mapboxgl.Marker(addrEl)
            .setLngLat([lng, lat])
            .setPopup(new mapboxgl.Popup().setHTML('<div style="font-weight:600;padding:4px;">Searched Address</div>'))
            .addTo(fullMap);

        // Fit bounds to show address and nearest buildings
        const bounds = new mapboxgl.LngLatBounds();
        bounds.extend([lng, lat]);
        nearest.slice(0, 5).forEach(b => bounds.extend([b.lon, b.lat]));
        fullMap.fitBounds(bounds, {{ padding: 60, maxZoom: 16 }});
    }}
}}

// =============================================================================
// UTILITIES
// =============================================================================

function toRad(deg) {{
    return deg * Math.PI / 180;
}}

function savingsColor(amount) {{
    amount = parseFloat(amount) || 0;
    // Green gradient: darker = more savings
    if (amount >= 500000) return '#166534';  // dark green
    if (amount >= 100000) return '#22c55e';  // medium green
    return '#4ade80';  // light green
}}

// =============================================================================
// MAP PANEL - Full Interactive Map with Clustering
// =============================================================================

// Load map data on demand (if not already loaded via script tag)
let MAP_DATA = null;

function loadMapData() {{
    if (MAP_DATA) {{
        DIAG.log('info', 'MAP_DATA already loaded', {{ count: MAP_DATA.length }});
        return Promise.resolve();
    }}
    DIAG.log('info', 'Loading map_data.js...');
    // Larger file needs longer timeout (30s)
    return loadScript('data/map_data.js', {{ timeout: 30000 }})
        .then(() => {{
            DIAG.log('info', 'map_data.js loaded', {{ count: MAP_DATA?.length || 0 }});
        }})
        .catch(err => {{
            DIAG.log('error', 'map_data.js failed to load', err);
            console.error('[Map] Failed to load map data:', err);
            MAP_DATA = []; // Graceful fallback to empty
        }});
}}

let fullMap = null;
let expandedPortfolioLogo = null;  // Track current expanded portfolio's logo URL

// Get buildings filtered by current context (expanded portfolio + active filters)
function getFilteredBuildingsForMap() {{
    // Map data loaded on demand - return empty if not loaded yet
    if (!MAP_DATA) return [];

    // Check if a portfolio is expanded
    const expandedPortfolio = document.querySelector('.portfolio-card.expanded');

    let buildingIds = null;
    if (expandedPortfolio) {{
        // Get building IDs from PORTFOLIO_BUILDINGS data (not DOM)
        const idx = parseInt(expandedPortfolio.dataset.idx);
        if (!isNaN(idx) && PORTFOLIO_BUILDINGS[idx]) {{
            buildingIds = new Set(PORTFOLIO_BUILDINGS[idx].map(b => b.id));
        }} else {{
            buildingIds = new Set();
        }}
    }}

    // Filter MAP_DATA array (loaded on demand)
    return MAP_DATA.filter(b => {{
        // Must have coordinates
        if (!b.lat || !b.lon) return false;

        // If portfolio expanded, must be in that portfolio
        if (buildingIds && !buildingIds.has(b.id)) return false;

        // Apply current filters (vertical, building type)
        if (activeVertical !== 'all' && b.vertical !== activeVertical) return false;
        if (selectedBuildingType && b.type !== selectedBuildingType) return false;

        return true;
    }});
}}

// Build GeoJSON from buildings array (optionally filtered)
function buildingsGeoJSON(buildings = null) {{
    const data = buildings || getFilteredBuildingsForMap();

    // Group buildings by coordinates to detect stacked pins
    const coordMap = {{}};
    data.forEach(b => {{
        const key = `${{b.lat}},${{b.lon}}`;
        if (!coordMap[key]) coordMap[key] = [];
        coordMap[key].push(b);
    }});

    return {{
        type: 'FeatureCollection',
        features: data.map(b => {{
            const key = `${{b.lat}},${{b.lon}}`;
            const stack = coordMap[key];
            return {{
                type: 'Feature',
                properties: {{
                    id: b.id,
                    address: b.address,
                    city: b.city,
                    state: b.state,
                    type: b.type,
                    vertical: b.vertical,
                    opex: b.opex,
                    image: b.image,
                    owner: b.owner || '',
                    manager: b.manager || '',
                    property_name: b.property_name || '',
                    stackCount: stack.length,
                    stackKey: key
                }},
                geometry: {{
                    type: 'Point',
                    coordinates: [b.lon, b.lat]
                }}
            }};
        }})
    }};
}}

// Update map data based on current context
function updateMapData() {{
    if (!fullMap || !fullMap.getSource('buildings')) return;

    const filteredBuildings = getFilteredBuildingsForMap();
    const geojson = buildingsGeoJSON(filteredBuildings);

    fullMap.getSource('buildings').setData(geojson);

    // Fit bounds to filtered buildings
    if (filteredBuildings.length > 0 && filteredBuildings.length < 5000) {{
        const bounds = new mapboxgl.LngLatBounds();
        filteredBuildings.forEach(b => bounds.extend([b.lon, b.lat]));
        fullMap.fitBounds(bounds, {{ padding: 50, maxZoom: 15 }});
    }}
}}

const CLIMATE_ZONES = {{"type":"FeatureCollection","features":[{{"type":"Feature","id":"01","properties":{{"name":"Alabama","density":94.65,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-87.359296,35.00118],[-85.606675,34.984749],[-85.431413,34.124869],[-85.184951,32.859696],[-85.069935,32.580372],[-84.960397,32.421541],[-85.004212,32.322956],[-84.889196,32.262709],[-85.058981,32.13674],[-85.053504,32.01077],[-85.141136,31.840985],[-85.042551,31.539753],[-85.113751,31.27686],[-85.004212,31.003013],[-85.497137,30.997536],[-87.600282,30.997536],[-87.633143,30.86609],[-87.408589,30.674397],[-87.446927,30.510088],[-87.37025,30.427934],[-87.518128,30.280057],[-87.655051,30.247195],[-87.90699,30.411504],[-87.934375,30.657966],[-88.011052,30.685351],[-88.10416,30.499135],[-88.137022,30.318396],[-88.394438,30.367688],[-88.471115,31.895754],[-88.241084,33.796253],[-88.098683,34.891641],[-88.202745,34.995703],[-87.359296,35.00118]]]}}}},{{"type":"Feature","id":"02","properties":{{"name":"Alaska","density":1.264,"zone":7}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-131.602021,55.117982],[-131.569159,55.28229],[-131.355558,55.183705],[-131.38842,55.01392],[-131.645836,55.035827],[-131.602021,55.117982]]],[[[-131.832052,55.42469],[-131.645836,55.304197],[-131.749898,55.128935],[-131.832052,55.189182],[-131.832052,55.42469]]],[[[-132.976733,56.437924],[-132.735747,56.459832],[-132.631685,56.421493],[-132.664547,56.273616],[-132.878148,56.240754],[-133.069841,56.333862],[-132.976733,56.437924]]],[[[-133.595627,56.350293],[-133.162949,56.317431],[-133.05341,56.125739],[-132.620732,55.912138],[-132.472854,55.780691],[-132.4619,55.671152],[-132.357838,55.649245],[-132.341408,55.506844],[-132.166146,55.364444],[-132.144238,55.238474],[-132.029222,55.276813],[-131.97993,55.178228],[-131.958022,54.789365],[-132.029222,54.701734],[-132.308546,54.718165],[-132.385223,54.915335],[-132.483808,54.898904],[-132.686455,55.046781],[-132.746701,54.997489],[-132.916486,55.046781],[-132.889102,54.898904],[-132.73027,54.937242],[-132.626209,54.882473],[-132.675501,54.679826],[-132.867194,54.701734],[-133.157472,54.95915],[-133.239626,55.090597],[-133.223195,55.22752],[-133.453227,55.216566],[-133.453227,55.320628],[-133.277964,55.331582],[-133.102702,55.42469],[-133.17938,55.588998],[-133.387503,55.62186],[-133.420365,55.884753],[-133.497042,56.0162],[-133.639442,55.923092],[-133.694212,56.070969],[-133.546335,56.142169],[-133.666827,56.311955],[-133.595627,56.350293]]],[[[-133.738027,55.556137],[-133.546335,55.490413],[-133.414888,55.572568],[-133.283441,55.534229],[-133.420365,55.386352],[-133.633966,55.430167],[-133.738027,55.556137]]],[[[-133.907813,56.930849],[-134.050213,57.029434],[-133.885905,57.095157],[-133.343688,57.002049],[-133.102702,57.007526],[-132.932917,56.82131],[-132.620732,56.667956],[-132.653593,56.55294],[-132.817901,56.492694],[-133.042456,56.520078],[-133.201287,56.448878],[-133.420365,56.492694],[-133.66135,56.448878],[-133.710643,56.684386],[-133.688735,56.837741],[-133.869474,56.843218],[-133.907813,56.930849]]],[[[-134.115936,56.48174],[-134.25286,56.558417],[-134.400737,56.722725],[-134.417168,56.848695],[-134.296675,56.908941],[-134.170706,56.848695],[-134.143321,56.952757],[-133.748981,56.772017],[-133.710643,56.596755],[-133.847566,56.574848],[-133.935197,56.377678],[-133.836612,56.322908],[-133.957105,56.092877],[-134.110459,56.142169],[-134.132367,55.999769],[-134.230952,56.070969],[-134.291198,56.350293],[-134.115936,56.48174]]],[[[-134.636246,56.28457],[-134.669107,56.169554],[-134.806031,56.235277],[-135.178463,56.67891],[-135.413971,56.810356],[-135.331817,56.914418],[-135.424925,57.166357],[-135.687818,57.369004],[-135.419448,57.566174],[-135.298955,57.48402],[-135.063447,57.418296],[-134.849846,57.407343],[-134.844369,57.248511],[-134.636246,56.728202],[-134.636246,56.28457]]],[[[-134.712923,58.223407],[-134.373353,58.14673],[-134.176183,58.157683],[-134.187137,58.081006],[-133.902336,57.807159],[-134.099505,57.850975],[-134.148798,57.757867],[-133.935197,57.615466],[-133.869474,57.363527],[-134.083075,57.297804],[-134.154275,57.210173],[-134.499322,57.029434],[-134.603384,57.034911],[-134.6472,57.226604],[-134.575999,57.341619],[-134.608861,57.511404],[-134.729354,57.719528],[-134.707446,57.829067],[-134.784123,58.097437],[-134.91557,58.212453],[-134.953908,58.409623],[-134.712923,58.223407]]],[[[-135.857603,57.330665],[-135.715203,57.330665],[-135.567326,57.149926],[-135.633049,57.023957],[-135.857603,56.996572],[-135.824742,57.193742],[-135.857603,57.330665]]],[[[-136.279328,58.206976],[-135.978096,58.201499],[-135.780926,58.28913],[-135.496125,58.168637],[-135.64948,58.037191],[-135.59471,57.987898],[-135.45231,58.135776],[-135.107263,58.086483],[-134.91557,57.976944],[-135.025108,57.779775],[-134.937477,57.763344],[-134.822462,57.500451],[-135.085355,57.462112],[-135.572802,57.675713],[-135.556372,57.456635],[-135.709726,57.369004],[-135.890465,57.407343],[-136.000004,57.544266],[-136.208128,57.637374],[-136.366959,57.829067],[-136.569606,57.916698],[-136.558652,58.075529],[-136.421728,58.130299],[-136.377913,58.267222],[-136.279328,58.206976]]],[[[-147.079854,60.200582],[-147.501579,59.948643],[-147.53444,59.850058],[-147.874011,59.784335],[-147.80281,59.937689],[-147.435855,60.09652],[-147.205824,60.271782],[-147.079854,60.200582]]],[[[-147.561825,60.578491],[-147.616594,60.370367],[-147.758995,60.156767],[-147.956165,60.227967],[-147.791856,60.474429],[-147.561825,60.578491]]],[[[-147.786379,70.245291],[-147.682318,70.201475],[-147.162008,70.15766],[-146.888161,70.185044],[-146.510252,70.185044],[-146.099482,70.146706],[-145.858496,70.168614],[-145.622988,70.08646],[-145.195787,69.993352],[-144.620708,69.971444],[-144.461877,70.026213],[-144.078491,70.059075],[-143.914183,70.130275],[-143.497935,70.141229],[-143.503412,70.091936],[-143.25695,70.119321],[-142.747594,70.042644],[-142.402547,69.916674],[-142.079408,69.856428],[-142.008207,69.801659],[-141.712453,69.790705],[-141.433129,69.697597],[-141.378359,69.63735],[-141.208574,69.686643],[-141.00045,69.648304],[-141.00045,60.304644],[-140.53491,60.22249],[-140.474664,60.310121],[-139.987216,60.184151],[-139.696939,60.342983],[-139.088998,60.359413],[-139.198537,60.091043],[-139.045183,59.997935],[-138.700135,59.910304],[-138.623458,59.767904],[-137.604747,59.242118],[-137.445916,58.908024],[-137.265177,59.001132],[-136.827022,59.159963],[-136.580559,59.16544],[-136.465544,59.285933],[-136.476498,59.466672],[-136.301236,59.466672],[-136.25742,59.625503],[-135.945234,59.663842],[-135.479694,59.800766],[-135.025108,59.565257],[-135.068924,59.422857],[-134.959385,59.280456],[-134.701969,59.247595],[-134.378829,59.033994],[-134.400737,58.973748],[-134.25286,58.858732],[-133.842089,58.727285],[-133.173903,58.152206],[-133.075318,57.998852],[-132.867194,57.845498],[-132.560485,57.505928],[-132.253777,57.21565],[-132.368792,57.095157],[-132.05113,57.051341],[-132.127807,56.876079],[-131.870391,56.804879],[-131.837529,56.602232],[-131.580113,56.613186],[-131.087188,56.405062],[-130.78048,56.366724],[-130.621648,56.268139],[-130.468294,56.240754],[-130.424478,56.142169],[-130.101339,56.114785],[-130.002754,55.994292],[-130.150631,55.769737],[-130.128724,55.583521],[-129.986323,55.276813],[-130.095862,55.200136],[-130.336847,54.920812],[-130.687372,54.718165],[-130.785957,54.822227],[-130.917403,54.789365],[-131.010511,54.997489],[-130.983126,55.08512],[-131.092665,55.189182],[-130.862634,55.298721],[-130.928357,55.337059],[-131.158389,55.200136],[-131.284358,55.287767],[-131.426759,55.238474],[-131.843006,55.457552],[-131.700606,55.698537],[-131.963499,55.616383],[-131.974453,55.49589],[-132.182576,55.588998],[-132.226392,55.704014],[-132.083991,55.829984],[-132.127807,55.955953],[-132.324977,55.851892],[-132.522147,56.076446],[-132.642639,56.032631],[-132.719317,56.218847],[-132.527624,56.339339],[-132.341408,56.339339],[-132.396177,56.487217],[-132.297592,56.67891],[-132.450946,56.673433],[-132.768609,56.837741],[-132.993164,57.034911],[-133.51895,57.177311],[-133.507996,57.577128],[-133.677781,57.62642],[-133.639442,57.790728],[-133.814705,57.834544],[-134.072121,58.053622],[-134.143321,58.168637],[-134.586953,58.206976],[-135.074401,58.502731],[-135.282525,59.192825],[-135.38111,59.033994],[-135.337294,58.891593],[-135.140124,58.617746],[-135.189417,58.573931],[-135.05797,58.349376],[-135.085355,58.201499],[-135.277048,58.234361],[-135.430402,58.398669],[-135.633049,58.426053],[-135.91785,58.382238],[-135.912373,58.617746],[-136.087635,58.814916],[-136.246466,58.75467],[-136.876314,58.962794],[-136.931084,58.902547],[-136.586036,58.836824],[-136.317666,58.672516],[-136.213604,58.667039],[-136.180743,58.535592],[-136.043819,58.382238],[-136.388867,58.294607],[-136.591513,58.349376],[-136.59699,58.212453],[-136.859883,58.316515],[-136.947514,58.393192],[-137.111823,58.393192],[-137.566409,58.590362],[-137.900502,58.765624],[-137.933364,58.869686],[-138.11958,59.02304],[-138.634412,59.132579],[-138.919213,59.247595],[-139.417615,59.379041],[-139.746231,59.505011],[-139.718846,59.641934],[-139.625738,59.598119],[-139.5162,59.68575],[-139.625738,59.88292],[-139.488815,59.992458],[-139.554538,60.041751],[-139.801,59.833627],[-140.315833,59.696704],[-140.92925,59.745996],[-141.444083,59.871966],[-141.46599,59.970551],[-141.706976,59.948643],[-141.964392,60.019843],[-142.539471,60.085566],[-142.873564,60.091043],[-143.623905,60.036274],[-143.892275,59.997935],[-144.231845,60.140336],[-144.65357,60.206059],[-144.785016,60.29369],[-144.834309,60.441568],[-145.124586,60.430614],[-145.223171,60.299167],[-145.738004,60.474429],[-145.820158,60.551106],[-146.351421,60.408706],[-146.608837,60.238921],[-146.718376,60.397752],[-146.608837,60.485383],[-146.455483,60.463475],[-145.951604,60.578491],[-146.017328,60.666122],[-146.252836,60.622307],[-146.345944,60.737322],[-146.565022,60.753753],[-146.784099,61.044031],[-146.866253,60.972831],[-147.172962,60.934492],[-147.271547,60.972831],[-147.375609,60.879723],[-147.758995,60.912584],[-147.775426,60.808523],[-148.032842,60.781138],[-148.153334,60.819476],[-148.065703,61.005692],[-148.175242,61.000215],[-148.350504,60.803046],[-148.109519,60.737322],[-148.087611,60.594922],[-147.939734,60.441568],[-148.027365,60.277259],[-148.219058,60.332029],[-148.273827,60.249875],[-148.087611,60.217013],[-147.983549,59.997935],[-148.251919,59.95412],[-148.399797,59.997935],[-148.635305,59.937689],[-148.755798,59.986981],[-149.067984,59.981505],[-149.05703,60.063659],[-149.204907,60.008889],[-149.287061,59.904827],[-149.418508,59.997935],[-149.582816,59.866489],[-149.511616,59.806242],[-149.741647,59.729565],[-149.949771,59.718611],[-150.031925,59.61455],[-150.25648,59.521442],[-150.409834,59.554303],[-150.579619,59.444764],[-150.716543,59.450241],[-151.001343,59.225687],[-151.308052,59.209256],[-151.406637,59.280456],[-151.592853,59.159963],[-151.976239,59.253071],[-151.888608,59.422857],[-151.636669,59.483103],[-151.47236,59.472149],[-151.423068,59.537872],[-151.127313,59.669319],[-151.116359,59.778858],[-151.505222,59.63098],[-151.828361,59.718611],[-151.8667,59.778858],[-151.702392,60.030797],[-151.423068,60.211536],[-151.379252,60.359413],[-151.297098,60.386798],[-151.264237,60.545629],[-151.406637,60.720892],[-151.06159,60.786615],[-150.404357,61.038554],[-150.245526,60.939969],[-150.042879,60.912584],[-149.741647,61.016646],[-150.075741,61.15357],[-150.207187,61.257632],[-150.47008,61.246678],[-150.656296,61.29597],[-150.711066,61.252155],[-151.023251,61.180954],[-151.165652,61.044031],[-151.477837,61.011169],[-151.800977,60.852338],[-151.833838,60.748276],[-152.080301,60.693507],[-152.13507,60.578491],[-152.310332,60.507291],[-152.392486,60.304644],[-152.732057,60.173197],[-152.567748,60.069136],[-152.704672,59.915781],[-153.022334,59.888397],[-153.049719,59.691227],[-153.345474,59.620026],[-153.438582,59.702181],[-153.586459,59.548826],[-153.761721,59.543349],[-153.72886,59.433811],[-154.117723,59.368087],[-154.1944,59.066856],[-153.750768,59.050425],[-153.400243,58.968271],[-153.301658,58.869686],[-153.444059,58.710854],[-153.679567,58.612269],[-153.898645,58.606793],[-153.920553,58.519161],[-154.062953,58.4863],[-153.99723,58.376761],[-154.145107,58.212453],[-154.46277,58.059098],[-154.643509,58.059098],[-154.818771,58.004329],[-154.988556,58.015283],[-155.120003,57.955037],[-155.081664,57.872883],[-155.328126,57.829067],[-155.377419,57.708574],[-155.547204,57.785251],[-155.73342,57.549743],[-156.045606,57.566174],[-156.023698,57.440204],[-156.209914,57.473066],[-156.34136,57.418296],[-156.34136,57.248511],[-156.549484,56.985618],[-156.883577,56.952757],[-157.157424,56.832264],[-157.20124,56.766541],[-157.376502,56.859649],[-157.672257,56.607709],[-157.754411,56.67891],[-157.918719,56.657002],[-157.957058,56.514601],[-158.126843,56.459832],[-158.32949,56.48174],[-158.488321,56.339339],[-158.208997,56.295524],[-158.510229,55.977861],[-159.375585,55.873799],[-159.616571,55.594475],[-159.676817,55.654722],[-159.643955,55.829984],[-159.813741,55.857368],[-160.027341,55.791645],[-160.060203,55.720445],[-160.394296,55.605429],[-160.536697,55.473983],[-160.580512,55.567091],[-160.668143,55.457552],[-160.865313,55.528752],[-161.232268,55.358967],[-161.506115,55.364444],[-161.467776,55.49589],[-161.588269,55.62186],[-161.697808,55.517798],[-161.686854,55.408259],[-162.053809,55.074166],[-162.179779,55.15632],[-162.218117,55.03035],[-162.470057,55.052258],[-162.508395,55.249428],[-162.661749,55.293244],[-162.716519,55.222043],[-162.579595,55.134412],[-162.645319,54.997489],[-162.847965,54.926289],[-163.00132,55.079643],[-163.187536,55.090597],[-163.220397,55.03035],[-163.034181,54.942719],[-163.373752,54.800319],[-163.14372,54.76198],[-163.138243,54.696257],[-163.329936,54.74555],[-163.587352,54.614103],[-164.085754,54.61958],[-164.332216,54.531949],[-164.354124,54.466226],[-164.638925,54.389548],[-164.847049,54.416933],[-164.918249,54.603149],[-164.710125,54.663395],[-164.551294,54.88795],[-164.34317,54.893427],[-163.894061,55.041304],[-163.532583,55.046781],[-163.39566,54.904381],[-163.291598,55.008443],[-163.313505,55.128935],[-163.105382,55.183705],[-162.880827,55.183705],[-162.579595,55.446598],[-162.245502,55.682106],[-161.807347,55.89023],[-161.292514,55.983338],[-161.078914,55.939523],[-160.87079,55.999769],[-160.816021,55.912138],[-160.931036,55.813553],[-160.805067,55.736876],[-160.766728,55.857368],[-160.509312,55.868322],[-160.438112,55.791645],[-160.27928,55.76426],[-160.273803,55.857368],[-160.536697,55.939523],[-160.558604,55.994292],[-160.383342,56.251708],[-160.147834,56.399586],[-159.830171,56.541986],[-159.326293,56.667956],[-158.959338,56.848695],[-158.784076,56.782971],[-158.641675,56.810356],[-158.701922,56.925372],[-158.658106,57.034911],[-158.378782,57.264942],[-157.995396,57.41282],[-157.688688,57.609989],[-157.705118,57.719528],[-157.458656,58.497254],[-157.07527,58.705377],[-157.119086,58.869686],[-158.039212,58.634177],[-158.32949,58.661562],[-158.40069,58.760147],[-158.564998,58.803962],[-158.619768,58.913501],[-158.767645,58.864209],[-158.860753,58.694424],[-158.701922,58.480823],[-158.893615,58.387715],[-159.0634,58.420577],[-159.392016,58.760147],[-159.616571,58.929932],[-159.731586,58.929932],[-159.808264,58.803962],[-159.906848,58.782055],[-160.054726,58.886116],[-160.235465,58.902547],[-160.317619,59.072332],[-160.854359,58.88064],[-161.33633,58.743716],[-161.374669,58.667039],[-161.752577,58.552023],[-161.938793,58.656085],[-161.769008,58.776578],[-161.829255,59.061379],[-161.955224,59.36261],[-161.703285,59.48858],[-161.911409,59.740519],[-162.092148,59.88292],[-162.234548,60.091043],[-162.448149,60.178674],[-162.502918,59.997935],[-162.760334,59.959597],[-163.171105,59.844581],[-163.66403,59.795289],[-163.9324,59.806242],[-164.162431,59.866489],[-164.189816,60.02532],[-164.386986,60.074613],[-164.699171,60.29369],[-164.962064,60.337506],[-165.268773,60.578491],[-165.060649,60.68803],[-165.016834,60.890677],[-165.175665,60.846861],[-165.197573,60.972831],[-165.120896,61.076893],[-165.323543,61.170001],[-165.34545,61.071416],[-165.591913,61.109754],[-165.624774,61.279539],[-165.816467,61.301447],[-165.920529,61.416463],[-165.915052,61.558863],[-166.106745,61.49314],[-166.139607,61.630064],[-165.904098,61.662925],[-166.095791,61.81628],[-165.756221,61.827233],[-165.756221,62.013449],[-165.674067,62.139419],[-165.044219,62.539236],[-164.912772,62.659728],[-164.819664,62.637821],[-164.874433,62.807606],[-164.633448,63.097884],[-164.425324,63.212899],[-164.036462,63.262192],[-163.73523,63.212899],[-163.313505,63.037637],[-163.039658,63.059545],[-162.661749,63.22933],[-162.272887,63.486746],[-162.075717,63.514131],[-162.026424,63.448408],[-161.555408,63.448408],[-161.13916,63.503177],[-160.766728,63.771547],[-160.766728,63.837271],[-160.952944,64.08921],[-160.974852,64.237087],[-161.26513,64.395918],[-161.374669,64.532842],[-161.078914,64.494503],[-160.79959,64.609519],[-160.783159,64.719058],[-161.144637,64.921705],[-161.413007,64.762873],[-161.664946,64.790258],[-161.900455,64.702627],[-162.168825,64.680719],[-162.234548,64.620473],[-162.541257,64.532842],[-162.634365,64.384965],[-162.787719,64.324718],[-162.858919,64.49998],[-163.045135,64.538319],[-163.176582,64.401395],[-163.253259,64.467119],[-163.598306,64.565704],[-164.304832,64.560227],[-164.80871,64.450688],[-165.000403,64.434257],[-165.411174,64.49998],[-166.188899,64.576658],[-166.391546,64.636904],[-166.484654,64.735489],[-166.413454,64.872412],[-166.692778,64.987428],[-166.638008,65.113398],[-166.462746,65.179121],[-166.517516,65.337952],[-166.796839,65.337952],[-167.026871,65.381768],[-167.47598,65.414629],[-167.711489,65.496784],[-168.072967,65.578938],[-168.105828,65.682999],[-167.541703,65.819923],[-166.829701,66.049954],[-166.3313,66.186878],[-166.046499,66.110201],[-165.756221,66.09377],[-165.690498,66.203309],[-165.86576,66.21974],[-165.88219,66.312848],[-165.186619,66.466202],[-164.403417,66.581218],[-163.981692,66.592172],[-163.751661,66.553833],[-163.872153,66.389525],[-163.828338,66.274509],[-163.915969,66.192355],[-163.768091,66.060908],[-163.494244,66.082816],[-163.149197,66.060908],[-162.749381,66.088293],[-162.634365,66.039001],[-162.371472,66.028047],[-162.14144,66.077339],[-161.840208,66.02257],[-161.549931,66.241647],[-161.341807,66.252601],[-161.199406,66.208786],[-161.128206,66.334755],[-161.528023,66.395002],[-161.911409,66.345709],[-161.87307,66.510017],[-162.174302,66.68528],[-162.502918,66.740049],[-162.601503,66.89888],[-162.344087,66.937219],[-162.015471,66.778388],[-162.075717,66.652418],[-161.916886,66.553833],[-161.571838,66.438817],[-161.489684,66.55931],[-161.884024,66.718141],[-161.714239,67.002942],[-161.851162,67.052235],[-162.240025,66.991988],[-162.639842,67.008419],[-162.700088,67.057712],[-162.902735,67.008419],[-163.740707,67.128912],[-163.757138,67.254881],[-164.009077,67.534205],[-164.211724,67.638267],[-164.534863,67.725898],[-165.192096,67.966884],[-165.493328,68.059992],[-165.794559,68.081899],[-166.243668,68.246208],[-166.681824,68.339316],[-166.703731,68.372177],[-166.375115,68.42147],[-166.227238,68.574824],[-166.216284,68.881533],[-165.329019,68.859625],[-164.255539,68.930825],[-163.976215,68.985595],[-163.532583,69.138949],[-163.110859,69.374457],[-163.023228,69.609966],[-162.842489,69.812613],[-162.470057,69.982398],[-162.311225,70.108367],[-161.851162,70.311014],[-161.779962,70.256245],[-161.396576,70.239814],[-160.837928,70.343876],[-160.487404,70.453415],[-159.649432,70.792985],[-159.33177,70.809416],[-159.298908,70.760123],[-158.975769,70.798462],[-158.658106,70.787508],[-158.033735,70.831323],[-157.420318,70.979201],[-156.812377,71.285909],[-156.565915,71.351633],[-156.522099,71.296863],[-155.585543,71.170894],[-155.508865,71.083263],[-155.832005,70.968247],[-155.979882,70.96277],[-155.974405,70.809416],[-155.503388,70.858708],[-155.476004,70.940862],[-155.262403,71.017539],[-155.191203,70.973724],[-155.032372,71.148986],[-154.566832,70.990155],[-154.643509,70.869662],[-154.353231,70.8368],[-154.183446,70.7656],[-153.931507,70.880616],[-153.487874,70.886093],[-153.235935,70.924431],[-152.589656,70.886093],[-152.26104,70.842277],[-152.419871,70.606769],[-151.817408,70.546523],[-151.773592,70.486276],[-151.187559,70.382214],[-151.182082,70.431507],[-150.760358,70.49723],[-150.355064,70.491753],[-150.349588,70.436984],[-150.114079,70.431507],[-149.867617,70.508184],[-149.462323,70.519138],[-149.177522,70.486276],[-148.78866,70.404122],[-148.607921,70.420553],[-148.350504,70.305537],[-148.202627,70.349353],[-147.961642,70.316491],[-147.786379,70.245291]]],[[[-152.94018,58.026237],[-152.945657,57.982421],[-153.290705,58.048145],[-153.044242,58.305561],[-152.819688,58.327469],[-152.666333,58.562977],[-152.496548,58.354853],[-152.354148,58.426053],[-152.080301,58.311038],[-152.080301,58.152206],[-152.480117,58.130299],[-152.655379,58.059098],[-152.94018,58.026237]]],[[[-153.958891,57.538789],[-153.67409,57.670236],[-153.931507,57.69762],[-153.936983,57.812636],[-153.723383,57.889313],[-153.570028,57.834544],[-153.548121,57.719528],[-153.46049,57.796205],[-153.455013,57.96599],[-153.268797,57.889313],[-153.235935,57.998852],[-153.071627,57.933129],[-152.874457,57.933129],[-152.721103,57.993375],[-152.469163,57.889313],[-152.469163,57.599035],[-152.151501,57.620943],[-152.359625,57.42925],[-152.74301,57.505928],[-152.60061,57.379958],[-152.710149,57.275896],[-152.907319,57.325188],[-152.912796,57.128019],[-153.214027,57.073249],[-153.312612,56.991095],[-153.498828,57.067772],[-153.695998,56.859649],[-153.849352,56.837741],[-154.013661,56.744633],[-154.073907,56.969187],[-154.303938,56.848695],[-154.314892,56.919895],[-154.523016,56.991095],[-154.539447,57.193742],[-154.742094,57.275896],[-154.627078,57.511404],[-154.227261,57.659282],[-153.980799,57.648328],[-153.958891,57.538789]]],[[[-154.53397,56.602232],[-154.742094,56.399586],[-154.807817,56.432447],[-154.53397,56.602232]]],[[[-155.634835,55.923092],[-155.476004,55.912138],[-155.530773,55.704014],[-155.793666,55.731399],[-155.837482,55.802599],[-155.634835,55.923092]]],[[[-159.890418,55.28229],[-159.950664,55.068689],[-160.257373,54.893427],[-160.109495,55.161797],[-160.005433,55.134412],[-159.890418,55.28229]]],[[[-160.520266,55.358967],[-160.33405,55.358967],[-160.339527,55.249428],[-160.525743,55.128935],[-160.690051,55.211089],[-160.794113,55.134412],[-160.854359,55.320628],[-160.79959,55.380875],[-160.520266,55.358967]]],[[[-162.256456,54.981058],[-162.234548,54.893427],[-162.349564,54.838658],[-162.437195,54.931766],[-162.256456,54.981058]]],[[[-162.415287,63.634624],[-162.563165,63.536039],[-162.612457,63.62367],[-162.415287,63.634624]]],[[[-162.80415,54.488133],[-162.590549,54.449795],[-162.612457,54.367641],[-162.782242,54.373118],[-162.80415,54.488133]]],[[[-165.548097,54.29644],[-165.476897,54.181425],[-165.630251,54.132132],[-165.685021,54.252625],[-165.548097,54.29644]]],[[[-165.73979,54.15404],[-166.046499,54.044501],[-166.112222,54.121178],[-165.980775,54.219763],[-165.73979,54.15404]]],[[[-166.364161,60.359413],[-166.13413,60.397752],[-166.084837,60.326552],[-165.88219,60.342983],[-165.685021,60.277259],[-165.646682,59.992458],[-165.750744,59.89935],[-166.00816,59.844581],[-166.062929,59.745996],[-166.440838,59.855535],[-166.6161,59.850058],[-166.994009,59.992458],[-167.125456,59.992458],[-167.344534,60.074613],[-167.421211,60.206059],[-167.311672,60.238921],[-166.93924,60.206059],[-166.763978,60.310121],[-166.577762,60.321075],[-166.495608,60.392275],[-166.364161,60.359413]]],[[[-166.375115,54.01164],[-166.210807,53.934962],[-166.5449,53.748746],[-166.539423,53.715885],[-166.117699,53.852808],[-166.112222,53.776131],[-166.282007,53.683023],[-166.555854,53.622777],[-166.583239,53.529669],[-166.878994,53.431084],[-167.13641,53.425607],[-167.306195,53.332499],[-167.623857,53.250345],[-167.793643,53.337976],[-167.459549,53.442038],[-167.355487,53.425607],[-167.103548,53.513238],[-167.163794,53.611823],[-167.021394,53.715885],[-166.807793,53.666592],[-166.785886,53.732316],[-167.015917,53.754223],[-167.141887,53.825424],[-167.032348,53.945916],[-166.643485,54.017116],[-166.561331,53.880193],[-166.375115,54.01164]]],[[[-168.790446,53.157237],[-168.40706,53.34893],[-168.385152,53.431084],[-168.237275,53.524192],[-168.007243,53.568007],[-167.886751,53.518715],[-167.842935,53.387268],[-168.270136,53.244868],[-168.500168,53.036744],[-168.686384,52.965544],[-168.790446,53.157237]]],[[[-169.74891,52.894344],[-169.705095,52.795759],[-169.962511,52.790282],[-169.989896,52.856005],[-169.74891,52.894344]]],[[[-170.148727,57.221127],[-170.28565,57.128019],[-170.313035,57.221127],[-170.148727,57.221127]]],[[[-170.669036,52.697174],[-170.603313,52.604066],[-170.789529,52.538343],[-170.816914,52.636928],[-170.669036,52.697174]]],[[[-171.742517,63.716778],[-170.94836,63.5689],[-170.488297,63.69487],[-170.280174,63.683916],[-170.093958,63.612716],[-170.044665,63.492223],[-169.644848,63.4265],[-169.518879,63.366254],[-168.99857,63.338869],[-168.686384,63.295053],[-168.856169,63.147176],[-169.108108,63.180038],[-169.376478,63.152653],[-169.513402,63.08693],[-169.639372,62.939052],[-169.831064,63.075976],[-170.055619,63.169084],[-170.263743,63.180038],[-170.362328,63.2841],[-170.866206,63.415546],[-171.101715,63.421023],[-171.463193,63.306007],[-171.73704,63.366254],[-171.852055,63.486746],[-171.742517,63.716778]]],[[[-172.432611,52.390465],[-172.41618,52.275449],[-172.607873,52.253542],[-172.569535,52.352127],[-172.432611,52.390465]]],[[[-173.626584,52.14948],[-173.495138,52.105664],[-173.122706,52.111141],[-173.106275,52.07828],[-173.549907,52.028987],[-173.626584,52.14948]]],[[[-174.322156,52.280926],[-174.327632,52.379511],[-174.185232,52.41785],[-173.982585,52.319265],[-174.059262,52.226157],[-174.179755,52.231634],[-174.141417,52.127572],[-174.333109,52.116618],[-174.738403,52.007079],[-174.968435,52.039941],[-174.902711,52.116618],[-174.656249,52.105664],[-174.322156,52.280926]]],[[[-176.469116,51.853725],[-176.288377,51.870156],[-176.288377,51.744186],[-176.518409,51.760617],[-176.80321,51.61274],[-176.912748,51.80991],[-176.792256,51.815386],[-176.775825,51.963264],[-176.627947,51.968741],[-176.627947,51.859202],[-176.469116,51.853725]]],[[[-177.153734,51.946833],[-177.044195,51.897541],[-177.120872,51.727755],[-177.274226,51.678463],[-177.279703,51.782525],[-177.153734,51.946833]]],[[[-178.123152,51.919448],[-177.953367,51.913971],[-177.800013,51.793479],[-177.964321,51.651078],[-178.123152,51.919448]]],[[[-187.107557,52.992929],[-187.293773,52.927205],[-187.304726,52.823143],[-188.90491,52.762897],[-188.642017,52.927205],[-188.642017,53.003883],[-187.107557,52.992929]]]]}}}},{{"type":"Feature","id":"04","properties":{{"name":"Arizona","density":57.05,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-109.042503,37.000263],[-109.04798,31.331629],[-111.074448,31.331629],[-112.246513,31.704061],[-114.815198,32.492741],[-114.72209,32.717295],[-114.524921,32.755634],[-114.470151,32.843265],[-114.524921,33.029481],[-114.661844,33.034958],[-114.727567,33.40739],[-114.524921,33.54979],[-114.497536,33.697668],[-114.535874,33.933176],[-114.415382,34.108438],[-114.256551,34.174162],[-114.136058,34.305608],[-114.333228,34.448009],[-114.470151,34.710902],[-114.634459,34.87521],[-114.634459,35.00118],[-114.574213,35.138103],[-114.596121,35.324319],[-114.678275,35.516012],[-114.738521,36.102045],[-114.371566,36.140383],[-114.251074,36.01989],[-114.152489,36.025367],[-114.048427,36.195153],[-114.048427,37.000263],[-110.499369,37.00574],[-109.042503,37.000263]]]}}}},{{"type":"Feature","id":"05","properties":{{"name":"Arkansas","density":56.43,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-94.473842,36.501861],[-90.152536,36.496384],[-90.064905,36.304691],[-90.218259,36.184199],[-90.377091,35.997983],[-89.730812,35.997983],[-89.763673,35.811767],[-89.911551,35.756997],[-89.944412,35.603643],[-90.130628,35.439335],[-90.114197,35.198349],[-90.212782,35.023087],[-90.311367,34.995703],[-90.251121,34.908072],[-90.409952,34.831394],[-90.481152,34.661609],[-90.585214,34.617794],[-90.568783,34.420624],[-90.749522,34.365854],[-90.744046,34.300131],[-90.952169,34.135823],[-90.891923,34.026284],[-91.072662,33.867453],[-91.231493,33.560744],[-91.056231,33.429298],[-91.143862,33.347144],[-91.089093,33.13902],[-91.16577,33.002096],[-93.608485,33.018527],[-94.041164,33.018527],[-94.041164,33.54979],[-94.183564,33.593606],[-94.380734,33.544313],[-94.484796,33.637421],[-94.430026,35.395519],[-94.616242,36.501861],[-94.473842,36.501861]]]}}}},{{"type":"Feature","id":"06","properties":{{"name":"California","density":241.7,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-123.233256,42.006186],[-122.378853,42.011663],[-121.037003,41.995232],[-120.001861,41.995232],[-119.996384,40.264519],[-120.001861,38.999346],[-118.71478,38.101128],[-117.498899,37.21934],[-116.540435,36.501861],[-115.85034,35.970598],[-114.634459,35.00118],[-114.634459,34.87521],[-114.470151,34.710902],[-114.333228,34.448009],[-114.136058,34.305608],[-114.256551,34.174162],[-114.415382,34.108438],[-114.535874,33.933176],[-114.497536,33.697668],[-114.524921,33.54979],[-114.727567,33.40739],[-114.661844,33.034958],[-114.524921,33.029481],[-114.470151,32.843265],[-114.524921,32.755634],[-114.72209,32.717295],[-116.04751,32.624187],[-117.126467,32.536556],[-117.24696,32.668003],[-117.252437,32.876127],[-117.329114,33.122589],[-117.471515,33.297851],[-117.7837,33.538836],[-118.183517,33.763391],[-118.260194,33.703145],[-118.413548,33.741483],[-118.391641,33.840068],[-118.566903,34.042715],[-118.802411,33.998899],[-119.218659,34.146777],[-119.278905,34.26727],[-119.558229,34.415147],[-119.875891,34.40967],[-120.138784,34.475393],[-120.472878,34.448009],[-120.64814,34.579455],[-120.609801,34.858779],[-120.670048,34.902595],[-120.631709,35.099764],[-120.894602,35.247642],[-120.905556,35.450289],[-121.004141,35.461243],[-121.168449,35.636505],[-121.283465,35.674843],[-121.332757,35.784382],[-121.716143,36.195153],[-121.896882,36.315645],[-121.935221,36.638785],[-121.858544,36.6114],[-121.787344,36.803093],[-121.929744,36.978355],[-122.105006,36.956447],[-122.335038,37.115279],[-122.417192,37.241248],[-122.400761,37.361741],[-122.515777,37.520572],[-122.515777,37.783465],[-122.329561,37.783465],[-122.406238,38.15042],[-122.488392,38.112082],[-122.504823,37.931343],[-122.701993,37.893004],[-122.937501,38.029928],[-122.97584,38.265436],[-123.129194,38.451652],[-123.331841,38.566668],[-123.44138,38.698114],[-123.737134,38.95553],[-123.687842,39.032208],[-123.824765,39.366301],[-123.764519,39.552517],[-123.85215,39.831841],[-124.109566,40.105688],[-124.361506,40.259042],[-124.410798,40.439781],[-124.158859,40.877937],[-124.109566,41.025814],[-124.158859,41.14083],[-124.065751,41.442061],[-124.147905,41.715908],[-124.257444,41.781632],[-124.213628,42.000709],[-123.233256,42.006186]]]}}}},{{"type":"Feature","id":"08","properties":{{"name":"Colorado","density":49.33,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-107.919731,41.003906],[-105.728954,40.998429],[-104.053011,41.003906],[-102.053927,41.003906],[-102.053927,40.001626],[-102.042974,36.994786],[-103.001438,37.000263],[-104.337812,36.994786],[-106.868158,36.994786],[-107.421329,37.000263],[-109.042503,37.000263],[-109.042503,38.166851],[-109.058934,38.27639],[-109.053457,39.125316],[-109.04798,40.998429],[-107.919731,41.003906]]]}}}},{{"type":"Feature","id":"09","properties":{{"name":"Connecticut","density":739.1,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-73.053528,42.039048],[-71.799309,42.022617],[-71.799309,42.006186],[-71.799309,41.414677],[-71.859555,41.321569],[-71.947186,41.338],[-72.385341,41.261322],[-72.905651,41.28323],[-73.130205,41.146307],[-73.371191,41.102491],[-73.655992,40.987475],[-73.727192,41.102491],[-73.48073,41.21203],[-73.55193,41.294184],[-73.486206,42.050002],[-73.053528,42.039048]]]}}}},{{"type":"Feature","id":"10","properties":{{"name":"Delaware","density":464.3,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-75.414089,39.804456],[-75.507197,39.683964],[-75.611259,39.61824],[-75.589352,39.459409],[-75.441474,39.311532],[-75.403136,39.065069],[-75.189535,38.807653],[-75.09095,38.796699],[-75.047134,38.451652],[-75.693413,38.462606],[-75.786521,39.722302],[-75.616736,39.831841],[-75.414089,39.804456]]]}}}},{{"type":"Feature","id":"11","properties":{{"name":"District of Columbia","density":10065,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-77.035264,38.993869],[-76.909294,38.895284],[-77.040741,38.791222],[-77.117418,38.933623],[-77.035264,38.993869]]]}}}},{{"type":"Feature","id":"12","properties":{{"name":"Florida","density":353.4,"zone":2}},"geometry":{{"type":"Polygon","coordinates":[[[-85.497137,30.997536],[-85.004212,31.003013],[-84.867289,30.712735],[-83.498053,30.647012],[-82.216449,30.570335],[-82.167157,30.356734],[-82.046664,30.362211],[-82.002849,30.564858],[-82.041187,30.751074],[-81.948079,30.827751],[-81.718048,30.745597],[-81.444201,30.707258],[-81.383954,30.27458],[-81.257985,29.787132],[-80.967707,29.14633],[-80.524075,28.461713],[-80.589798,28.41242],[-80.56789,28.094758],[-80.381674,27.738757],[-80.091397,27.021277],[-80.03115,26.796723],[-80.036627,26.566691],[-80.146166,25.739673],[-80.239274,25.723243],[-80.337859,25.465826],[-80.304997,25.383672],[-80.49669,25.197456],[-80.573367,25.241272],[-80.759583,25.164595],[-81.077246,25.120779],[-81.170354,25.224841],[-81.126538,25.378195],[-81.351093,25.821827],[-81.526355,25.903982],[-81.679709,25.843735],[-81.800202,26.090198],[-81.833064,26.292844],[-82.041187,26.517399],[-82.09048,26.665276],[-82.057618,26.878877],[-82.172634,26.917216],[-82.145249,26.791246],[-82.249311,26.758384],[-82.566974,27.300601],[-82.692943,27.437525],[-82.391711,27.837342],[-82.588881,27.815434],[-82.720328,27.689464],[-82.851774,27.886634],[-82.676512,28.434328],[-82.643651,28.888914],[-82.764143,28.998453],[-82.802482,29.14633],[-82.994175,29.179192],[-83.218729,29.420177],[-83.399469,29.518762],[-83.410422,29.66664],[-83.536392,29.721409],[-83.640454,29.885717],[-84.02384,30.104795],[-84.357933,30.055502],[-84.341502,29.902148],[-84.451041,29.929533],[-84.867289,29.743317],[-85.310921,29.699501],[-85.299967,29.80904],[-85.404029,29.940487],[-85.924338,30.236241],[-86.29677,30.362211],[-86.630863,30.395073],[-86.910187,30.373165],[-87.518128,30.280057],[-87.37025,30.427934],[-87.446927,30.510088],[-87.408589,30.674397],[-87.633143,30.86609],[-87.600282,30.997536],[-85.497137,30.997536]]]}}}},{{"type":"Feature","id":"13","properties":{{"name":"Georgia","density":169.5,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-83.109191,35.00118],[-83.322791,34.787579],[-83.339222,34.683517],[-83.005129,34.469916],[-82.901067,34.486347],[-82.747713,34.26727],[-82.714851,34.152254],[-82.55602,33.94413],[-82.325988,33.81816],[-82.194542,33.631944],[-81.926172,33.462159],[-81.937125,33.347144],[-81.761863,33.160928],[-81.493493,33.007573],[-81.42777,32.843265],[-81.416816,32.629664],[-81.279893,32.558464],[-81.121061,32.290094],[-81.115584,32.120309],[-80.885553,32.032678],[-81.132015,31.693108],[-81.175831,31.517845],[-81.279893,31.364491],[-81.290846,31.20566],[-81.400385,31.13446],[-81.444201,30.707258],[-81.718048,30.745597],[-81.948079,30.827751],[-82.041187,30.751074],[-82.002849,30.564858],[-82.046664,30.362211],[-82.167157,30.356734],[-82.216449,30.570335],[-83.498053,30.647012],[-84.867289,30.712735],[-85.004212,31.003013],[-85.113751,31.27686],[-85.042551,31.539753],[-85.141136,31.840985],[-85.053504,32.01077],[-85.058981,32.13674],[-84.889196,32.262709],[-85.004212,32.322956],[-84.960397,32.421541],[-85.069935,32.580372],[-85.184951,32.859696],[-85.431413,34.124869],[-85.606675,34.984749],[-84.319594,34.990226],[-83.618546,34.984749],[-83.109191,35.00118]]]}}}},{{"type":"Feature","id":"15","properties":{{"name":"Hawaii","density":214.1,"zone":1}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-155.634835,18.948267],[-155.881297,19.035898],[-155.919636,19.123529],[-155.886774,19.348084],[-156.062036,19.73147],[-155.925113,19.857439],[-155.826528,20.032702],[-155.897728,20.147717],[-155.87582,20.26821],[-155.596496,20.12581],[-155.284311,20.021748],[-155.092618,19.868393],[-155.092618,19.736947],[-154.807817,19.523346],[-154.983079,19.348084],[-155.295265,19.26593],[-155.514342,19.134483],[-155.634835,18.948267]]],[[[-156.587823,21.029505],[-156.472807,20.892581],[-156.324929,20.952827],[-156.00179,20.793996],[-156.051082,20.651596],[-156.379699,20.580396],[-156.445422,20.60778],[-156.461853,20.783042],[-156.631638,20.821381],[-156.697361,20.919966],[-156.587823,21.029505]]],[[[-156.982162,21.210244],[-157.080747,21.106182],[-157.310779,21.106182],[-157.239579,21.221198],[-156.982162,21.210244]]],[[[-157.951581,21.697691],[-157.842042,21.462183],[-157.896811,21.325259],[-158.110412,21.303352],[-158.252813,21.582676],[-158.126843,21.588153],[-157.951581,21.697691]]],[[[-159.468693,22.228955],[-159.353678,22.218001],[-159.298908,22.113939],[-159.33177,21.966061],[-159.446786,21.872953],[-159.764448,21.987969],[-159.726109,22.152277],[-159.468693,22.228955]]]]}}}},{{"type":"Feature","id":"16","properties":{{"name":"Idaho","density":19.15,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-116.04751,49.000239],[-116.04751,47.976051],[-115.724371,47.696727],[-115.718894,47.42288],[-115.527201,47.302388],[-115.324554,47.258572],[-115.302646,47.187372],[-114.930214,46.919002],[-114.886399,46.809463],[-114.623506,46.705401],[-114.612552,46.639678],[-114.322274,46.645155],[-114.464674,46.272723],[-114.492059,46.037214],[-114.387997,45.88386],[-114.568736,45.774321],[-114.497536,45.670259],[-114.546828,45.560721],[-114.333228,45.456659],[-114.086765,45.593582],[-113.98818,45.703121],[-113.807441,45.604536],[-113.834826,45.522382],[-113.736241,45.330689],[-113.571933,45.128042],[-113.45144,45.056842],[-113.456917,44.865149],[-113.341901,44.782995],[-113.133778,44.772041],[-113.002331,44.448902],[-112.887315,44.394132],[-112.783254,44.48724],[-112.471068,44.481763],[-112.241036,44.569394],[-112.104113,44.520102],[-111.868605,44.563917],[-111.819312,44.509148],[-111.616665,44.547487],[-111.386634,44.75561],[-111.227803,44.580348],[-111.047063,44.476286],[-111.047063,42.000709],[-112.164359,41.995232],[-114.04295,41.995232],[-117.027882,42.000709],[-117.027882,43.830007],[-116.896436,44.158624],[-116.97859,44.240778],[-117.170283,44.257209],[-117.241483,44.394132],[-117.038836,44.750133],[-116.934774,44.782995],[-116.830713,44.930872],[-116.847143,45.02398],[-116.732128,45.144473],[-116.671881,45.319735],[-116.463758,45.61549],[-116.545912,45.752413],[-116.78142,45.823614],[-116.918344,45.993399],[-116.92382,46.168661],[-117.055267,46.343923],[-117.038836,46.426077],[-117.044313,47.762451],[-117.033359,49.000239],[-116.04751,49.000239]]]}}}},{{"type":"Feature","id":"17","properties":{{"name":"Illinois","density":231.5,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-90.639984,42.510065],[-88.788778,42.493634],[-87.802929,42.493634],[-87.83579,42.301941],[-87.682436,42.077386],[-87.523605,41.710431],[-87.529082,39.34987],[-87.63862,39.169131],[-87.512651,38.95553],[-87.49622,38.780268],[-87.62219,38.637868],[-87.655051,38.506421],[-87.83579,38.292821],[-87.950806,38.27639],[-87.923421,38.15042],[-88.000098,38.101128],[-88.060345,37.865619],[-88.027483,37.799896],[-88.15893,37.657496],[-88.065822,37.482234],[-88.476592,37.389126],[-88.514931,37.285064],[-88.421823,37.153617],[-88.547792,37.071463],[-88.914747,37.224817],[-89.029763,37.213863],[-89.183118,37.038601],[-89.133825,36.983832],[-89.292656,36.994786],[-89.517211,37.279587],[-89.435057,37.34531],[-89.517211,37.537003],[-89.517211,37.690357],[-89.84035,37.903958],[-89.949889,37.88205],[-90.059428,38.013497],[-90.355183,38.216144],[-90.349706,38.374975],[-90.179921,38.632391],[-90.207305,38.725499],[-90.10872,38.845992],[-90.251121,38.917192],[-90.470199,38.961007],[-90.585214,38.867899],[-90.661891,38.928146],[-90.727615,39.256762],[-91.061708,39.470363],[-91.368417,39.727779],[-91.494386,40.034488],[-91.50534,40.237135],[-91.417709,40.379535],[-91.401278,40.560274],[-91.121954,40.669813],[-91.09457,40.823167],[-90.963123,40.921752],[-90.946692,41.097014],[-91.111001,41.239415],[-91.045277,41.414677],[-90.656414,41.463969],[-90.344229,41.589939],[-90.311367,41.743293],[-90.179921,41.809016],[-90.141582,42.000709],[-90.168967,42.126679],[-90.393521,42.225264],[-90.420906,42.329326],[-90.639984,42.510065]]]}}}},{{"type":"Feature","id":"18","properties":{{"name":"Indiana","density":181.7,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-85.990061,41.759724],[-84.807042,41.759724],[-84.807042,41.694001],[-84.801565,40.500028],[-84.817996,39.103408],[-84.894673,39.059592],[-84.812519,38.785745],[-84.987781,38.780268],[-85.173997,38.68716],[-85.431413,38.730976],[-85.42046,38.533806],[-85.590245,38.451652],[-85.655968,38.325682],[-85.83123,38.27639],[-85.924338,38.024451],[-86.039354,37.958727],[-86.263908,38.051835],[-86.302247,38.166851],[-86.521325,38.040881],[-86.504894,37.931343],[-86.729448,37.893004],[-86.795172,37.991589],[-87.047111,37.893004],[-87.129265,37.788942],[-87.381204,37.93682],[-87.512651,37.903958],[-87.600282,37.975158],[-87.682436,37.903958],[-87.934375,37.893004],[-88.027483,37.799896],[-88.060345,37.865619],[-88.000098,38.101128],[-87.923421,38.15042],[-87.950806,38.27639],[-87.83579,38.292821],[-87.655051,38.506421],[-87.62219,38.637868],[-87.49622,38.780268],[-87.512651,38.95553],[-87.63862,39.169131],[-87.529082,39.34987],[-87.523605,41.710431],[-87.42502,41.644708],[-87.118311,41.644708],[-86.822556,41.759724],[-85.990061,41.759724]]]}}}},{{"type":"Feature","id":"19","properties":{{"name":"Iowa","density":54.81,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-91.368417,43.501391],[-91.215062,43.501391],[-91.204109,43.353514],[-91.056231,43.254929],[-91.176724,43.134436],[-91.143862,42.909881],[-91.067185,42.75105],[-90.711184,42.636034],[-90.639984,42.510065],[-90.420906,42.329326],[-90.393521,42.225264],[-90.168967,42.126679],[-90.141582,42.000709],[-90.179921,41.809016],[-90.311367,41.743293],[-90.344229,41.589939],[-90.656414,41.463969],[-91.045277,41.414677],[-91.111001,41.239415],[-90.946692,41.097014],[-90.963123,40.921752],[-91.09457,40.823167],[-91.121954,40.669813],[-91.401278,40.560274],[-91.417709,40.379535],[-91.527248,40.412397],[-91.729895,40.615043],[-91.833957,40.609566],[-93.257961,40.582182],[-94.632673,40.571228],[-95.7664,40.587659],[-95.881416,40.719105],[-95.826646,40.976521],[-95.925231,41.201076],[-95.919754,41.453015],[-96.095016,41.540646],[-96.122401,41.67757],[-96.062155,41.798063],[-96.127878,41.973325],[-96.264801,42.039048],[-96.44554,42.488157],[-96.631756,42.707235],[-96.544125,42.855112],[-96.511264,43.052282],[-96.434587,43.123482],[-96.560556,43.222067],[-96.527695,43.397329],[-96.582464,43.479483],[-96.451017,43.501391],[-91.368417,43.501391]]]}}}},{{"type":"Feature","id":"20","properties":{{"name":"Kansas","density":35.09,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-101.90605,40.001626],[-95.306337,40.001626],[-95.207752,39.908518],[-94.884612,39.831841],[-95.109167,39.541563],[-94.983197,39.442978],[-94.824366,39.20747],[-94.610765,39.158177],[-94.616242,37.000263],[-100.087706,37.000263],[-102.042974,36.994786],[-102.053927,40.001626],[-101.90605,40.001626]]]}}}},{{"type":"Feature","id":"21","properties":{{"name":"Kentucky","density":110,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-83.903347,38.769315],[-83.678792,38.632391],[-83.519961,38.703591],[-83.142052,38.626914],[-83.032514,38.725499],[-82.890113,38.758361],[-82.846298,38.588575],[-82.731282,38.561191],[-82.594358,38.424267],[-82.621743,38.123036],[-82.50125,37.931343],[-82.342419,37.783465],[-82.293127,37.668449],[-82.101434,37.553434],[-81.969987,37.537003],[-82.353373,37.268633],[-82.720328,37.120755],[-82.720328,37.044078],[-82.868205,36.978355],[-82.879159,36.890724],[-83.070852,36.852385],[-83.136575,36.742847],[-83.673316,36.600446],[-83.689746,36.584015],[-84.544149,36.594969],[-85.289013,36.627831],[-85.486183,36.616877],[-86.592525,36.655216],[-87.852221,36.633308],[-88.071299,36.677123],[-88.054868,36.496384],[-89.298133,36.507338],[-89.418626,36.496384],[-89.363857,36.622354],[-89.215979,36.578538],[-89.133825,36.983832],[-89.183118,37.038601],[-89.029763,37.213863],[-88.914747,37.224817],[-88.547792,37.071463],[-88.421823,37.153617],[-88.514931,37.285064],[-88.476592,37.389126],[-88.065822,37.482234],[-88.15893,37.657496],[-88.027483,37.799896],[-87.934375,37.893004],[-87.682436,37.903958],[-87.600282,37.975158],[-87.512651,37.903958],[-87.381204,37.93682],[-87.129265,37.788942],[-87.047111,37.893004],[-86.795172,37.991589],[-86.729448,37.893004],[-86.504894,37.931343],[-86.521325,38.040881],[-86.302247,38.166851],[-86.263908,38.051835],[-86.039354,37.958727],[-85.924338,38.024451],[-85.83123,38.27639],[-85.655968,38.325682],[-85.590245,38.451652],[-85.42046,38.533806],[-85.431413,38.730976],[-85.173997,38.68716],[-84.987781,38.780268],[-84.812519,38.785745],[-84.894673,39.059592],[-84.817996,39.103408],[-84.43461,39.103408],[-84.231963,38.895284],[-84.215533,38.807653],[-83.903347,38.769315]]]}}}},{{"type":"Feature","id":"22","properties":{{"name":"Louisiana","density":105,"zone":2}},"geometry":{{"type":"Polygon","coordinates":[[[-93.608485,33.018527],[-91.16577,33.002096],[-91.072662,32.887081],[-91.143862,32.843265],[-91.154816,32.640618],[-91.006939,32.514649],[-90.985031,32.218894],[-91.105524,31.988862],[-91.341032,31.846462],[-91.401278,31.621907],[-91.499863,31.643815],[-91.516294,31.27686],[-91.636787,31.265906],[-91.565587,31.068736],[-91.636787,30.997536],[-89.747242,30.997536],[-89.845827,30.66892],[-89.681519,30.449842],[-89.643181,30.285534],[-89.522688,30.181472],[-89.818443,30.044549],[-89.84035,29.945964],[-89.599365,29.88024],[-89.495303,30.039072],[-89.287179,29.88024],[-89.30361,29.754271],[-89.424103,29.699501],[-89.648657,29.748794],[-89.621273,29.655686],[-89.69795,29.513285],[-89.506257,29.387316],[-89.199548,29.348977],[-89.09001,29.2011],[-89.002379,29.179192],[-89.16121,29.009407],[-89.336472,29.042268],[-89.484349,29.217531],[-89.851304,29.310638],[-89.851304,29.480424],[-90.032043,29.425654],[-90.021089,29.283254],[-90.103244,29.151807],[-90.23469,29.129899],[-90.333275,29.277777],[-90.563307,29.283254],[-90.645461,29.129899],[-90.798815,29.086084],[-90.963123,29.179192],[-91.09457,29.190146],[-91.220539,29.436608],[-91.445094,29.546147],[-91.532725,29.529716],[-91.620356,29.73784],[-91.883249,29.710455],[-91.888726,29.836425],[-92.146142,29.715932],[-92.113281,29.622824],[-92.31045,29.535193],[-92.617159,29.579009],[-92.97316,29.715932],[-93.2251,29.776178],[-93.767317,29.726886],[-93.838517,29.688547],[-93.926148,29.787132],[-93.690639,30.143133],[-93.767317,30.334826],[-93.696116,30.438888],[-93.728978,30.575812],[-93.630393,30.679874],[-93.526331,30.93729],[-93.542762,31.15089],[-93.816609,31.556184],[-93.822086,31.775262],[-94.041164,31.994339],[-94.041164,33.018527],[-93.608485,33.018527]]]}}}},{{"type":"Feature","id":"23","properties":{{"name":"Maine","density":43.04,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-70.703921,43.057759],[-70.824413,43.128959],[-70.807983,43.227544],[-70.966814,43.34256],[-71.032537,44.657025],[-71.08183,45.303304],[-70.649151,45.440228],[-70.720352,45.511428],[-70.556043,45.664782],[-70.386258,45.735983],[-70.41912,45.796229],[-70.260289,45.889337],[-70.309581,46.064599],[-70.210996,46.327492],[-70.057642,46.415123],[-69.997395,46.694447],[-69.225147,47.461219],[-69.044408,47.428357],[-69.033454,47.242141],[-68.902007,47.176418],[-68.578868,47.285957],[-68.376221,47.285957],[-68.233821,47.357157],[-67.954497,47.198326],[-67.790188,47.066879],[-67.779235,45.944106],[-67.801142,45.675736],[-67.456095,45.604536],[-67.505388,45.48952],[-67.417757,45.379982],[-67.488957,45.281397],[-67.346556,45.128042],[-67.16034,45.160904],[-66.979601,44.804903],[-67.187725,44.646072],[-67.308218,44.706318],[-67.406803,44.596779],[-67.549203,44.624164],[-67.565634,44.531056],[-67.75185,44.54201],[-68.047605,44.328409],[-68.118805,44.476286],[-68.222867,44.48724],[-68.173574,44.328409],[-68.403606,44.251732],[-68.458375,44.377701],[-68.567914,44.311978],[-68.82533,44.311978],[-68.830807,44.459856],[-68.984161,44.426994],[-68.956777,44.322932],[-69.099177,44.103854],[-69.071793,44.043608],[-69.258008,43.923115],[-69.444224,43.966931],[-69.553763,43.840961],[-69.707118,43.82453],[-69.833087,43.720469],[-69.986442,43.742376],[-70.030257,43.851915],[-70.254812,43.676653],[-70.194565,43.567114],[-70.358873,43.528776],[-70.369827,43.435668],[-70.556043,43.320652],[-70.703921,43.057759]]]}}}},{{"type":"Feature","id":"24","properties":{{"name":"Maryland","density":596.3,"zone":4}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-75.994645,37.95325],[-76.016553,37.95325],[-76.043938,37.95325],[-75.994645,37.95325]]],[[[-79.477979,39.722302],[-75.786521,39.722302],[-75.693413,38.462606],[-75.047134,38.451652],[-75.244304,38.029928],[-75.397659,38.013497],[-75.671506,37.95325],[-75.885106,37.909435],[-75.879629,38.073743],[-75.961783,38.139466],[-75.846768,38.210667],[-76.000122,38.374975],[-76.049415,38.303775],[-76.257538,38.320205],[-76.328738,38.500944],[-76.263015,38.500944],[-76.257538,38.736453],[-76.191815,38.829561],[-76.279446,39.147223],[-76.169907,39.333439],[-76.000122,39.366301],[-75.972737,39.557994],[-76.098707,39.536086],[-76.104184,39.437501],[-76.367077,39.311532],[-76.443754,39.196516],[-76.460185,38.906238],[-76.55877,38.769315],[-76.514954,38.539283],[-76.383508,38.380452],[-76.399939,38.259959],[-76.317785,38.139466],[-76.3616,38.057312],[-76.591632,38.216144],[-76.920248,38.292821],[-77.018833,38.446175],[-77.205049,38.358544],[-77.276249,38.479037],[-77.128372,38.632391],[-77.040741,38.791222],[-76.909294,38.895284],[-77.035264,38.993869],[-77.117418,38.933623],[-77.248864,39.026731],[-77.456988,39.076023],[-77.456988,39.223901],[-77.566527,39.306055],[-77.719881,39.322485],[-77.834897,39.601809],[-78.004682,39.601809],[-78.174467,39.694917],[-78.267575,39.61824],[-78.431884,39.623717],[-78.470222,39.514178],[-78.765977,39.585379],[-78.963147,39.437501],[-79.094593,39.470363],[-79.291763,39.300578],[-79.488933,39.20747],[-79.477979,39.722302]]]]}}}},{{"type":"Feature","id":"25","properties":{{"name":"Massachusetts","density":840.2,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-70.917521,42.887974],[-70.818936,42.871543],[-70.780598,42.696281],[-70.824413,42.55388],[-70.983245,42.422434],[-70.988722,42.269079],[-70.769644,42.247172],[-70.638197,42.08834],[-70.660105,41.962371],[-70.550566,41.929509],[-70.539613,41.814493],[-70.260289,41.715908],[-69.937149,41.809016],[-70.008349,41.672093],[-70.484843,41.5516],[-70.660105,41.546123],[-70.764167,41.639231],[-70.928475,41.611847],[-70.933952,41.540646],[-71.120168,41.496831],[-71.196845,41.67757],[-71.22423,41.710431],[-71.328292,41.781632],[-71.383061,42.01714],[-71.530939,42.01714],[-71.799309,42.006186],[-71.799309,42.022617],[-73.053528,42.039048],[-73.486206,42.050002],[-73.508114,42.08834],[-73.267129,42.745573],[-72.456542,42.729142],[-71.29543,42.696281],[-71.185891,42.789389],[-70.917521,42.887974]]]}}}},{{"type":"Feature","id":"26","properties":{{"name":"Michigan","density":173.9,"zone":5}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-83.454238,41.732339],[-84.807042,41.694001],[-84.807042,41.759724],[-85.990061,41.759724],[-86.822556,41.759724],[-86.619909,41.891171],[-86.482986,42.115725],[-86.357016,42.252649],[-86.263908,42.444341],[-86.209139,42.718189],[-86.231047,43.013943],[-86.526801,43.594499],[-86.433693,43.813577],[-86.499417,44.07647],[-86.269385,44.34484],[-86.220093,44.569394],[-86.252954,44.689887],[-86.088646,44.73918],[-86.066738,44.903488],[-85.809322,44.947303],[-85.612152,45.128042],[-85.628583,44.766564],[-85.524521,44.750133],[-85.393075,44.930872],[-85.387598,45.237581],[-85.305444,45.314258],[-85.031597,45.363551],[-85.119228,45.577151],[-84.938489,45.75789],[-84.713934,45.768844],[-84.461995,45.653829],[-84.215533,45.637398],[-84.09504,45.494997],[-83.908824,45.484043],[-83.596638,45.352597],[-83.4871,45.358074],[-83.317314,45.144473],[-83.454238,45.029457],[-83.322791,44.88158],[-83.273499,44.711795],[-83.333745,44.339363],[-83.536392,44.246255],[-83.585684,44.054562],[-83.82667,43.988839],[-83.958116,43.758807],[-83.908824,43.671176],[-83.667839,43.589022],[-83.481623,43.714992],[-83.262545,43.972408],[-82.917498,44.070993],[-82.747713,43.994316],[-82.643651,43.851915],[-82.539589,43.435668],[-82.523158,43.227544],[-82.413619,42.975605],[-82.517681,42.614127],[-82.681989,42.559357],[-82.687466,42.690804],[-82.797005,42.652465],[-82.922975,42.351234],[-83.125621,42.236218],[-83.185868,42.006186],[-83.437807,41.814493],[-83.454238,41.732339]]],[[[-85.508091,45.730506],[-85.49166,45.610013],[-85.623106,45.588105],[-85.568337,45.75789],[-85.508091,45.730506]]],[[[-87.589328,45.095181],[-87.742682,45.199243],[-87.649574,45.341643],[-87.885083,45.363551],[-87.791975,45.500474],[-87.781021,45.675736],[-87.989145,45.796229],[-88.10416,45.922199],[-88.531362,46.020784],[-88.662808,45.987922],[-89.09001,46.135799],[-90.119674,46.338446],[-90.229213,46.508231],[-90.415429,46.568478],[-90.026566,46.672539],[-89.851304,46.793032],[-89.413149,46.842325],[-89.128348,46.990202],[-88.996902,46.995679],[-88.887363,47.099741],[-88.575177,47.247618],[-88.416346,47.373588],[-88.180837,47.455742],[-87.956283,47.384542],[-88.350623,47.077833],[-88.443731,46.973771],[-88.438254,46.787555],[-88.246561,46.929956],[-87.901513,46.908048],[-87.633143,46.809463],[-87.392158,46.535616],[-87.260711,46.486323],[-87.008772,46.530139],[-86.948526,46.469893],[-86.696587,46.437031],[-86.159846,46.667063],[-85.880522,46.68897],[-85.508091,46.678016],[-85.256151,46.754694],[-85.064458,46.760171],[-85.02612,46.480847],[-84.82895,46.442508],[-84.63178,46.486323],[-84.549626,46.4206],[-84.418179,46.502754],[-84.127902,46.530139],[-84.122425,46.179615],[-83.990978,46.031737],[-83.793808,45.993399],[-83.7719,46.091984],[-83.580208,46.091984],[-83.476146,45.987922],[-83.563777,45.911245],[-84.111471,45.976968],[-84.374364,45.933153],[-84.659165,46.053645],[-84.741319,45.944106],[-84.70298,45.850998],[-84.82895,45.872906],[-85.015166,46.00983],[-85.338305,46.091984],[-85.502614,46.097461],[-85.661445,45.966014],[-85.924338,45.933153],[-86.209139,45.960537],[-86.324155,45.905768],[-86.351539,45.796229],[-86.663725,45.703121],[-86.647294,45.834568],[-86.784218,45.861952],[-86.838987,45.725029],[-87.069019,45.719552],[-87.17308,45.659305],[-87.326435,45.423797],[-87.611236,45.122565],[-87.589328,45.095181]]],[[[-88.805209,47.976051],[-89.057148,47.850082],[-89.188594,47.833651],[-89.177641,47.937713],[-88.547792,48.173221],[-88.668285,48.008913],[-88.805209,47.976051]]]]}}}},{{"type":"Feature","id":"27","properties":{{"name":"Minnesota","density":67.14,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-92.014696,46.705401],[-92.091373,46.749217],[-92.29402,46.667063],[-92.29402,46.075553],[-92.354266,46.015307],[-92.639067,45.933153],[-92.869098,45.719552],[-92.885529,45.577151],[-92.770513,45.566198],[-92.644544,45.440228],[-92.75956,45.286874],[-92.737652,45.117088],[-92.808852,44.750133],[-92.545959,44.569394],[-92.337835,44.552964],[-92.233773,44.443425],[-91.927065,44.333886],[-91.877772,44.202439],[-91.592971,44.032654],[-91.43414,43.994316],[-91.242447,43.775238],[-91.269832,43.616407],[-91.215062,43.501391],[-91.368417,43.501391],[-96.451017,43.501391],[-96.451017,45.297827],[-96.681049,45.412843],[-96.856311,45.604536],[-96.582464,45.818137],[-96.560556,45.933153],[-96.598895,46.332969],[-96.719387,46.437031],[-96.801542,46.656109],[-96.785111,46.924479],[-96.823449,46.968294],[-96.856311,47.609096],[-97.053481,47.948667],[-97.130158,48.140359],[-97.16302,48.545653],[-97.097296,48.682577],[-97.228743,49.000239],[-95.152983,49.000239],[-95.152983,49.383625],[-94.955813,49.372671],[-94.824366,49.295994],[-94.69292,48.775685],[-94.588858,48.715438],[-94.260241,48.699007],[-94.221903,48.649715],[-93.838517,48.627807],[-93.794701,48.518268],[-93.466085,48.545653],[-93.466085,48.589469],[-93.208669,48.644238],[-92.984114,48.62233],[-92.726698,48.540176],[-92.655498,48.436114],[-92.50762,48.447068],[-92.370697,48.222514],[-92.304974,48.315622],[-92.053034,48.359437],[-92.009219,48.266329],[-91.713464,48.200606],[-91.713464,48.112975],[-91.565587,48.041775],[-91.264355,48.080113],[-91.083616,48.178698],[-90.837154,48.238944],[-90.749522,48.091067],[-90.579737,48.123929],[-90.377091,48.091067],[-90.141582,48.112975],[-89.873212,47.987005],[-89.615796,48.008913],[-89.637704,47.954144],[-89.971797,47.828174],[-90.437337,47.729589],[-90.738569,47.625527],[-91.171247,47.368111],[-91.357463,47.20928],[-91.642264,47.028541],[-92.091373,46.787555],[-92.014696,46.705401]]]}}}},{{"type":"Feature","id":"28","properties":{{"name":"Mississippi","density":63.5,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-88.471115,34.995703],[-88.202745,34.995703],[-88.098683,34.891641],[-88.241084,33.796253],[-88.471115,31.895754],[-88.394438,30.367688],[-88.503977,30.323872],[-88.744962,30.34578],[-88.843547,30.411504],[-89.084533,30.367688],[-89.418626,30.252672],[-89.522688,30.181472],[-89.643181,30.285534],[-89.681519,30.449842],[-89.845827,30.66892],[-89.747242,30.997536],[-91.636787,30.997536],[-91.565587,31.068736],[-91.636787,31.265906],[-91.516294,31.27686],[-91.499863,31.643815],[-91.401278,31.621907],[-91.341032,31.846462],[-91.105524,31.988862],[-90.985031,32.218894],[-91.006939,32.514649],[-91.154816,32.640618],[-91.143862,32.843265],[-91.072662,32.887081],[-91.16577,33.002096],[-91.089093,33.13902],[-91.143862,33.347144],[-91.056231,33.429298],[-91.231493,33.560744],[-91.072662,33.867453],[-90.891923,34.026284],[-90.952169,34.135823],[-90.744046,34.300131],[-90.749522,34.365854],[-90.568783,34.420624],[-90.585214,34.617794],[-90.481152,34.661609],[-90.409952,34.831394],[-90.251121,34.908072],[-90.311367,34.995703],[-88.471115,34.995703]]]}}}},{{"type":"Feature","id":"29","properties":{{"name":"Missouri","density":87.26,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-91.833957,40.609566],[-91.729895,40.615043],[-91.527248,40.412397],[-91.417709,40.379535],[-91.50534,40.237135],[-91.494386,40.034488],[-91.368417,39.727779],[-91.061708,39.470363],[-90.727615,39.256762],[-90.661891,38.928146],[-90.585214,38.867899],[-90.470199,38.961007],[-90.251121,38.917192],[-90.10872,38.845992],[-90.207305,38.725499],[-90.179921,38.632391],[-90.349706,38.374975],[-90.355183,38.216144],[-90.059428,38.013497],[-89.949889,37.88205],[-89.84035,37.903958],[-89.517211,37.690357],[-89.517211,37.537003],[-89.435057,37.34531],[-89.517211,37.279587],[-89.292656,36.994786],[-89.133825,36.983832],[-89.215979,36.578538],[-89.363857,36.622354],[-89.418626,36.496384],[-89.484349,36.496384],[-89.539119,36.496384],[-89.533642,36.249922],[-89.730812,35.997983],[-90.377091,35.997983],[-90.218259,36.184199],[-90.064905,36.304691],[-90.152536,36.496384],[-94.473842,36.501861],[-94.616242,36.501861],[-94.616242,37.000263],[-94.610765,39.158177],[-94.824366,39.20747],[-94.983197,39.442978],[-95.109167,39.541563],[-94.884612,39.831841],[-95.207752,39.908518],[-95.306337,40.001626],[-95.552799,40.264519],[-95.7664,40.587659],[-94.632673,40.571228],[-93.257961,40.582182],[-91.833957,40.609566]]]}}}},{{"type":"Feature","id":"30","properties":{{"name":"Montana","density":6.858,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-104.047534,49.000239],[-104.042057,47.861036],[-104.047534,45.944106],[-104.042057,44.996596],[-104.058488,44.996596],[-105.91517,45.002073],[-109.080842,45.002073],[-111.05254,45.002073],[-111.047063,44.476286],[-111.227803,44.580348],[-111.386634,44.75561],[-111.616665,44.547487],[-111.819312,44.509148],[-111.868605,44.563917],[-112.104113,44.520102],[-112.241036,44.569394],[-112.471068,44.481763],[-112.783254,44.48724],[-112.887315,44.394132],[-113.002331,44.448902],[-113.133778,44.772041],[-113.341901,44.782995],[-113.456917,44.865149],[-113.45144,45.056842],[-113.571933,45.128042],[-113.736241,45.330689],[-113.834826,45.522382],[-113.807441,45.604536],[-113.98818,45.703121],[-114.086765,45.593582],[-114.333228,45.456659],[-114.546828,45.560721],[-114.497536,45.670259],[-114.568736,45.774321],[-114.387997,45.88386],[-114.492059,46.037214],[-114.464674,46.272723],[-114.322274,46.645155],[-114.612552,46.639678],[-114.623506,46.705401],[-114.886399,46.809463],[-114.930214,46.919002],[-115.302646,47.187372],[-115.324554,47.258572],[-115.527201,47.302388],[-115.718894,47.42288],[-115.724371,47.696727],[-116.04751,47.976051],[-116.04751,49.000239],[-111.50165,48.994762],[-109.453274,49.000239],[-104.047534,49.000239]]]}}}},{{"type":"Feature","id":"31","properties":{{"name":"Nebraska","density":23.97,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-103.324578,43.002989],[-101.626726,42.997512],[-98.499393,42.997512],[-98.466531,42.94822],[-97.951699,42.767481],[-97.831206,42.866066],[-97.688806,42.844158],[-97.217789,42.844158],[-96.692003,42.657942],[-96.626279,42.515542],[-96.44554,42.488157],[-96.264801,42.039048],[-96.127878,41.973325],[-96.062155,41.798063],[-96.122401,41.67757],[-96.095016,41.540646],[-95.919754,41.453015],[-95.925231,41.201076],[-95.826646,40.976521],[-95.881416,40.719105],[-95.7664,40.587659],[-95.552799,40.264519],[-95.306337,40.001626],[-101.90605,40.001626],[-102.053927,40.001626],[-102.053927,41.003906],[-104.053011,41.003906],[-104.053011,43.002989],[-103.324578,43.002989]]]}}}},{{"type":"Feature","id":"32","properties":{{"name":"Nevada","density":24.8,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-117.027882,42.000709],[-114.04295,41.995232],[-114.048427,37.000263],[-114.048427,36.195153],[-114.152489,36.025367],[-114.251074,36.01989],[-114.371566,36.140383],[-114.738521,36.102045],[-114.678275,35.516012],[-114.596121,35.324319],[-114.574213,35.138103],[-114.634459,35.00118],[-115.85034,35.970598],[-116.540435,36.501861],[-117.498899,37.21934],[-118.71478,38.101128],[-120.001861,38.999346],[-119.996384,40.264519],[-120.001861,41.995232],[-118.698349,41.989755],[-117.027882,42.000709]]]}}}},{{"type":"Feature","id":"33","properties":{{"name":"New Hampshire","density":147,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-71.08183,45.303304],[-71.032537,44.657025],[-70.966814,43.34256],[-70.807983,43.227544],[-70.824413,43.128959],[-70.703921,43.057759],[-70.818936,42.871543],[-70.917521,42.887974],[-71.185891,42.789389],[-71.29543,42.696281],[-72.456542,42.729142],[-72.544173,42.80582],[-72.533219,42.953697],[-72.445588,43.008466],[-72.456542,43.150867],[-72.379864,43.572591],[-72.204602,43.769761],[-72.116971,43.994316],[-72.02934,44.07647],[-72.034817,44.322932],[-71.700724,44.41604],[-71.536416,44.585825],[-71.629524,44.750133],[-71.4926,44.914442],[-71.503554,45.013027],[-71.361154,45.270443],[-71.131122,45.243058],[-71.08183,45.303304]]]}}}},{{"type":"Feature","id":"34","properties":{{"name":"New Jersey","density":1189,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-74.236547,41.14083],[-73.902454,40.998429],[-74.022947,40.708151],[-74.187255,40.642428],[-74.274886,40.489074],[-74.001039,40.412397],[-73.979131,40.297381],[-74.099624,39.760641],[-74.411809,39.360824],[-74.614456,39.245808],[-74.795195,38.993869],[-74.888303,39.158177],[-75.178581,39.240331],[-75.534582,39.459409],[-75.55649,39.607286],[-75.561967,39.629194],[-75.507197,39.683964],[-75.414089,39.804456],[-75.145719,39.88661],[-75.129289,39.963288],[-74.82258,40.127596],[-74.773287,40.215227],[-75.058088,40.417874],[-75.069042,40.543843],[-75.195012,40.576705],[-75.205966,40.691721],[-75.052611,40.866983],[-75.134765,40.971045],[-74.882826,41.179168],[-74.828057,41.288707],[-74.69661,41.359907],[-74.236547,41.14083]]]}}}},{{"type":"Feature","id":"35","properties":{{"name":"New Mexico","density":17.16,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-107.421329,37.000263],[-106.868158,36.994786],[-104.337812,36.994786],[-103.001438,37.000263],[-103.001438,36.501861],[-103.039777,36.501861],[-103.045254,34.01533],[-103.067161,33.002096],[-103.067161,31.999816],[-106.616219,31.999816],[-106.643603,31.901231],[-106.528588,31.786216],[-108.210008,31.786216],[-108.210008,31.331629],[-109.04798,31.331629],[-109.042503,37.000263],[-107.421329,37.000263]]]}}}},{{"type":"Feature","id":"36","properties":{{"name":"New York","density":412.3,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-73.343806,45.013027],[-73.332852,44.804903],[-73.387622,44.618687],[-73.294514,44.437948],[-73.321898,44.246255],[-73.436914,44.043608],[-73.349283,43.769761],[-73.404052,43.687607],[-73.245221,43.523299],[-73.278083,42.833204],[-73.267129,42.745573],[-73.508114,42.08834],[-73.486206,42.050002],[-73.55193,41.294184],[-73.48073,41.21203],[-73.727192,41.102491],[-73.655992,40.987475],[-73.22879,40.905321],[-73.141159,40.965568],[-72.774204,40.965568],[-72.587988,40.998429],[-72.28128,41.157261],[-72.259372,41.042245],[-72.100541,40.992952],[-72.467496,40.845075],[-73.239744,40.625997],[-73.562884,40.582182],[-73.776484,40.593136],[-73.935316,40.543843],[-74.022947,40.708151],[-73.902454,40.998429],[-74.236547,41.14083],[-74.69661,41.359907],[-74.740426,41.431108],[-74.89378,41.436584],[-75.074519,41.60637],[-75.052611,41.754247],[-75.173104,41.869263],[-75.249781,41.863786],[-75.35932,42.000709],[-79.76278,42.000709],[-79.76278,42.252649],[-79.76278,42.269079],[-79.149363,42.55388],[-79.050778,42.690804],[-78.853608,42.783912],[-78.930285,42.953697],[-79.012439,42.986559],[-79.072686,43.260406],[-78.486653,43.375421],[-77.966344,43.369944],[-77.75822,43.34256],[-77.533665,43.233021],[-77.391265,43.276836],[-76.958587,43.271359],[-76.695693,43.34256],[-76.41637,43.523299],[-76.235631,43.528776],[-76.230154,43.802623],[-76.137046,43.961454],[-76.3616,44.070993],[-76.312308,44.196962],[-75.912491,44.366748],[-75.764614,44.514625],[-75.282643,44.848718],[-74.828057,45.018503],[-74.148916,44.991119],[-73.343806,45.013027]]]}}}},{{"type":"Feature","id":"37","properties":{{"name":"North Carolina","density":198.2,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-80.978661,36.562108],[-80.294043,36.545677],[-79.510841,36.5402],[-75.868676,36.551154],[-75.75366,36.151337],[-76.032984,36.189676],[-76.071322,36.140383],[-76.410893,36.080137],[-76.460185,36.025367],[-76.68474,36.008937],[-76.673786,35.937736],[-76.399939,35.987029],[-76.3616,35.943213],[-76.060368,35.992506],[-75.961783,35.899398],[-75.781044,35.937736],[-75.715321,35.696751],[-75.775568,35.581735],[-75.89606,35.570781],[-76.147999,35.324319],[-76.482093,35.313365],[-76.536862,35.14358],[-76.394462,34.973795],[-76.279446,34.940933],[-76.493047,34.661609],[-76.673786,34.694471],[-76.991448,34.667086],[-77.210526,34.60684],[-77.555573,34.415147],[-77.82942,34.163208],[-77.971821,33.845545],[-78.179944,33.916745],[-78.541422,33.851022],[-79.675149,34.80401],[-80.797922,34.820441],[-80.781491,34.935456],[-80.934845,35.105241],[-81.038907,35.044995],[-81.044384,35.149057],[-82.276696,35.198349],[-82.550543,35.160011],[-82.764143,35.066903],[-83.109191,35.00118],[-83.618546,34.984749],[-84.319594,34.990226],[-84.29221,35.225734],[-84.09504,35.247642],[-84.018363,35.41195],[-83.7719,35.559827],[-83.498053,35.565304],[-83.251591,35.718659],[-82.994175,35.773428],[-82.775097,35.997983],[-82.638174,36.063706],[-82.610789,35.965121],[-82.216449,36.156814],[-82.03571,36.118475],[-81.909741,36.304691],[-81.723525,36.353984],[-81.679709,36.589492],[-80.978661,36.562108]]]}}}},{{"type":"Feature","id":"38","properties":{{"name":"North Dakota","density":9.916,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-97.228743,49.000239],[-97.097296,48.682577],[-97.16302,48.545653],[-97.130158,48.140359],[-97.053481,47.948667],[-96.856311,47.609096],[-96.823449,46.968294],[-96.785111,46.924479],[-96.801542,46.656109],[-96.719387,46.437031],[-96.598895,46.332969],[-96.560556,45.933153],[-104.047534,45.944106],[-104.042057,47.861036],[-104.047534,49.000239],[-97.228743,49.000239]]]}}}},{{"type":"Feature","id":"39","properties":{{"name":"Ohio","density":281.9,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-80.518598,41.978802],[-80.518598,40.636951],[-80.666475,40.582182],[-80.595275,40.472643],[-80.600752,40.319289],[-80.737675,40.078303],[-80.830783,39.711348],[-81.219646,39.388209],[-81.345616,39.344393],[-81.455155,39.410117],[-81.57017,39.267716],[-81.685186,39.273193],[-81.811156,39.0815],[-81.783771,38.966484],[-81.887833,38.873376],[-82.03571,39.026731],[-82.221926,38.785745],[-82.172634,38.632391],[-82.293127,38.577622],[-82.331465,38.446175],[-82.594358,38.424267],[-82.731282,38.561191],[-82.846298,38.588575],[-82.890113,38.758361],[-83.032514,38.725499],[-83.142052,38.626914],[-83.519961,38.703591],[-83.678792,38.632391],[-83.903347,38.769315],[-84.215533,38.807653],[-84.231963,38.895284],[-84.43461,39.103408],[-84.817996,39.103408],[-84.801565,40.500028],[-84.807042,41.694001],[-83.454238,41.732339],[-83.065375,41.595416],[-82.933929,41.513262],[-82.835344,41.589939],[-82.616266,41.431108],[-82.479343,41.381815],[-82.013803,41.513262],[-81.739956,41.485877],[-81.444201,41.672093],[-81.011523,41.852832],[-80.518598,41.978802],[-80.518598,41.978802]]]}}}},{{"type":"Feature","id":"40","properties":{{"name":"Oklahoma","density":55.22,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-100.087706,37.000263],[-94.616242,37.000263],[-94.616242,36.501861],[-94.430026,35.395519],[-94.484796,33.637421],[-94.868182,33.74696],[-94.966767,33.861976],[-95.224183,33.960561],[-95.289906,33.87293],[-95.547322,33.878407],[-95.602092,33.933176],[-95.8376,33.834591],[-95.936185,33.889361],[-96.149786,33.840068],[-96.346956,33.686714],[-96.423633,33.774345],[-96.631756,33.845545],[-96.850834,33.845545],[-96.922034,33.960561],[-97.173974,33.736006],[-97.256128,33.861976],[-97.371143,33.823637],[-97.458774,33.905791],[-97.694283,33.982469],[-97.869545,33.851022],[-97.946222,33.987946],[-98.088623,34.004376],[-98.170777,34.113915],[-98.36247,34.157731],[-98.488439,34.064623],[-98.570593,34.146777],[-98.767763,34.135823],[-98.986841,34.223454],[-99.189488,34.2125],[-99.260688,34.404193],[-99.57835,34.415147],[-99.698843,34.382285],[-99.923398,34.573978],[-100.000075,34.563024],[-100.000075,36.501861],[-101.812942,36.501861],[-103.001438,36.501861],[-103.001438,37.000263],[-102.042974,36.994786],[-100.087706,37.000263]]]}}}},{{"type":"Feature","id":"41","properties":{{"name":"Oregon","density":40.33,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-123.211348,46.174138],[-123.11824,46.185092],[-122.904639,46.08103],[-122.811531,45.960537],[-122.762239,45.659305],[-122.247407,45.549767],[-121.809251,45.708598],[-121.535404,45.725029],[-121.217742,45.670259],[-121.18488,45.604536],[-120.637186,45.746937],[-120.505739,45.697644],[-120.209985,45.725029],[-119.963522,45.823614],[-119.525367,45.911245],[-119.125551,45.933153],[-118.988627,45.998876],[-116.918344,45.993399],[-116.78142,45.823614],[-116.545912,45.752413],[-116.463758,45.61549],[-116.671881,45.319735],[-116.732128,45.144473],[-116.847143,45.02398],[-116.830713,44.930872],[-116.934774,44.782995],[-117.038836,44.750133],[-117.241483,44.394132],[-117.170283,44.257209],[-116.97859,44.240778],[-116.896436,44.158624],[-117.027882,43.830007],[-117.027882,42.000709],[-118.698349,41.989755],[-120.001861,41.995232],[-121.037003,41.995232],[-122.378853,42.011663],[-123.233256,42.006186],[-124.213628,42.000709],[-124.356029,42.115725],[-124.432706,42.438865],[-124.416275,42.663419],[-124.553198,42.838681],[-124.454613,43.002989],[-124.383413,43.271359],[-124.235536,43.55616],[-124.169813,43.8081],[-124.060274,44.657025],[-124.076705,44.772041],[-123.97812,45.144473],[-123.939781,45.659305],[-123.994551,45.944106],[-123.945258,46.113892],[-123.545441,46.261769],[-123.370179,46.146753],[-123.211348,46.174138]]]}}}},{{"type":"Feature","id":"42","properties":{{"name":"Pennsylvania","density":284.3,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-79.76278,42.252649],[-79.76278,42.000709],[-75.35932,42.000709],[-75.249781,41.863786],[-75.173104,41.869263],[-75.052611,41.754247],[-75.074519,41.60637],[-74.89378,41.436584],[-74.740426,41.431108],[-74.69661,41.359907],[-74.828057,41.288707],[-74.882826,41.179168],[-75.134765,40.971045],[-75.052611,40.866983],[-75.205966,40.691721],[-75.195012,40.576705],[-75.069042,40.543843],[-75.058088,40.417874],[-74.773287,40.215227],[-74.82258,40.127596],[-75.129289,39.963288],[-75.145719,39.88661],[-75.414089,39.804456],[-75.616736,39.831841],[-75.786521,39.722302],[-79.477979,39.722302],[-80.518598,39.722302],[-80.518598,40.636951],[-80.518598,41.978802],[-80.518598,41.978802],[-80.332382,42.033571],[-79.76278,42.269079],[-79.76278,42.252649]]]}}}},{{"type":"Feature","id":"44","properties":{{"name":"Rhode Island","density":1006,"zone":5}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-71.196845,41.67757],[-71.120168,41.496831],[-71.317338,41.474923],[-71.196845,41.67757]]],[[[-71.530939,42.01714],[-71.383061,42.01714],[-71.328292,41.781632],[-71.22423,41.710431],[-71.344723,41.726862],[-71.448785,41.578985],[-71.481646,41.370861],[-71.859555,41.321569],[-71.799309,41.414677],[-71.799309,42.006186],[-71.530939,42.01714]]]]}}}},{{"type":"Feature","id":"45","properties":{{"name":"South Carolina","density":155.4,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-82.764143,35.066903],[-82.550543,35.160011],[-82.276696,35.198349],[-81.044384,35.149057],[-81.038907,35.044995],[-80.934845,35.105241],[-80.781491,34.935456],[-80.797922,34.820441],[-79.675149,34.80401],[-78.541422,33.851022],[-78.716684,33.80173],[-78.935762,33.637421],[-79.149363,33.380005],[-79.187701,33.171881],[-79.357487,33.007573],[-79.582041,33.007573],[-79.631334,32.887081],[-79.866842,32.755634],[-79.998289,32.613234],[-80.206412,32.552987],[-80.430967,32.399633],[-80.452875,32.328433],[-80.660998,32.246279],[-80.885553,32.032678],[-81.115584,32.120309],[-81.121061,32.290094],[-81.279893,32.558464],[-81.416816,32.629664],[-81.42777,32.843265],[-81.493493,33.007573],[-81.761863,33.160928],[-81.937125,33.347144],[-81.926172,33.462159],[-82.194542,33.631944],[-82.325988,33.81816],[-82.55602,33.94413],[-82.714851,34.152254],[-82.747713,34.26727],[-82.901067,34.486347],[-83.005129,34.469916],[-83.339222,34.683517],[-83.322791,34.787579],[-83.109191,35.00118],[-82.764143,35.066903]]]}}}},{{"type":"Feature","id":"46","properties":{{"name":"South Dakota","density":98.07,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-104.047534,45.944106],[-96.560556,45.933153],[-96.582464,45.818137],[-96.856311,45.604536],[-96.681049,45.412843],[-96.451017,45.297827],[-96.451017,43.501391],[-96.582464,43.479483],[-96.527695,43.397329],[-96.560556,43.222067],[-96.434587,43.123482],[-96.511264,43.052282],[-96.544125,42.855112],[-96.631756,42.707235],[-96.44554,42.488157],[-96.626279,42.515542],[-96.692003,42.657942],[-97.217789,42.844158],[-97.688806,42.844158],[-97.831206,42.866066],[-97.951699,42.767481],[-98.466531,42.94822],[-98.499393,42.997512],[-101.626726,42.997512],[-103.324578,43.002989],[-104.053011,43.002989],[-104.058488,44.996596],[-104.042057,44.996596],[-104.047534,45.944106]]]}}}},{{"type":"Feature","id":"47","properties":{{"name":"Tennessee","density":88.08,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-88.054868,36.496384],[-88.071299,36.677123],[-87.852221,36.633308],[-86.592525,36.655216],[-85.486183,36.616877],[-85.289013,36.627831],[-84.544149,36.594969],[-83.689746,36.584015],[-83.673316,36.600446],[-81.679709,36.589492],[-81.723525,36.353984],[-81.909741,36.304691],[-82.03571,36.118475],[-82.216449,36.156814],[-82.610789,35.965121],[-82.638174,36.063706],[-82.775097,35.997983],[-82.994175,35.773428],[-83.251591,35.718659],[-83.498053,35.565304],[-83.7719,35.559827],[-84.018363,35.41195],[-84.09504,35.247642],[-84.29221,35.225734],[-84.319594,34.990226],[-85.606675,34.984749],[-87.359296,35.00118],[-88.202745,34.995703],[-88.471115,34.995703],[-90.311367,34.995703],[-90.212782,35.023087],[-90.114197,35.198349],[-90.130628,35.439335],[-89.944412,35.603643],[-89.911551,35.756997],[-89.763673,35.811767],[-89.730812,35.997983],[-89.533642,36.249922],[-89.539119,36.496384],[-89.484349,36.496384],[-89.418626,36.496384],[-89.298133,36.507338],[-88.054868,36.496384]]]}}}},{{"type":"Feature","id":"48","properties":{{"name":"Texas","density":98.07,"zone":3}},"geometry":{{"type":"Polygon","coordinates":[[[-101.812942,36.501861],[-100.000075,36.501861],[-100.000075,34.563024],[-99.923398,34.573978],[-99.698843,34.382285],[-99.57835,34.415147],[-99.260688,34.404193],[-99.189488,34.2125],[-98.986841,34.223454],[-98.767763,34.135823],[-98.570593,34.146777],[-98.488439,34.064623],[-98.36247,34.157731],[-98.170777,34.113915],[-98.088623,34.004376],[-97.946222,33.987946],[-97.869545,33.851022],[-97.694283,33.982469],[-97.458774,33.905791],[-97.371143,33.823637],[-97.256128,33.861976],[-97.173974,33.736006],[-96.922034,33.960561],[-96.850834,33.845545],[-96.631756,33.845545],[-96.423633,33.774345],[-96.346956,33.686714],[-96.149786,33.840068],[-95.936185,33.889361],[-95.8376,33.834591],[-95.602092,33.933176],[-95.547322,33.878407],[-95.289906,33.87293],[-95.224183,33.960561],[-94.966767,33.861976],[-94.868182,33.74696],[-94.484796,33.637421],[-94.380734,33.544313],[-94.183564,33.593606],[-94.041164,33.54979],[-94.041164,33.018527],[-94.041164,31.994339],[-93.822086,31.775262],[-93.816609,31.556184],[-93.542762,31.15089],[-93.526331,30.93729],[-93.630393,30.679874],[-93.728978,30.575812],[-93.696116,30.438888],[-93.767317,30.334826],[-93.690639,30.143133],[-93.926148,29.787132],[-93.838517,29.688547],[-94.002825,29.68307],[-94.523134,29.546147],[-94.70935,29.622824],[-94.742212,29.787132],[-94.873659,29.672117],[-94.966767,29.699501],[-95.016059,29.557101],[-94.911997,29.496854],[-94.895566,29.310638],[-95.081782,29.113469],[-95.383014,28.867006],[-95.985477,28.604113],[-96.045724,28.647929],[-96.226463,28.582205],[-96.23194,28.642452],[-96.478402,28.598636],[-96.593418,28.724606],[-96.664618,28.697221],[-96.401725,28.439805],[-96.593418,28.357651],[-96.774157,28.406943],[-96.801542,28.226204],[-97.026096,28.039988],[-97.256128,27.694941],[-97.404005,27.333463],[-97.513544,27.360848],[-97.540929,27.229401],[-97.425913,27.262263],[-97.480682,26.99937],[-97.557359,26.988416],[-97.562836,26.840538],[-97.469728,26.758384],[-97.442344,26.457153],[-97.332805,26.353091],[-97.30542,26.161398],[-97.217789,25.991613],[-97.524498,25.887551],[-97.650467,26.018997],[-97.885976,26.06829],[-98.198161,26.057336],[-98.466531,26.221644],[-98.669178,26.238075],[-98.822533,26.369522],[-99.030656,26.413337],[-99.173057,26.539307],[-99.266165,26.840538],[-99.446904,27.021277],[-99.424996,27.174632],[-99.50715,27.33894],[-99.479765,27.48134],[-99.605735,27.640172],[-99.709797,27.656603],[-99.879582,27.799003],[-99.934351,27.979742],[-100.082229,28.14405],[-100.29583,28.280974],[-100.399891,28.582205],[-100.498476,28.66436],[-100.629923,28.905345],[-100.673738,29.102515],[-100.799708,29.244915],[-101.013309,29.370885],[-101.062601,29.458516],[-101.259771,29.535193],[-101.413125,29.754271],[-101.851281,29.803563],[-102.114174,29.792609],[-102.338728,29.869286],[-102.388021,29.765225],[-102.629006,29.732363],[-102.809745,29.524239],[-102.919284,29.190146],[-102.97953,29.184669],[-103.116454,28.987499],[-103.280762,28.982022],[-103.527224,29.135376],[-104.146119,29.381839],[-104.266611,29.513285],[-104.507597,29.639255],[-104.677382,29.924056],[-104.688336,30.181472],[-104.858121,30.389596],[-104.896459,30.570335],[-105.005998,30.685351],[-105.394861,30.855136],[-105.602985,31.085167],[-105.77277,31.167321],[-105.953509,31.364491],[-106.205448,31.468553],[-106.38071,31.731446],[-106.528588,31.786216],[-106.643603,31.901231],[-106.616219,31.999816],[-103.067161,31.999816],[-103.067161,33.002096],[-103.045254,34.01533],[-103.039777,36.501861],[-103.001438,36.501861],[-101.812942,36.501861]]]}}}},{{"type":"Feature","id":"49","properties":{{"name":"Utah","density":34.3,"zone":5}},"geometry":{{"type":"Polygon","coordinates":[[[-112.164359,41.995232],[-111.047063,42.000709],[-111.047063,40.998429],[-109.04798,40.998429],[-109.053457,39.125316],[-109.058934,38.27639],[-109.042503,38.166851],[-109.042503,37.000263],[-110.499369,37.00574],[-114.048427,37.000263],[-114.04295,41.995232],[-112.164359,41.995232]]]}}}},{{"type":"Feature","id":"50","properties":{{"name":"Vermont","density":67.73,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-71.503554,45.013027],[-71.4926,44.914442],[-71.629524,44.750133],[-71.536416,44.585825],[-71.700724,44.41604],[-72.034817,44.322932],[-72.02934,44.07647],[-72.116971,43.994316],[-72.204602,43.769761],[-72.379864,43.572591],[-72.456542,43.150867],[-72.445588,43.008466],[-72.533219,42.953697],[-72.544173,42.80582],[-72.456542,42.729142],[-73.267129,42.745573],[-73.278083,42.833204],[-73.245221,43.523299],[-73.404052,43.687607],[-73.349283,43.769761],[-73.436914,44.043608],[-73.321898,44.246255],[-73.294514,44.437948],[-73.387622,44.618687],[-73.332852,44.804903],[-73.343806,45.013027],[-72.308664,45.002073],[-71.503554,45.013027]]]}}}},{{"type":"Feature","id":"51","properties":{{"name":"Virginia","density":204.5,"zone":4}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-75.397659,38.013497],[-75.244304,38.029928],[-75.375751,37.860142],[-75.512674,37.799896],[-75.594828,37.569865],[-75.802952,37.197433],[-75.972737,37.120755],[-76.027507,37.257679],[-75.939876,37.564388],[-75.671506,37.95325],[-75.397659,38.013497]]],[[[-76.016553,37.95325],[-75.994645,37.95325],[-76.043938,37.95325],[-76.016553,37.95325]]],[[[-78.349729,39.464886],[-77.82942,39.130793],[-77.719881,39.322485],[-77.566527,39.306055],[-77.456988,39.223901],[-77.456988,39.076023],[-77.248864,39.026731],[-77.117418,38.933623],[-77.040741,38.791222],[-77.128372,38.632391],[-77.248864,38.588575],[-77.325542,38.446175],[-77.281726,38.342113],[-77.013356,38.374975],[-76.964064,38.216144],[-76.613539,38.15042],[-76.514954,38.024451],[-76.235631,37.887527],[-76.3616,37.608203],[-76.246584,37.389126],[-76.383508,37.285064],[-76.399939,37.159094],[-76.273969,37.082417],[-76.410893,36.961924],[-76.619016,37.120755],[-76.668309,37.065986],[-76.48757,36.95097],[-75.994645,36.923586],[-75.868676,36.551154],[-79.510841,36.5402],[-80.294043,36.545677],[-80.978661,36.562108],[-81.679709,36.589492],[-83.673316,36.600446],[-83.136575,36.742847],[-83.070852,36.852385],[-82.879159,36.890724],[-82.868205,36.978355],[-82.720328,37.044078],[-82.720328,37.120755],[-82.353373,37.268633],[-81.969987,37.537003],[-81.986418,37.454849],[-81.849494,37.285064],[-81.679709,37.20291],[-81.55374,37.208387],[-81.362047,37.339833],[-81.225123,37.235771],[-80.967707,37.290541],[-80.513121,37.482234],[-80.474782,37.421987],[-80.29952,37.509618],[-80.294043,37.690357],[-80.184505,37.849189],[-79.998289,37.997066],[-79.921611,38.177805],[-79.724442,38.364021],[-79.647764,38.594052],[-79.477979,38.457129],[-79.313671,38.413313],[-79.209609,38.495467],[-78.996008,38.851469],[-78.870039,38.763838],[-78.404499,39.169131],[-78.349729,39.464886]]]]}}}},{{"type":"Feature","id":"53","properties":{{"name":"Washington","density":102.6,"zone":4}},"geometry":{{"type":"MultiPolygon","coordinates":[[[[-117.033359,49.000239],[-117.044313,47.762451],[-117.038836,46.426077],[-117.055267,46.343923],[-116.92382,46.168661],[-116.918344,45.993399],[-118.988627,45.998876],[-119.125551,45.933153],[-119.525367,45.911245],[-119.963522,45.823614],[-120.209985,45.725029],[-120.505739,45.697644],[-120.637186,45.746937],[-121.18488,45.604536],[-121.217742,45.670259],[-121.535404,45.725029],[-121.809251,45.708598],[-122.247407,45.549767],[-122.762239,45.659305],[-122.811531,45.960537],[-122.904639,46.08103],[-123.11824,46.185092],[-123.211348,46.174138],[-123.370179,46.146753],[-123.545441,46.261769],[-123.72618,46.300108],[-123.874058,46.239861],[-124.065751,46.327492],[-124.027412,46.464416],[-123.895966,46.535616],[-124.098612,46.74374],[-124.235536,47.285957],[-124.31769,47.357157],[-124.427229,47.740543],[-124.624399,47.88842],[-124.706553,48.184175],[-124.597014,48.381345],[-124.394367,48.288237],[-123.983597,48.162267],[-123.704273,48.167744],[-123.424949,48.118452],[-123.162056,48.167744],[-123.036086,48.080113],[-122.800578,48.08559],[-122.636269,47.866512],[-122.515777,47.882943],[-122.493869,47.587189],[-122.422669,47.318818],[-122.324084,47.346203],[-122.422669,47.576235],[-122.395284,47.800789],[-122.230976,48.030821],[-122.362422,48.123929],[-122.373376,48.288237],[-122.471961,48.468976],[-122.422669,48.600422],[-122.488392,48.753777],[-122.647223,48.775685],[-122.795101,48.8907],[-122.756762,49.000239],[-117.033359,49.000239]]],[[[-122.718423,48.310145],[-122.586977,48.35396],[-122.608885,48.151313],[-122.767716,48.227991],[-122.718423,48.310145]]],[[[-123.025132,48.583992],[-122.915593,48.715438],[-122.767716,48.556607],[-122.811531,48.419683],[-123.041563,48.458022],[-123.025132,48.583992]]]]}}}},{{"type":"Feature","id":"54","properties":{{"name":"West Virginia","density":77.06,"zone":4}},"geometry":{{"type":"Polygon","coordinates":[[[-80.518598,40.636951],[-80.518598,39.722302],[-79.477979,39.722302],[-79.488933,39.20747],[-79.291763,39.300578],[-79.094593,39.470363],[-78.963147,39.437501],[-78.765977,39.585379],[-78.470222,39.514178],[-78.431884,39.623717],[-78.267575,39.61824],[-78.174467,39.694917],[-78.004682,39.601809],[-77.834897,39.601809],[-77.719881,39.322485],[-77.82942,39.130793],[-78.349729,39.464886],[-78.404499,39.169131],[-78.870039,38.763838],[-78.996008,38.851469],[-79.209609,38.495467],[-79.313671,38.413313],[-79.477979,38.457129],[-79.647764,38.594052],[-79.724442,38.364021],[-79.921611,38.177805],[-79.998289,37.997066],[-80.184505,37.849189],[-80.294043,37.690357],[-80.29952,37.509618],[-80.474782,37.421987],[-80.513121,37.482234],[-80.967707,37.290541],[-81.225123,37.235771],[-81.362047,37.339833],[-81.55374,37.208387],[-81.679709,37.20291],[-81.849494,37.285064],[-81.986418,37.454849],[-81.969987,37.537003],[-82.101434,37.553434],[-82.293127,37.668449],[-82.342419,37.783465],[-82.50125,37.931343],[-82.621743,38.123036],[-82.594358,38.424267],[-82.331465,38.446175],[-82.293127,38.577622],[-82.172634,38.632391],[-82.221926,38.785745],[-82.03571,39.026731],[-81.887833,38.873376],[-81.783771,38.966484],[-81.811156,39.0815],[-81.685186,39.273193],[-81.57017,39.267716],[-81.455155,39.410117],[-81.345616,39.344393],[-81.219646,39.388209],[-80.830783,39.711348],[-80.737675,40.078303],[-80.600752,40.319289],[-80.595275,40.472643],[-80.666475,40.582182],[-80.518598,40.636951]]]}}}},{{"type":"Feature","id":"55","properties":{{"name":"Wisconsin","density":105.2,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-90.415429,46.568478],[-90.229213,46.508231],[-90.119674,46.338446],[-89.09001,46.135799],[-88.662808,45.987922],[-88.531362,46.020784],[-88.10416,45.922199],[-87.989145,45.796229],[-87.781021,45.675736],[-87.791975,45.500474],[-87.885083,45.363551],[-87.649574,45.341643],[-87.742682,45.199243],[-87.589328,45.095181],[-87.627666,44.974688],[-87.819359,44.95278],[-87.983668,44.722749],[-88.043914,44.563917],[-87.928898,44.536533],[-87.775544,44.640595],[-87.611236,44.837764],[-87.403112,44.914442],[-87.238804,45.166381],[-87.03068,45.22115],[-87.047111,45.089704],[-87.189511,44.969211],[-87.468835,44.552964],[-87.545512,44.322932],[-87.540035,44.158624],[-87.644097,44.103854],[-87.737205,43.8793],[-87.704344,43.687607],[-87.791975,43.561637],[-87.912467,43.249452],[-87.885083,43.002989],[-87.76459,42.783912],[-87.802929,42.493634],[-88.788778,42.493634],[-90.639984,42.510065],[-90.711184,42.636034],[-91.067185,42.75105],[-91.143862,42.909881],[-91.176724,43.134436],[-91.056231,43.254929],[-91.204109,43.353514],[-91.215062,43.501391],[-91.269832,43.616407],[-91.242447,43.775238],[-91.43414,43.994316],[-91.592971,44.032654],[-91.877772,44.202439],[-91.927065,44.333886],[-92.233773,44.443425],[-92.337835,44.552964],[-92.545959,44.569394],[-92.808852,44.750133],[-92.737652,45.117088],[-92.75956,45.286874],[-92.644544,45.440228],[-92.770513,45.566198],[-92.885529,45.577151],[-92.869098,45.719552],[-92.639067,45.933153],[-92.354266,46.015307],[-92.29402,46.075553],[-92.29402,46.667063],[-92.091373,46.749217],[-92.014696,46.705401],[-91.790141,46.694447],[-91.09457,46.864232],[-90.837154,46.95734],[-90.749522,46.88614],[-90.886446,46.754694],[-90.55783,46.584908],[-90.415429,46.568478]]]}}}},{{"type":"Feature","id":"56","properties":{{"name":"Wyoming","density":5.851,"zone":6}},"geometry":{{"type":"Polygon","coordinates":[[[-109.080842,45.002073],[-105.91517,45.002073],[-104.058488,44.996596],[-104.053011,43.002989],[-104.053011,41.003906],[-105.728954,40.998429],[-107.919731,41.003906],[-109.04798,40.998429],[-111.047063,40.998429],[-111.047063,42.000709],[-111.047063,44.476286],[-111.05254,45.002073],[-109.080842,45.002073]]]}}}},{{"type":"Feature","id":"72","properties":{{"name":"Puerto Rico","density":1082,"zone":1}},"geometry":{{"type":"Polygon","coordinates":[[[-66.448338,17.984326],[-66.771478,18.006234],[-66.924832,17.929556],[-66.985078,17.973372],[-67.209633,17.956941],[-67.154863,18.19245],[-67.269879,18.362235],[-67.094617,18.515589],[-66.957694,18.488204],[-66.409999,18.488204],[-65.840398,18.433435],[-65.632274,18.367712],[-65.626797,18.203403],[-65.730859,18.186973],[-65.834921,18.017187],[-66.234737,17.929556],[-66.448338,17.984326]]]}}}}]}};

// Initialize the full map with clustering - NOW LOADS DATA ON DEMAND
async function initFullMap() {{
    if (fullMap) return;

    // Show loading message in map container
    const mapContainer = document.getElementById('full-map');
    if (mapContainer) {{
        mapContainer.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#666;">Loading map data...</div>';
    }}

    // Load map data on demand (only when user clicks map tab)
    await loadMapData();

    // Clear loading message
    if (mapContainer) {{
        mapContainer.innerHTML = '';
    }}

    mapboxgl.accessToken = CONFIG.mapboxToken;
    fullMap = new mapboxgl.Map({{
        container: 'full-map',
        style: 'mapbox://styles/mapbox/light-v11',
        center: [-98.5795, 39.8283],  // US center
        zoom: 3
    }});

    fullMap.on('load', () => {{
        const geojson = buildingsGeoJSON();

        // Add climate zones source and layers (behind buildings)
        fullMap.addSource('climate-zones', {{
            type: 'geojson',
            data: CLIMATE_ZONES
        }});

        // Climate zone fill layer
        fullMap.addLayer({{
            id: 'climate-zone-fill',
            type: 'fill',
            source: 'climate-zones',
            paint: {{
                'fill-color': [
                    'match', ['get', 'zone'],
                    1, '#ff4444',
                    2, '#ff8844',
                    3, '#ffcc44',
                    4, '#88cc44',
                    5, '#44cc88',
                    6, '#4488cc',
                    7, '#4444cc',
                    8, '#8844cc',
                    '#cccccc'
                ],
                'fill-opacity': [
                    'interpolate', ['linear'], ['zoom'],
                    3, 0.4,
                    5, 0.2,
                    7, 0
                ]
            }}
        }});

        // Climate zone boundary outlines
        fullMap.addLayer({{
            id: 'climate-zone-outline',
            type: 'line',
            source: 'climate-zones',
            paint: {{
                'line-color': '#ffffff',
                'line-width': 1,
                'line-opacity': [
                    'interpolate', ['linear'], ['zoom'],
                    3, 0.6,
                    5, 0.3,
                    7, 0
                ]
            }}
        }});

        // Add clustered source
        fullMap.addSource('buildings', {{
            type: 'geojson',
            data: geojson,
            cluster: true,
            clusterMaxZoom: 14,
            clusterRadius: 50
        }});

        // Cluster circles - color by count
        fullMap.addLayer({{
            id: 'clusters',
            type: 'circle',
            source: 'buildings',
            filter: ['has', 'point_count'],
            paint: {{
                'circle-color': ['step', ['get', 'point_count'],
                    '#1b95ff', 100,    // < 100: mid blue
                    '#0066cc', 500,    // < 500: primary blue
                    '#0052a3'          // 500+: dark blue
                ],
                'circle-radius': ['step', ['get', 'point_count'],
                    18, 100,
                    24, 500,
                    32
                ],
                'circle-stroke-width': 2,
                'circle-stroke-color': '#ffffff'
            }}
        }});

        // Cluster count labels - BIG and BOLD
        fullMap.addLayer({{
            id: 'cluster-count',
            type: 'symbol',
            source: 'buildings',
            filter: ['has', 'point_count'],
            layout: {{
                'text-field': '{{point_count_abbreviated}}',
                'text-size': ['step', ['get', 'point_count'], 14, 100, 16, 500, 18],
                'text-font': ['DIN Offc Pro Bold', 'Arial Unicode MS Bold'],
                'text-allow-overlap': true
            }},
            paint: {{
                'text-color': '#ffffff',
                'text-halo-color': '#0052a3',
                'text-halo-width': 1.5
            }}
        }});

        // Individual pins (unclustered)
        fullMap.addLayer({{
            id: 'unclustered-point',
            type: 'circle',
            source: 'buildings',
            filter: ['!', ['has', 'point_count']],
            paint: {{
                'circle-color': '#0066cc',
                'circle-radius': 8,
                'circle-stroke-width': 2,
                'circle-stroke-color': '#ffffff'
            }}
        }});

        // Hover highlight layer (orange ring behind hovered pin)
        fullMap.addLayer({{
            id: 'hover-highlight',
            type: 'circle',
            source: 'buildings',
            filter: ['==', ['get', 'id'], ''],
            paint: {{
                'circle-radius': 14,
                'circle-color': '#ff6600',
                'circle-stroke-width': 3,
                'circle-stroke-color': '#ffffff',
                'circle-opacity': 0.8
            }}
        }});

        // Badge showing count for stacked pins (multiple buildings at same location)
        fullMap.addLayer({{
            id: 'stacked-count',
            type: 'symbol',
            source: 'buildings',
            filter: ['all',
                ['!', ['has', 'point_count']],
                ['>', ['get', 'stackCount'], 1]
            ],
            layout: {{
                'text-field': ['get', 'stackCount'],
                'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
                'text-size': 10,
                'text-offset': [0.7, -0.7],
                'text-anchor': 'bottom-left'
            }},
            paint: {{
                'text-color': '#ffffff',
                'text-halo-color': '#0066cc',
                'text-halo-width': 2
            }}
        }});

        // Fade climate legend when zoomed in
        fullMap.on('zoom', () => {{
            const zoom = fullMap.getZoom();
            const legend = document.getElementById('climate-legend');
            if (legend) {{
                if (zoom >= 7) {{
                    legend.style.opacity = '0';
                    legend.style.pointerEvents = 'none';
                }} else if (zoom >= 5) {{
                    legend.style.opacity = '0.5';
                    legend.style.pointerEvents = 'auto';
                }} else {{
                    legend.style.opacity = '1';
                    legend.style.pointerEvents = 'auto';
                }}
            }}
        }});

        setupMapInteractions(fullMap);
    }});
}}

// Spiderfy: spread out stacked pins at same location
let spiderfiedMarkers = [];

function spiderfyStack(stackKey, centerLng, centerLat, map) {{
    clearSpiderfy();

    // Get all buildings at this location (MAP_DATA loaded on demand)
    if (!MAP_DATA) return;
    const stackedBuildings = MAP_DATA.filter(b => `${{b.lat}},${{b.lon}}` === stackKey);
    if (stackedBuildings.length <= 1) return;

    // Calculate positions in a circle
    const radius = 0.00015;  // ~15 meters at equator
    const angleStep = (2 * Math.PI) / stackedBuildings.length;

    stackedBuildings.forEach((b, i) => {{
        const angle = i * angleStep - Math.PI / 2;  // Start from top
        const offsetLng = centerLng + radius * Math.cos(angle);
        const offsetLat = centerLat + radius * Math.sin(angle);

        // Create marker element
        const el = document.createElement('div');
        el.className = 'spiderfy-marker';
        el.innerHTML = '<div class="spiderfy-pin"></div>';

        // Create popup
        const spiderLogoHtml = expandedPortfolioLogo
            ? `<div style="background:#f3f4f6;padding:8px 12px;display:flex;align-items:center;border-radius:6px 6px 0 0;"><img src="${{expandedPortfolioLogo}}" style="height:28px;max-width:100px;object-fit:contain;" onerror="this.parentElement.style.display='none'"></div>`
            : '';
        const imgHtml = b.image
            ? `<img src="${{CONFIG.awsBucket}}/thumbnails/${{b.image}}" style="width:100%;height:80px;object-fit:cover;${{expandedPortfolioLogo ? '' : 'border-radius:6px 6px 0 0;'}}">`
            : '';
        const popup = new mapboxgl.Popup({{ offset: 25, closeButton: true }})
            .setHTML(`
                <div style="min-width:200px;">
                    ${{spiderLogoHtml}}
                    ${{imgHtml}}
                    <div style="padding:10px;">
                        <div style="font-weight:600;color:#0066cc;">${{b.address}}</div>
                        <div style="color:#666;font-size:12px;">${{b.city}}, ${{b.state}}</div>
                        <div style="color:#666;font-size:12px;">${{b.type}}</div>
                        <div style="color:${{savingsColor(b.total_opex)}};font-weight:600;margin-top:6px;">${{formatMoney(b.total_opex)}}/yr</div>
                        <div style="font-size:11px;color:#999;margin-top:4px;">Click pin to view details</div>
                    </div>
                </div>
            `);

        // Create and add marker
        const marker = new mapboxgl.Marker(el)
            .setLngLat([offsetLng, offsetLat])
            .setPopup(popup)
            .addTo(map);

        // Click to navigate
        el.addEventListener('click', (e) => {{
            e.stopPropagation();
            const fromTab = document.querySelector('.main-tab.active')?.dataset.tab === 'all-buildings' ? 'cities' : 'portfolios';
            window.location.href = `buildings/${{b.id}}.html?from=${{fromTab}}`;
        }});

        spiderfiedMarkers.push(marker);
    }});

    // Zoom in slightly to show spread
    map.easeTo({{
        center: [centerLng, centerLat],
        zoom: Math.max(map.getZoom(), 17)
    }});
}}

function clearSpiderfy() {{
    spiderfiedMarkers.forEach(m => m.remove());
    spiderfiedMarkers = [];
}}

// Setup map interactions: popups, hover, click
function setupMapInteractions(map) {{
    // Popup for hovering unclustered pins
    const popup = new mapboxgl.Popup({{
        closeButton: false,
        closeOnClick: false,
        offset: [0, -12],
        maxWidth: '280px',
        className: 'pin-popup'
    }});

    // Track hovered building to avoid redundant updates
    let hoveredId = null;

    // Use mousemove for smoother hover detection (like NYC implementation)
    map.on('mousemove', 'unclustered-point', (e) => {{
        map.getCanvas().style.cursor = 'pointer';
        const props = e.features[0].properties;
        const coords = e.features[0].geometry.coordinates.slice();

        // Skip if same building (avoid redundant popup updates)
        if (hoveredId === props.id) return;
        hoveredId = props.id;

        // Update hover highlight layer
        if (map.getLayer('hover-highlight')) {{
            map.setFilter('hover-highlight', ['==', ['get', 'id'], props.id]);
        }}

        // Portfolio logo header (shown when a portfolio is expanded)
        const logoHtml = expandedPortfolioLogo
            ? `<div style="background:#f3f4f6;padding:8px 12px;display:flex;align-items:center;border-radius:6px 6px 0 0;"><img src="${{expandedPortfolioLogo}}" style="height:32px;max-width:120px;object-fit:contain;" onerror="this.parentElement.style.display='none'"></div>`
            : '';

        const imgHtml = props.image
            ? `<img src="${{CONFIG.awsBucket}}/thumbnails/${{props.image}}" style="width:100%;height:100px;object-fit:cover;${{expandedPortfolioLogo ? '' : 'border-radius:6px 6px 0 0;'}}" onerror="this.style.display='none'">`
            : '';

        popup.setLngLat(coords)
            .setHTML(`
                <div style="min-width:250px;cursor:pointer;" onclick="window.location.href='buildings/${{props.id}}.html?from=' + (document.querySelector('.main-tab.active')?.dataset.tab === 'all-buildings' ? 'cities' : 'portfolios')">
                    ${{logoHtml}}
                    ${{imgHtml}}
                    <div style="padding:12px;">
                        <div style="font-weight:600;font-size:14px;margin-bottom:4px;color:#0066cc;">${{props.address}}</div>
                        ${{props.property_name ? `<div style="font-size:12px;color:#333;margin-bottom:4px;">${{props.property_name}}</div>` : ''}}
                        <div style="color:#666;font-size:12px;margin-bottom:8px;">${{props.city}}, ${{props.state}} &bull; ${{props.type}}</div>
                        ${{props.owner ? `<div style="font-size:13px;color:#666;margin-bottom:4px;"><strong>Owner:</strong> ${{props.owner}}</div>` : ''}}
                        ${{props.manager ? `<div style="font-size:13px;color:#666;margin-bottom:4px;"><strong>Manager:</strong> ${{props.manager}}</div>` : ''}}
                        <div style="color:${{savingsColor(props.opex)}};font-weight:600;font-size:14px;margin-top:8px;padding-top:8px;border-top:1px solid #eee;">
                            Savings: ${{formatMoney(props.opex)}}/yr
                        </div>
                        <div style="font-size:11px;color:#999;margin-top:6px;text-align:center;">Click for details &rarr;</div>
                    </div>
                </div>
            `)
            .addTo(map);

        // Highlight table row
        highlightTableRow(props.id);
    }});

    map.on('mouseleave', 'unclustered-point', () => {{
        map.getCanvas().style.cursor = '';
        hoveredId = null;
        popup.remove();
        clearTableHighlight();
        // Clear hover highlight
        if (map.getLayer('hover-highlight')) {{
            map.setFilter('hover-highlight', ['==', ['get', 'id'], '']);
        }}
    }});

    // Click pin → spiderfy if stacked, else navigate to building
    map.on('click', 'unclustered-point', (e) => {{
        const props = e.features[0].properties;
        const coords = e.features[0].geometry.coordinates;

        // If multiple buildings at this location, spiderfy them
        if (props.stackCount > 1) {{
            spiderfyStack(props.stackKey, coords[0], coords[1], map);
            return;
        }}

        // Single building → navigate
        const fromTab = document.querySelector('.main-tab.active')?.dataset.tab === 'all-buildings' ? 'cities' : 'portfolios';
        window.location.href = `buildings/${{props.id}}.html?from=${{fromTab}}`;
    }});

    // Click elsewhere on map → clear spiderfied markers
    map.on('click', (e) => {{
        // Only clear if not clicking on a feature
        const features = map.queryRenderedFeatures(e.point, {{ layers: ['unclustered-point', 'clusters'] }});
        if (features.length === 0) {{
            clearSpiderfy();
        }}
    }});

    // Click cluster → zoom in
    map.on('click', 'clusters', (e) => {{
        const features = map.queryRenderedFeatures(e.point, {{ layers: ['clusters'] }});
        const clusterId = features[0].properties.cluster_id;
        map.getSource('buildings').getClusterExpansionZoom(clusterId, (err, zoom) => {{
            if (!err) {{
                map.easeTo({{
                    center: features[0].geometry.coordinates,
                    zoom: zoom
                }});
            }}
        }});
    }});

    // Cursor pointer on clusters
    map.on('mouseenter', 'clusters', () => {{
        map.getCanvas().style.cursor = 'pointer';
    }});
    map.on('mouseleave', 'clusters', () => {{
        map.getCanvas().style.cursor = '';
    }});
}}

// Highlight table row when hovering pin
function highlightTableRow(buildingId) {{
    clearTableHighlight();
    const row = document.querySelector(`tr[data-id="${{buildingId}}"]`);
    if (row) {{
        row.classList.add('pin-highlight');
        row.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
    }}
}}

// Clear table row highlight
function clearTableHighlight() {{
    document.querySelectorAll('tr.pin-highlight').forEach(r => {{
        r.classList.remove('pin-highlight');
    }});
}}

// Open map panel (lazy init)
function openMapPanel() {{
    document.getElementById('map-panel').classList.add('open');
    updateMapTitle();
    // Initialize map on first open (lazy load for performance)
    setTimeout(() => {{
        initFullMap();
        if (fullMap) {{
            fullMap.resize();
            // Update map data based on current context (expanded portfolio + filters)
            if (fullMap.isStyleLoaded()) {{
                updateMapData();
            }} else {{
                fullMap.once('load', updateMapData);
            }}
        }}
    }}, 350); // Wait for CSS transition
}}

function closeMapPanel() {{
    document.getElementById('map-panel').classList.remove('open');
}}

function resetMap() {{
    if (!fullMap) return;

    // Clear address search input
    const addressInput = document.getElementById('addressAutocomplete');
    if (addressInput) addressInput.value = '';

    // Remove address marker and search markers
    if (addressMarker) {{ addressMarker.remove(); addressMarker = null; }}
    searchMarkers.forEach(m => m.remove());
    searchMarkers = [];
    selectedAddressLocation = null;

    // Remove radius circle
    if (fullMap.getLayer('radius-circle-layer')) fullMap.removeLayer('radius-circle-layer');
    if (fullMap.getSource('radius-circle')) fullMap.removeSource('radius-circle');

    // Clear spiderfied markers
    clearSpiderfy();

    // Reset map view to initial USA view
    fullMap.flyTo({{
        center: [-98.5795, 39.8283],
        zoom: 3,
        duration: 1000
    }});

    // Collapse expanded portfolios
    document.querySelectorAll('.portfolio-card.expanded').forEach(card => {{
        card.classList.remove('expanded');
    }});
    expandedPortfolioLogo = null;  // Clear portfolio logo

    // Reset filter states
    activeVertical = 'all';
    selectedBuildingType = null;
    globalQuery = '';
    selectedOwner = '';

    // Reset UI controls
    document.querySelectorAll('.vertical-btn').forEach(b => b.classList.remove('selected'));
    const allBtn = document.querySelector('.vertical-btn[data-vertical="all"]');
    if (allBtn) allBtn.classList.add('selected');
    document.querySelectorAll('.building-type-btn').forEach(b => {{
        b.classList.remove('selected');
        b.classList.remove('hidden');
    }});
    document.querySelectorAll('.opp-tile').forEach(t => t.classList.remove('selected'));
    const searchInput = document.getElementById('global-search');
    if (searchInput) searchInput.value = '';

    // Apply filters and update map
    updateFilterChips();
    applyFilters();
    updatePortfolioStats();
    updateMapTitle();
    updateMapData();
}}

// Update map title based on expanded portfolio
function updateMapTitle() {{
    const titleEl = document.getElementById('map-panel-title');
    if (!titleEl) return;

    const expandedPortfolio = document.querySelector('.portfolio-card.expanded');
    if (expandedPortfolio && expandedPortfolioLogo) {{
        const orgName = expandedPortfolio.getAttribute('data-org');
        titleEl.innerHTML = `<img src="${{expandedPortfolioLogo}}" style="height:32px;max-width:100px;object-fit:contain;" onerror="this.style.display='none'"><span>${{orgName}} Buildings</span>`;
    }} else if (expandedPortfolio) {{
        const orgName = expandedPortfolio.getAttribute('data-org');
        titleEl.innerHTML = `<span>${{orgName}} Buildings</span>`;
    }} else {{
        titleEl.innerHTML = 'All Buildings';
    }}
}}

// =============================================================================
// SMART IMAGE LOADING
// =============================================================================

const imageLoader = {{
    loaded: new Set(),
    loading: new Set(),

    load(img) {{
        if (this.loaded.has(img) || this.loading.has(img)) return;
        if (!img.dataset.src) return;
        this.loading.add(img);
        const src = img.dataset.src;
        const preload = new Image();
        preload.onload = () => {{
            img.src = src;
            img.removeAttribute('data-src');
            this.loading.delete(img);
            this.loaded.add(img);
        }};
        preload.onerror = () => this.loading.delete(img);
        preload.src = src;
    }},

    loadCard(card) {{
        if (!card) return;
        card.querySelectorAll('img[data-src]').forEach(img => this.load(img));
    }}
}};

// Instagram-style throttled preload queue - max 6 concurrent, prioritizes visible
const preloadQueue = {{
    queue: [],
    loaded: new Set(),
    loading: new Set(),
    maxConcurrent: 6,
    stats: {{ started: 0, completed: 0, failed: 0 }},

    add(url, priority = false) {{
        if (!url || this.loaded.has(url) || this.loading.has(url)) return;
        if (this.queue.includes(url)) return;
        priority ? this.queue.unshift(url) : this.queue.push(url);
        this.process();
    }},

    process() {{
        while (this.loading.size < this.maxConcurrent && this.queue.length > 0) {{
            const url = this.queue.shift();
            if (this.loaded.has(url)) continue;
            this.loading.add(url);
            this.stats.started++;
            const img = new Image();
            const filename = url.split('/').pop();
            img.onload = () => {{
                this.loaded.add(url);
                this.loading.delete(url);
                this.stats.completed++;
                this.process();
            }};
            img.onerror = () => {{
                this.loading.delete(url);
                this.stats.failed++;
                console.warn('[PreloadQueue] ✗ Failed:', filename);
                this.process();
            }};
            img.src = url;
        }}
    }}
}};

// Track how many buildings shown per portfolio
const portfolioBuildingCounts = {{}};
const BUILDINGS_PER_BATCH = 10;

// Load building rows into a portfolio card - with Show More pagination
function loadPortfolioRows(card, loadMore = false) {{
    const idx = parseInt(card.dataset.idx);
    const container = card.querySelector('.building-rows-container');
    if (!container) {{
        DIAG.log('warn', 'loadPortfolioRows: container not found', {{ idx }});
        return;
    }}

    if (!PORTFOLIO_BUILDINGS[idx]) {{
        DIAG.log('info', 'Loading portfolio buildings', {{ idx }});
        container.innerHTML = '<div class="loading-shimmer" style="padding:20px;text-align:center;border-radius:4px;">Loading buildings...</div>';
        loadScript(`data/portfolios/p_${{idx}}.js`)
            .then(() => {{
                DIAG.log('info', 'Portfolio buildings loaded', {{ idx, count: PORTFOLIO_BUILDINGS[idx]?.length || 0 }});
                loadPortfolioRows(card, loadMore);
            }})
            .catch(err => {{
                DIAG.log('error', 'Portfolio buildings failed to load', {{ idx, error: err.message }});
                console.error('[Portfolio] Failed to load portfolio', idx, ':', err);
                container.innerHTML = `<div style="padding:20px;color:#c00;text-align:center;">
                    Failed to load buildings.
                    <a href="#" onclick="event.preventDefault();loadPortfolioRows(this.closest('.portfolio-card'))" style="color:#0066cc;text-decoration:underline;margin-left:8px;">Try again</a>
                </div>`;
            }});
        return;
    }}

    let buildings = PORTFOLIO_BUILDINGS[idx];
    if (!buildings || !buildings.length) return;

    // Filter by selected building type if active
    if (selectedBuildingType) {{
        buildings = buildings.filter(b => b.type === selectedBuildingType);
    }}
    // Filter by active vertical if not 'all'
    if (activeVertical && activeVertical !== 'all') {{
        buildings = buildings.filter(b => b.vertical === activeVertical);
    }}
    // Filter by EUI rating if active
    if (activeEuiFilter && activeEuiFilter !== 'all') {{
        buildings = buildings.filter(b => {{
            let rating = 'ok';
            if (b.eui && b.eui_benchmark && b.eui_benchmark > 0) {{
                const ratio = b.eui / b.eui_benchmark;
                if (ratio <= 1.0) rating = 'good';
                else if (ratio <= 1.2) rating = 'ok';
                else rating = 'bad';
            }}
            return rating === activeEuiFilter;
        }});
    }}
    // NOTE: globalQuery filters PORTFOLIOS not buildings - don't filter here

    if (!buildings.length) {{
        // Show helpful message instead of empty space
        const filterMsg = selectedBuildingType || (activeVertical && activeVertical !== 'all') || (activeEuiFilter && activeEuiFilter !== 'all')
            ? 'No buildings match the current filters'
            : 'No buildings in this portfolio';
        container.innerHTML = `<div style="padding:24px;text-align:center;color:#666;font-style:italic;background:#f9f9f9;border-radius:4px;margin:8px 0">${{filterMsg}}</div>`;
        return;
    }}

    // Track shown count - first click shows 10, second click shows ALL remaining
    if (!loadMore) {{
        portfolioBuildingCounts[idx] = BUILDINGS_PER_BATCH;
    }} else {{
        // Show ALL remaining buildings on "Show More" click
        portfolioBuildingCounts[idx] = buildings.length;
    }}
    const showCount = Math.min(portfolioBuildingCounts[idx], buildings.length);
    const buildingsToShow = buildings.slice(0, showCount);

    // Generate grid rows
    const bucket = CONFIG.awsBucket;
    const html = buildingsToShow.map(b => {{
        const thumb = b.image
            ? `<div class="img-container building-thumb-container"><div class="img-skeleton thumb"></div><img src="${{bucket}}/thumbnails/${{b.image}}" class="building-thumb" alt="" style="opacity:0;transition:opacity 0.15s" onload="this.classList.add('img-loaded');this.previousElementSibling.classList.add('img-hidden')" onerror="console.warn('[Thumb] ✗',this.src.split('/').pop());this.classList.add('img-hidden');this.previousElementSibling.classList.add('img-hidden');this.nextElementSibling.classList.remove('img-hidden')"><div class="building-thumb-placeholder img-hidden">🏢</div></div>`
            : `<div class="building-thumb-placeholder">🏢</div>`;
        // Strip zip code and city/state from address (show only street address)
        let addrClean = (b.address || '').replace(/,?\\s*\\d{{5}}(-\\d{{4}})?$/, '').trim();
        // Also strip ", City, ST" or ", City ST" pattern from end
        if (b.city && b.state) {{
            const cityStatePattern = new RegExp(',?\\\\s*' + b.city.replace(/[.*+?^${{}}()|[\\\\]\\\\\\\\]/g, '\\\\\\\\$&') + ',?\\\\s*' + b.state + '\\\\s*$', 'i');
            addrClean = addrClean.replace(cityStatePattern, '').trim();
        }}
        const cityState = b.city && b.state ? `${{b.city}}, ${{b.state}}` : '';
        // Safe formatting with null/NaN handling - display '--' for missing data
        const sqftVal = safeParseFloat(b.sqft, 0);
        const sqft = sqftVal >= 1000000 ? `${{(sqftVal/1000000).toFixed(1)}}M` : sqftVal >= 10000 ? `${{Math.round(sqftVal/1000)}}K` : sqftVal > 0 ? Math.round(sqftVal).toLocaleString() : '--';
        const eui = (b.eui && b.eui > 0) ? formatEuiRating(b.eui, b.eui_benchmark) : '--';
        let euiRating = 'ok';
        if (b.eui && b.eui_benchmark && b.eui_benchmark > 0) {{
            const ratio = b.eui / b.eui_benchmark;
            if (ratio <= 1.0) euiRating = 'good';
            else if (ratio <= 1.2) euiRating = 'ok';
            else euiRating = 'bad';
        }}
        const opexVal = safeParseFloat(b.opex, 0);
        const opex = opexVal > 0 ? (opexVal >= 1000000000 ? `$${{(opexVal/1000000000).toFixed(1)}}B` : opexVal >= 1000000 ? `$${{(opexVal/1000000).toFixed(1)}}M` : opexVal >= 1000 ? `$${{Math.round(opexVal/1000)}}K` : `$${{Math.round(opexVal)}}`) : '--';
        const valNum = safeParseFloat(b.valuation, 0);
        const val = valNum > 0 ? (valNum >= 1000000000 ? `$${{(valNum/1000000000).toFixed(1)}}B` : valNum >= 1000000 ? `$${{(valNum/1000000).toFixed(1)}}M` : valNum >= 1000 ? `$${{Math.round(valNum/1000)}}K` : `$${{Math.round(valNum)}}`) : '--';
        const carbonVal = safeParseFloat(b.carbon, 0);
        const carbon = carbonVal > 0 ? (carbonVal >= 1000000 ? `${{(carbonVal/1000000).toFixed(1)}}M` : carbonVal >= 1000 ? `${{Math.round(carbonVal/1000)}}K` : Math.round(carbonVal)) : '0';

        const extLink = b.url ? `<a href="${{b.url}}" target="_blank" onclick="event.stopPropagation()" style="color:var(--primary);font-weight:bold;font-size:11px;background:rgba(0,102,204,0.15);padding:1px 4px;border-radius:3px;text-decoration:none">↗</a>` : '';
        const addrLine1 = b.property_name ? `${{addrClean}}, ${{cityState}}` : addrClean;
        const addrLine2 = b.property_name ? b.property_name : cityState;
        const hqBadge = b.hq_org ? `<span class="hq-badge">${{escapeHtml(b.hq_org)}} HQ</span>` : '';
        return `<div class="building-grid-row" data-radio-type="${{b.type}}" data-vertical="${{b.vertical}}" data-sqft="${{b.sqft}}" data-eui="${{b.eui || 0}}" data-eui-rating="${{euiRating}}" data-opex="${{b.opex}}" data-valuation="${{b.valuation}}" data-carbon="${{b.carbon}}" data-address="${{escapeHtml(b.address || '')}}" onclick="window.location='buildings/${{b.id}}.html'">
            <div>${{thumb}}</div>
            <span class="ext-link-cell">${{extLink}}</span>
            <span class="stat-cell"><span class="addr-main">${{addrLine1}}</span><span class="addr-sub">${{addrLine2}}</span></span>
            <span class="stat-cell">${{b.type || '-'}}${{hqBadge}}</span>
            <span class="stat-cell">${{sqft}}</span>
            <span class="stat-cell">${{eui}}</span>
            <span class="stat-cell carbon-value">${{carbon}}</span>
            <span class="stat-cell valuation-value">${{val}}</span>
            <span class="stat-cell opex-value">${{opex}}</span>
        </div>`;
    }}).join('');

    const remaining = buildings.length - showCount;

    // Sort header for building rows (only shown inside expanded portfolio)
    const orgName = card.dataset.displayname || card.dataset.org || '';
    // Build EUI filter with current state preserved
    const euiFilteringClass = (activeEuiFilter && activeEuiFilter !== 'all') ? ' filtering' : '';
    const euiBadChecked = activeEuiFilter === 'bad' ? ' checked' : '';
    const euiOkChecked = activeEuiFilter === 'ok' ? ' checked' : '';
    const euiGoodChecked = activeEuiFilter === 'good' ? ' checked' : '';
    const sortHeader = `<div class="building-sort-header">
        <span class="l2-org-name">${{orgName}}</span>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'address')">Building</span>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'type')">Type</span>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'sqft')">Sq Ft</span>
        <div class="sort-col eui-filter-wrapper${{euiFilteringClass}}" id="euiFilterWrapper">
            <span onclick="event.stopPropagation(); sortBuildingRows(this, 'eui')" style="cursor:pointer">EUI</span>
            <span class="eui-active-indicator" onclick="event.stopPropagation(); clearEuiFilter()">×</span>
            <svg class="eui-filter-icon" onclick="event.stopPropagation(); toggleEuiFilter(event)" style="cursor:pointer" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z"/></svg>
            <div class="eui-filter-dropdown" id="euiFilterDropdown" onclick="event.stopPropagation()">
                <label class="eui-filter-option"><input type="radio" name="eui-filter" data-eui="bad" onchange="applyEuiFilter()"${{euiBadChecked}}> Bad</label>
                <label class="eui-filter-option"><input type="radio" name="eui-filter" data-eui="ok" onchange="applyEuiFilter()"${{euiOkChecked}}> OK</label>
                <label class="eui-filter-option"><input type="radio" name="eui-filter" data-eui="good" onchange="applyEuiFilter()"${{euiGoodChecked}}> Good</label>
            </div>
        </div>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'carbon')">tCO2e/yr</span>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'valuation')">Val. Impact</span>
        <span class="sort-col" onclick="event.stopPropagation(); sortBuildingRows(this, 'opex')">Savings/yr</span>
    </div>`;

    // Simple control bar: ▲ (collapse) and ▼ (show more)
    const showLess = `<span class="row-arrow" onclick="event.stopPropagation(); showLessBuildings(this.closest('.portfolio-card'))">▲</span>`;
    const showMore = remaining > 0
        ? `<span class="row-arrow" onclick="event.stopPropagation(); loadPortfolioRows(this.closest('.portfolio-card'), true)">▼</span>`
        : `<span class="row-arrow disabled">▼</span>`;
    const controlBar = `<div class="row-controls">${{showLess}}${{showMore}}</div>`;

    container.innerHTML = sortHeader + html + controlBar;
    loadedPortfolios.add(idx);

    // Re-apply sort if user had sorted this portfolio (preserves sort on filter change)
    const sortKey = Object.keys(buildingSortDir).find(k => k.startsWith(idx + '_'));
    if (sortKey) {{
        const col = sortKey.split('_')[1];
        const asc = buildingSortDir[sortKey];

        // Sort rows directly without calling sortBuildingRows (which toggles direction)
        const rows = Array.from(container.querySelectorAll('.building-grid-row'));
        if (rows.length > 0) {{
            rows.sort((a, b) => {{
                let aVal, bVal;
                if (col === 'address') {{
                    aVal = (a.dataset.address || '').toLowerCase();
                    bVal = (b.dataset.address || '').toLowerCase();
                }} else if (col === 'type') {{
                    aVal = (a.dataset.radioType || '').toLowerCase();
                    bVal = (b.dataset.radioType || '').toLowerCase();
                }} else if (col === 'eui') {{
                    // Explicit null handling - push missing EUI to bottom regardless of sort direction
                    const aRaw = parseFloat(a.dataset.eui);
                    const bRaw = parseFloat(b.dataset.eui);
                    const aHasEui = !isNaN(aRaw) && aRaw > 0;
                    const bHasEui = !isNaN(bRaw) && bRaw > 0;
                    if (!aHasEui && !bHasEui) return 0;
                    if (!aHasEui) return 1;  // a goes to bottom
                    if (!bHasEui) return -1; // b goes to bottom
                    aVal = aRaw;
                    bVal = bRaw;
                }} else {{
                    aVal = parseFloat(a.dataset[col]) || 0;
                    bVal = parseFloat(b.dataset[col]) || 0;
                }}

                if (typeof aVal === 'string') {{
                    return asc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
                }}
                return asc ? aVal - bVal : bVal - aVal;
            }});

            // Re-append sorted rows
            const controls = container.querySelector('.row-controls');
            rows.forEach(row => container.insertBefore(row, controls));

            // Update header visual indicator - handle both direct onclick and nested span (for EUI)
            let headerEl = container.querySelector(`.sort-col[onclick*="${{col}}"]`);
            if (!headerEl) headerEl = container.querySelector(`.sort-col [onclick*="${{col}}"]`);
            if (headerEl) {{
                container.querySelectorAll('.building-sort-header .sort-col, .building-sort-header .sort-col span').forEach(el => {{
                    el.classList.remove('sorted-asc', 'sorted-desc');
                }});
                headerEl.classList.add(asc ? 'sorted-asc' : 'sorted-desc');
            }}
        }}
    }}
}}

// Show less - ALWAYS collapse the portfolio (hide all building rows)
function showLessBuildings(card) {{
    clearEuiFilter();  // Clear EUI filter when collapsing
    card.classList.remove('expanded');
    expandedPortfolioLogo = null;
    if (document.getElementById('map-panel').classList.contains('open')) {{
        updateMapData();
        updateMapTitle();
    }}
}}

// =============================================================================
// INITIALIZATION - NOTHING auto-loads, user action triggers everything
// =============================================================================

// Preload a portfolio's images using throttled queue
const preloadedIdx = new Set();
function preloadPortfolio(idx) {{
    if (preloadedIdx.has(idx)) return;
    preloadedIdx.add(idx);
    const buildings = PORTFOLIO_BUILDINGS[idx];
    if (!buildings) return;
    // Use throttled queue - only first 15 images to avoid flooding
    buildings.slice(0, 15).forEach(b => {{
        if (b.image) preloadQueue.add(CONFIG.awsBucket + '/thumbnails/' + b.image);
    }});
}}

// =============================================================================
// INFINITE SCROLL - Load more portfolio cards as user scrolls
// =============================================================================

let loadedCardCount = 100;  // First 100 loaded in HTML
const CARDS_PER_BATCH = 50;
let isLoadingMore = false;

function renderPortfolioCard(p, overrides = {{}}) {{
    // Use overrides if provided (for filtered views), otherwise use p values
    const count = overrides.count !== undefined ? overrides.count : p.building_count;
    const sqft = overrides.sqft !== undefined ? overrides.sqft : p.total_sqft;
    const opex = overrides.opex !== undefined ? overrides.opex : p.total_opex;
    const valuation = overrides.valuation !== undefined ? overrides.valuation : p.total_valuation;
    const carbon = overrides.carbon !== undefined ? overrides.carbon : p.total_carbon;

    const bucket = CONFIG.awsBucket;
    const logoUrl = p.aws_logo_url || (p.logo_file ? `${{bucket}}/logos/${{p.logo_file}}` : '');
    const logoThumbUrl = logoUrl ? logoUrl.replace('/logos/', '/logo-thumbnails/') : '';
    const orgInitial = (p.org_name && p.org_name.length > 0) ? p.org_name[0].toUpperCase() : '?';
    const logoInner = logoUrl
        ? `<div class="img-container" style="width:48px;height:48px"><div class="img-skeleton logo"></div><img src="${{logoThumbUrl}}" data-fullsize="${{logoUrl}}" alt="" class="org-logo" style="opacity:0;transition:opacity 0.15s" onload="this.classList.add('img-loaded');this.previousElementSibling.classList.add('img-hidden')" onerror="if(this.dataset.fullsize&&this.src!==this.dataset.fullsize){{this.src=this.dataset.fullsize}}else{{console.warn('[Logo] ✗',this.src.split('/').pop());this.classList.add('img-hidden');this.previousElementSibling.classList.add('img-hidden');this.nextElementSibling.classList.remove('img-hidden')}}"><div class="org-logo-placeholder img-hidden">${{orgInitial}}</div></div>`
        : `<div class="org-logo-placeholder">${{orgInitial}}</div>`;
    const logoHtml = p.org_url
        ? `<a href="${{p.org_url}}" target="_blank" onclick="event.stopPropagation()" class="org-logo-link">${{logoInner}}</a>`
        : logoInner;
    const parentHtml = p.parent_owned ? `<span class="parent-owned">${{p.parent_owned}}</span>` : '';
    const fullTitle = p.parent_owned ? `${{p.display_name || p.org_name}} (${{p.parent_owned}})` : (p.display_name || p.org_name);

    return `<div class="portfolio-card" data-idx="${{p.idx}}" data-org="${{p.org_name}}" data-displayname="${{p.display_name || p.org_name}}" data-buildings="${{count}}" data-sqft="${{sqft || 0}}" data-eui="${{p.median_eui}}" data-valuation="${{valuation}}" data-carbon="${{carbon}}" data-opex="${{opex}}" data-classification="${{p.classification || ''}}">
        <div class="portfolio-header" onclick="togglePortfolio(this)">
            <div class="org-logo-stack" data-col="portfolio">
                <span class="org-name-small" title="${{fullTitle}}">${{p.display_name || p.org_name}}${{parentHtml}}</span>
                ${{logoHtml}}
            </div>
            <span class="stat-cell building-count" data-col="buildings"><span class="building-count-value">${{count.toLocaleString()}}</span></span>
            <span class="stat-cell classification-cell" data-col="type">${{(p.classification || '-').replace(/\\//g, '<br>').replace(/ /g, '<br>')}}</span>
            <span class="stat-cell sqft-value" data-col="sqft">${{formatSqftJS(sqft)}}</span>
            <span class="stat-cell eui-value" data-col="eui" title="Median EUI of all buildings in this portfolio">${{formatEuiRating(p.median_eui, p.median_eui_benchmark)}}</span>
            <span class="stat-cell carbon-value" data-col="carbon">${{formatCarbon(carbon)}}</span>
            <span class="stat-cell valuation-value" data-col="valuation">${{formatMoney(valuation)}}</span>
            <span class="stat-cell opex-value" data-col="savings">${{formatMoney(opex)}}</span>
        </div>
        <div class="portfolio-buildings">
            <div class="building-rows-container"></div>
        </div>
    </div>`;
}}

function loadMorePortfolios() {{
    if (isLoadingMore || loadedCardCount >= PORTFOLIO_CARDS.length) return;
    isLoadingMore = true;

    const list = document.getElementById('portfolios-list');
    const endIdx = Math.min(loadedCardCount + CARDS_PER_BATCH, PORTFOLIO_CARDS.length);

    // Get existing card indices to avoid duplicates
    const existingIndices = new Set();
    list.querySelectorAll('.portfolio-card').forEach(c => existingIndices.add(parseInt(c.dataset.idx)));

    for (let i = loadedCardCount; i < endIdx; i++) {{
        if (!existingIndices.has(i)) {{
            const card = PORTFOLIO_CARDS[i];
            list.insertAdjacentHTML('beforeend', renderPortfolioCard(card));
        }}
    }}

    // Add hover listeners to new cards
    list.querySelectorAll('.portfolio-card').forEach(card => {{
        if (!card.dataset.hoverBound) {{
            card.dataset.hoverBound = 'true';
            card.addEventListener('mouseenter', function() {{
                const idx = parseInt(this.dataset.idx);
                if (!isNaN(idx)) preloadPortfolio(idx);
            }});
        }}
    }});

    loadedCardCount = endIdx;
    isLoadingMore = false;
    applyFilters();
}}

// =============================================================================
// OFFLINE DETECTION
// =============================================================================

window.addEventListener('offline', () => {{document.body.classList.add('is-offline');
}});

window.addEventListener('online', () => {{document.body.classList.remove('is-offline');
}});

// =============================================================================
// PAGE INITIALIZATION
// =============================================================================

document.addEventListener('DOMContentLoaded', function() {{
    DIAG.log('info', 'DOMContentLoaded fired');
    DIAG.log('info', 'Initial state', {{
        PORTFOLIO_CARDS: PORTFOLIO_CARDS?.length || 0,
        FILTER_DATA: FILTER_DATA?.length || 0,
        firebase: typeof firebase !== 'undefined',
        google: typeof google !== 'undefined',
        mapboxgl: typeof mapboxgl !== 'undefined'
    }});

    // Responsive breakpoint debugging - shows header vs data column comparison
    function logResponsiveBreakpoint() {{
        const w = window.innerWidth;
        let breakpoint = 'desktop-full';
        if (w <= 767) breakpoint = 'mobile';
        else if (w <= 1100) breakpoint = 'small-desktop';

        console.log('\\n[GRID DEBUG] ========== ' + w + 'px (' + breakpoint + ') ==========');

        const header = document.querySelector('#portfolios-tab .portfolio-sort-header');
        const row = document.querySelector('#portfolios-tab .portfolio-header');

        if (!header || !row) {{
            console.log('[GRID DEBUG] Header or row not found!');
            return;
        }}

        const cols = ['portfolio', 'buildings', 'type', 'sqft', 'eui', 'carbon', 'valuation', 'savings'];

        console.log('[GRID DEBUG] HEADERS visible:');
        cols.forEach(col => {{
            const el = header.querySelector('[data-col="' + col + '"]');
            if (el) {{
                const cs = getComputedStyle(el);
                const vis = cs.display !== 'none' && cs.visibility !== 'hidden';
                console.log('  ' + col + ': ' + (vis ? 'VISIBLE' : 'hidden') + ' (display=' + cs.display + ', visibility=' + cs.visibility + ')');
            }} else {{
                console.log('  ' + col + ': NO ELEMENT');
            }}
        }});

        console.log('[GRID DEBUG] DATA ROW visible:');
        cols.forEach(col => {{
            const el = row.querySelector('[data-col="' + col + '"]');
            if (el) {{
                const cs = getComputedStyle(el);
                const vis = cs.display !== 'none' && cs.visibility !== 'hidden';
                const text = el.textContent.trim().substring(0, 20);
                console.log('  ' + col + ': ' + (vis ? 'VISIBLE' : 'hidden') + ' (display=' + cs.display + ') content="' + text + '"');
            }} else {{
                console.log('  ' + col + ': NO ELEMENT');
            }}
        }});

        // Check grid template
        const headerCS = getComputedStyle(header);
        const rowCS = getComputedStyle(row);
        console.log('[GRID DEBUG] Header gridTemplateColumns: ' + headerCS.gridTemplateColumns);
        console.log('[GRID DEBUG] Row gridTemplateColumns: ' + rowCS.gridTemplateColumns);
    }}
    logResponsiveBreakpoint();
    window.addEventListener('resize', (function() {{
        let timeout;
        return function() {{
            clearTimeout(timeout);
            timeout = setTimeout(logResponsiveBreakpoint, 200);
        }};
    }})());

    // Load export_data.js for All Buildings tab and CSV export (not needed for header tooltips)
    // Header tooltips now use pre-computed HEADER_TOTALS for instant updates
    dataLoadState.exportData = 'loading';
    loadScript('data/export_data.js', {{ timeout: 30000 }})
        .then(() => {{
            allBuildingsData = EXPORT_DATA;
            dataLoadState.exportData = 'loaded';
            DIAG.log('info', 'EXPORT_DATA loaded via DOMContentLoaded', {{ count: EXPORT_DATA?.length || 0 }});
        }})
        .catch(err => {{
            DIAG.log('error', 'EXPORT_DATA failed in DOMContentLoaded', err);
            console.error('[DOMContentLoaded] Failed to load EXPORT_DATA:', err);
            dataLoadState.exportData = 'error';
        }});

    initTabs();
    selectVertical('all');

    // FIX: Handle cached images that loaded before handlers were attached
    // When images are cached, they may load synchronously before inline onload fires
    document.querySelectorAll('img.org-logo, img.building-thumb').forEach(img => {{
        if (img.complete && img.naturalWidth > 0) {{
            // Image already loaded successfully - trigger load handler manually
            img.classList.add('img-loaded');
            if (img.previousElementSibling) img.previousElementSibling.classList.add('img-hidden');
        }} else if (img.complete && img.naturalWidth === 0) {{
            // Image failed to load (404 or error) - trigger error handler manually
            img.classList.add('img-hidden');
            if (img.previousElementSibling) img.previousElementSibling.classList.add('img-hidden');
            if (img.nextElementSibling) img.nextElementSibling.classList.remove('img-hidden');
        }}
    }});

    // Smart throttled preload - only first 50 visible logos (above fold)
    // Uses preloadQueue to avoid flooding network on cold cache - preload thumbnails for speed
    PORTFOLIO_CARDS.slice(0, 50).forEach(p => {{
        const logoUrl = p.aws_logo_url || (p.logo_file ? CONFIG.awsBucket + '/logos/' + p.logo_file : '');
        const logoThumbUrl = logoUrl ? logoUrl.replace('/logos/', '/logo-thumbnails/') : '';
        if (logoThumbUrl) preloadQueue.add(logoThumbUrl, true);  // priority=true for visible
    }});

    // DON'T pre-expand first 5 portfolios on cold cache - let user trigger expansion
    // This prevents unnecessary network requests when cache is cleared

    // On HOVER: preload that portfolio's building thumbnails using throttled queue
    document.querySelectorAll('.portfolio-card').forEach(card => {{
        card.addEventListener('mouseenter', function() {{
            const idx = parseInt(this.dataset.idx);
            if (isNaN(idx)) return;
            // Preload logo thumbnail for this card if not already loaded
            const p = PORTFOLIO_CARDS[idx];
            if (p) {{
                const logoUrl = p.aws_logo_url || (p.logo_file ? CONFIG.awsBucket + '/logos/' + p.logo_file : '');
                const logoThumbUrl = logoUrl ? logoUrl.replace('/logos/', '/logo-thumbnails/') : '';
                if (logoThumbUrl) preloadQueue.add(logoThumbUrl);
            }}
            // Preload first 10 building thumbnails when hovering
            const buildings = PORTFOLIO_BUILDINGS[idx];
            if (buildings) {{
                buildings.slice(0, 10).forEach(b => {{
                    if (b.image) preloadQueue.add(CONFIG.awsBucket + '/thumbnails/' + b.image);
                }});
            }}
        }});
    }});

    // Infinite scroll - load more as user scrolls
    const trigger = document.getElementById('load-more-trigger');
    if (trigger) {{
        const observer = new IntersectionObserver((entries) => {{
            if (entries[0].isIntersecting) loadMorePortfolios();
        }}, {{ rootMargin: '500px' }});
        observer.observe(trigger);
    }}
}});

// =============================================================================
// TUTORIAL SYSTEM - WalkMe-style Interactive Guide
// =============================================================================

const TUTORIAL_STEPS = [
    {{
        target: '#global-search',
        title: 'Search Bar',
        content: 'Search for any owner, tenant, or brand name. Results filter instantly as you type. Try searching for "CBRE" or "Marriott".',
        position: 'bottom'
    }},
    {{
        target: '.main-tab[data-tab="portfolios"]',
        multiTarget: ['.main-tab[data-tab="portfolios"]', '.main-tab[data-tab="all-buildings"]'],
        title: 'Cities & Portfolios Tabs',
        content: 'Switch between views: Portfolios tab shows buildings grouped by organization (owner, tenant, property manager). Cities tab shows buildings grouped by metro area.',
        position: 'bottom',
        action: function() {{ switchMainTab('portfolios'); }}
    }},
    {{
        target: '.vertical-buttons-group',
        title: 'Vertical Filters',
        content: 'Filter portfolios by sector: Commercial (navy), Education (blue), or Healthcare (light blue). Click the DOWN ARROW on each button to filter by specific building types within that vertical.',
        position: 'bottom',
        action: function() {{ switchMainTab('portfolios'); }}
    }},
    {{
        target: 'button[onclick*="openMapPanel"]',
        title: 'Map View',
        content: 'Search for a specific address to check if that building is in our dataset. See all buildings plotted geographically by climate zone.',
        position: 'bottom'
    }},
    {{
        target: '#typeFilterWrapper',
        title: 'Type Filter',
        content: 'Filter portfolios by relationship type: Owner, Tenant, Property Manager, etc. Click the dropdown arrow to see options.',
        position: 'bottom',
        highlight: true,
        action: function() {{
            switchMainTab('portfolios');
            setTimeout(function() {{
                var typeWrapper = document.getElementById('typeFilterWrapper');
                if (typeWrapper) typeWrapper.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
            }}, 300);
        }}
    }},
    {{
        target: '.portfolio-card:first-child .portfolio-header',
        title: 'Expand Portfolio',
        content: 'Click any portfolio row to expand it and see individual buildings. Each building shows address, type, square footage, EUI rating, and savings potential.',
        position: 'bottom',
        action: function() {{
            var firstCard = document.querySelector('.portfolio-card:not(.hidden)');
            if (firstCard && !firstCard.classList.contains('expanded')) {{
                togglePortfolio(firstCard.querySelector('.portfolio-header'));
            }}
        }}
    }},
    {{
        target: '#euiFilterWrapper',
        title: 'EUI Filter',
        content: 'Filter buildings by energy efficiency rating: Good (green), OK (orange), or Bad (red). This filter only applies to buildings in the currently expanded portfolio.',
        position: 'bottom',
        highlight: true,
        action: function() {{
            // Ensure a portfolio is expanded first
            var firstCard = document.querySelector('.portfolio-card:not(.hidden)');
            if (firstCard && !firstCard.classList.contains('expanded')) {{
                togglePortfolio(firstCard.querySelector('.portfolio-header'));
            }}
            setTimeout(function() {{
                var euiWrapper = document.getElementById('euiFilterWrapper');
                if (euiWrapper) euiWrapper.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
            }}, 400);
        }}
    }},
    {{
        target: '.building-grid-row .ext-link-cell a[href]',
        title: 'Source Link',
        content: 'Click the arrow icon (↗) next to the building thumbnail to view the original data source for this building in a new tab.',
        position: 'right',
        waitForTarget: true,
        waitForTargetTimeoutMs: 2000,
        action: function() {{
            // Ensure a portfolio is expanded
            var firstCard = document.querySelector('.portfolio-card:not(.hidden)');
            if (firstCard && !firstCard.classList.contains('expanded')) {{
                togglePortfolio(firstCard.querySelector('.portfolio-header'));
            }}
        }}
    }},
    {{
        target: '.portfolio-card.expanded .row-controls',
        title: 'Show More / Collapse',
        content: 'Only the first 10 buildings are shown initially. Click ▼ to load all remaining buildings in the portfolio. Click ▲ to collapse the portfolio view.',
        position: 'top',
        waitForTarget: true,
        waitForTargetTimeoutMs: 3000,
        action: function() {{
            var expanded = document.querySelector('.portfolio-card.expanded');
            if (!expanded) {{
                var firstCard = document.querySelector('.portfolio-card:not(.hidden)');
                if (firstCard) togglePortfolio(firstCard.querySelector('.portfolio-header'));
            }}
        }}
    }}
];

// Helper: wait for element to exist (only for steps with waitForTarget)
function waitForTutorialTarget(step, maxWaitMs, cb) {{
    var start = Date.now();
    (function tick() {{
        // Look for element inside expanded card first
        var expanded = document.querySelector('.portfolio-card.expanded');
        if (expanded) {{
            // Try to find target inside expanded card
            var selector = step.target.replace('.portfolio-card.expanded ', '');
            var el = expanded.querySelector(selector) || expanded.querySelector('.row-controls');
            if (el && el.getBoundingClientRect().width > 0) {{
                return cb(el);
            }}
        }}
        // Fallback: try global querySelector
        var globalEl = document.querySelector(step.target);
        if (globalEl && globalEl.getBoundingClientRect().width > 0) {{
            return cb(globalEl);
        }}
        if (Date.now() - start >= maxWaitMs) return cb(null);
        requestAnimationFrame(tick);
    }})();
}}

let currentTutorialStep = 0;
let tutorialActive = false;

function startTutorial() {{
    tutorialActive = true;
    currentTutorialStep = 0;

    var overlay = document.getElementById('tutorial-overlay');
    overlay.style.display = 'block';
    setTimeout(function() {{ overlay.classList.add('active'); }}, 10);

    document.getElementById('tutorial-total-steps').textContent = TUTORIAL_STEPS.length;

    // Hide tutorial button during tutorial
    var btn = document.getElementById('tutorial-btn');
    if (btn) btn.style.display = 'none';

    showTutorialStep(0);
}}

function endTutorial() {{
    tutorialActive = false;
    var overlay = document.getElementById('tutorial-overlay');
    overlay.classList.remove('active');
    setTimeout(function() {{
        overlay.style.display = 'none';
    }}, 300);

    // Show tutorial button again
    var btn = document.getElementById('tutorial-btn');
    if (btn) btn.style.display = 'flex';

    // Remember that user has seen tutorial
    localStorage.setItem('tutorialCompleted', 'true');
}}

function nextTutorialStep() {{
    if (currentTutorialStep < TUTORIAL_STEPS.length - 1) {{
        currentTutorialStep++;
        showTutorialStep(currentTutorialStep);
    }} else {{
        endTutorial();
    }}
}}

function prevTutorialStep() {{
    if (currentTutorialStep > 0) {{
        currentTutorialStep--;
        showTutorialStep(currentTutorialStep);
    }}
}}

function showTutorialStep(stepIndex) {{
    var step = TUTORIAL_STEPS[stepIndex];
    var tooltip = document.getElementById('tutorial-tooltip');

    // Hide tooltip while repositioning
    tooltip.classList.remove('visible');

    // Execute any action for this step FIRST (like switching tabs, expanding cards)
    if (step.action) {{
        step.action();
    }}

    // Render function - called once we have the target element
    var doRender = function(targetEl) {{
        if (!targetEl) {{
            if (stepIndex < TUTORIAL_STEPS.length - 1) {{
                currentTutorialStep++;
                showTutorialStep(currentTutorialStep);
            }} else {{
                endTutorial();
            }}
            return;
        }}

        // Scroll target into view first
        targetEl.scrollIntoView({{ behavior: 'smooth', block: 'center' }});

        // Wait for smooth scroll to complete (400ms), then measure
        setTimeout(function() {{
            var spotlight = document.getElementById('tutorial-spotlight');
            var spotlight2 = document.getElementById('tutorial-spotlight-2');
            var padding = 8;
            var rect;

            var backdrop = document.querySelector('.tutorial-backdrop');

            // Handle multi-target spotlight (separate boxes for each target)
            if (step.multiTarget && step.multiTarget.length > 1) {{
                var el1 = document.querySelector(step.multiTarget[0]);
                var el2 = document.querySelector(step.multiTarget[1]);
                if (el1 && el2) {{
                    var rect1 = el1.getBoundingClientRect();
                    var rect2 = el2.getBoundingClientRect();
                    // Position first spotlight
                    spotlight.style.top = (rect1.top - padding) + 'px';
                    spotlight.style.left = (rect1.left - padding) + 'px';
                    spotlight.style.width = (rect1.width + padding * 2) + 'px';
                    spotlight.style.height = (rect1.height + padding * 2) + 'px';
                    spotlight.classList.remove('single-target');
                    // Position second spotlight
                    spotlight2.style.top = (rect2.top - padding) + 'px';
                    spotlight2.style.left = (rect2.left - padding) + 'px';
                    spotlight2.style.width = (rect2.width + padding * 2) + 'px';
                    spotlight2.style.height = (rect2.height + padding * 2) + 'px';
                    spotlight2.style.display = 'block';
                    // Create clip-path with two cutouts for backdrop
                    var vw = window.innerWidth, vh = window.innerHeight;
                    var r1 = {{ x: rect1.left - padding, y: rect1.top - padding, w: rect1.width + padding * 2, h: rect1.height + padding * 2 }};
                    var r2 = {{ x: rect2.left - padding, y: rect2.top - padding, w: rect2.width + padding * 2, h: rect2.height + padding * 2 }};
                    var clipPath = 'polygon(0% 0%, 0% 100%, ' + (r1.x/vw*100) + '% 100%, ' + (r1.x/vw*100) + '% ' + (r1.y/vh*100) + '%, ' + ((r1.x+r1.w)/vw*100) + '% ' + (r1.y/vh*100) + '%, ' + ((r1.x+r1.w)/vw*100) + '% ' + ((r1.y+r1.h)/vh*100) + '%, ' + (r1.x/vw*100) + '% ' + ((r1.y+r1.h)/vh*100) + '%, ' + (r1.x/vw*100) + '% 100%, ' + (r2.x/vw*100) + '% 100%, ' + (r2.x/vw*100) + '% ' + (r2.y/vh*100) + '%, ' + ((r2.x+r2.w)/vw*100) + '% ' + (r2.y/vh*100) + '%, ' + ((r2.x+r2.w)/vw*100) + '% ' + ((r2.y+r2.h)/vh*100) + '%, ' + (r2.x/vw*100) + '% ' + ((r2.y+r2.h)/vh*100) + '%, ' + (r2.x/vw*100) + '% 100%, 100% 100%, 100% 0%)';
                    backdrop.style.clipPath = clipPath;
                    backdrop.classList.add('active');
                    // Use combined rect for tooltip positioning
                    rect = {{ left: rect1.left, top: rect1.top, right: rect2.right, bottom: rect1.bottom, width: rect2.right - rect1.left, height: rect1.height }};
                }} else {{
                    rect = targetEl.getBoundingClientRect();
                    spotlight.style.top = (rect.top - padding) + 'px';
                    spotlight.style.left = (rect.left - padding) + 'px';
                    spotlight.style.width = (rect.width + padding * 2) + 'px';
                    spotlight.style.height = (rect.height + padding * 2) + 'px';
                    spotlight.classList.add('single-target');
                    spotlight2.style.display = 'none';
                    backdrop.classList.remove('active');
                    backdrop.style.clipPath = '';
                }}
            }} else {{
                rect = targetEl.getBoundingClientRect();
                spotlight.style.top = (rect.top - padding) + 'px';
                spotlight.style.left = (rect.left - padding) + 'px';
                spotlight.style.width = (rect.width + padding * 2) + 'px';
                spotlight.style.height = (rect.height + padding * 2) + 'px';
                spotlight.classList.add('single-target');
                spotlight2.style.display = 'none';
                backdrop.classList.remove('active');
                backdrop.style.clipPath = '';
            }}

            // Add special highlight class for filter steps
            if (step.highlight) {{
                spotlight.classList.add('extra-highlight');
                spotlight2.classList.add('extra-highlight');
            }} else {{
                spotlight.classList.remove('extra-highlight');
                spotlight2.classList.remove('extra-highlight');
            }}

            // Position tooltip
            positionTooltip(tooltip, rect, step.position);

            // Update content
            document.getElementById('tutorial-step-num').textContent = stepIndex + 1;
            document.getElementById('tutorial-title').textContent = step.title;
            document.getElementById('tutorial-content').textContent = step.content;

            // Update buttons
            document.getElementById('tutorial-next').textContent =
                stepIndex === TUTORIAL_STEPS.length - 1 ? 'Finish' : 'Next';

            // Show tooltip after positioning
            tooltip.classList.add('visible');
        }}, 600);
    }};

    // If step needs to wait for dynamic element (step 9), use waitForTutorialTarget
    if (step.waitForTarget) {{
        waitForTutorialTarget(step, step.waitForTargetTimeoutMs || 3000, doRender);
    }} else {{
        // Default: small delay then querySelector
        setTimeout(function() {{
            var targetEl = document.querySelector(step.target);
            doRender(targetEl);
        }}, step.action ? 250 : 50);
    }}
}}

function positionTooltip(tooltip, targetRect, position) {{
    var padding = 20;
    var tooltipWidth = 380;
    var tooltipHeight = tooltip.offsetHeight || 200;

    // Remove arrow classes but keep base class
    tooltip.classList.remove('arrow-top', 'arrow-bottom', 'arrow-left', 'arrow-right');

    var top, left;
    var targetCenterX = targetRect.left + (targetRect.width / 2);
    var targetCenterY = targetRect.top + (targetRect.height / 2);

    switch (position) {{
        case 'bottom':
            top = targetRect.bottom + padding;
            left = targetCenterX - (tooltipWidth / 2);
            tooltip.classList.add('arrow-top');
            break;
        case 'top':
            top = targetRect.top - tooltipHeight - padding;
            left = targetCenterX - (tooltipWidth / 2);
            tooltip.classList.add('arrow-bottom');
            break;
        case 'left':
            top = targetCenterY - (tooltipHeight / 2);
            left = targetRect.left - tooltipWidth - padding;
            tooltip.classList.add('arrow-right');
            break;
        case 'right':
            top = targetCenterY - (tooltipHeight / 2);
            left = targetRect.right + padding;
            tooltip.classList.add('arrow-left');
            break;
    }}

    // Keep tooltip on screen
    var originalLeft = left;
    var originalTop = top;
    left = Math.max(20, Math.min(left, window.innerWidth - tooltipWidth - 20));
    top = Math.max(20, Math.min(top, window.innerHeight - tooltipHeight - 20));

    // Calculate arrow offset to point at target center
    var arrowOffset;
    if (position === 'bottom' || position === 'top') {{
        // Horizontal arrow - calculate where target center is relative to tooltip
        arrowOffset = targetCenterX - left;
        // Clamp to stay within tooltip bounds (with padding)
        arrowOffset = Math.max(24, Math.min(arrowOffset, tooltipWidth - 24));
        tooltip.style.setProperty('--arrow-offset', arrowOffset + 'px');
    }} else {{
        // Vertical arrow - calculate where target center is relative to tooltip
        arrowOffset = targetCenterY - top;
        arrowOffset = Math.max(24, Math.min(arrowOffset, tooltipHeight - 24));
        tooltip.style.setProperty('--arrow-offset', arrowOffset + 'px');
    }}

    tooltip.style.top = top + 'px';
    tooltip.style.left = left + 'px';
}}

// Handle escape key to close tutorial
document.addEventListener('keydown', function(e) {{
    if (e.key === 'Escape' && tutorialActive) {{
        endTutorial();
    }}
}});

// Handle window resize - reposition spotlight and tooltip
window.addEventListener('resize', function() {{
    if (tutorialActive) {{
        showTutorialStep(currentTutorialStep);
    }}
}});

// =============================================================================
// RESPONSIVE DIAGNOSTICS - logs key measurements to console on resize
// =============================================================================
function logResponsiveDiagnostics() {{
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    const header = document.querySelector('.header');
    const filterBar = document.querySelector('.vertical-filter-bar');
    const filterInner = document.querySelector('.vertical-filter-inner');
    const portfolioSection = document.querySelector('.portfolio-section');
    const statsGrid = document.querySelector('.stats-grid');
    const tabsContainer = document.querySelector('.tabs-container');

    const portfolioHeader = document.querySelector('.portfolio-sort-header');
    const portfolioHeaderCells = portfolioHeader ? portfolioHeader.children : [];

    const citiesHeader = document.querySelector('.cities-header');
    const citiesHeaderCells = citiesHeader ? citiesHeader.children : [];

    const body = document.body;
    const hasHorizontalScroll = body.scrollWidth > vw;

    console.clear();
    console.log('%c=== RESPONSIVE DIAGNOSTICS ===', 'color: #0066cc; font-weight: bold; font-size: 14px');
    console.log('Viewport: ' + vw + 'px × ' + vh + 'px');
    console.log('Body scroll width: ' + body.scrollWidth + 'px');
    console.log('Horizontal overflow: ' + (hasHorizontalScroll ? '⚠️ YES' : '✅ NO'));
    console.log('');

    console.log('%cContainer Widths:', 'font-weight: bold');
    console.log('  Header: ' + (header ? header.offsetWidth : 'N/A') + 'px');
    console.log('  Filter bar: ' + (filterBar ? filterBar.offsetWidth : 'N/A') + 'px');
    console.log('  Filter inner: ' + (filterInner ? filterInner.offsetWidth : 'N/A') + 'px (max: 1272px)');
    console.log('  Portfolio section: ' + (portfolioSection ? portfolioSection.offsetWidth : 'N/A') + 'px');
    console.log('  Stats grid: ' + (statsGrid ? statsGrid.offsetWidth : 'N/A') + 'px (max: 1400px)');
    console.log('  Tabs container: ' + (tabsContainer ? tabsContainer.offsetWidth : 'N/A') + 'px');
    console.log('');

    if (portfolioHeaderCells.length > 0) {{
        console.log('%cPortfolio Grid Columns (8 cols):', 'font-weight: bold');
        var colWidths = Array.from(portfolioHeaderCells).map(function(cell) {{
            var w = cell.offsetWidth;
            var cramped = w < 80 ? '⚠️' : '';
            return w + 'px' + cramped;
        }});
        console.log('  ' + colWidths.join(' | '));
        var total = Array.from(portfolioHeaderCells).reduce(function(sum, c) {{ return sum + c.offsetWidth; }}, 0);
        console.log('  Total: ' + total + 'px');
    }}
    console.log('');

    if (citiesHeaderCells.length > 0) {{
        console.log('%cCities Grid Columns (9 cols):', 'font-weight: bold');
        var cityColWidths = Array.from(citiesHeaderCells).map(function(cell) {{
            var w = cell.offsetWidth;
            var cramped = w < 60 ? '⚠️' : '';
            return w + 'px' + cramped;
        }});
        console.log('  ' + cityColWidths.join(' | '));
        var cityTotal = Array.from(citiesHeaderCells).reduce(function(sum, c) {{ return sum + c.offsetWidth; }}, 0);
        console.log('  Total: ' + cityTotal + 'px');
    }}
    console.log('');

    console.log('%cBreakpoint Status:', 'font-weight: bold');
    console.log('  > 1400px (full desktop): ' + (vw > 1400 ? '✅ ACTIVE' : '—'));
    console.log('  1200-1400px: ' + (vw <= 1400 && vw > 1200 ? '✅ ACTIVE' : '—'));
    console.log('  1024-1200px: ' + (vw <= 1200 && vw > 1024 ? '⚠️ NO BREAKPOINT' : '—'));
    console.log('  768-1024px: ' + (vw <= 1024 && vw > 768 ? '⚠️ NO BREAKPOINT' : '—'));
    console.log('  < 768px: ' + (vw <= 768 ? '⚠️ ACTIVE (limited)' : '—'));
    console.log('');

    console.log('%cRecommendations:', 'font-weight: bold; color: #cc6600');
    if (vw < 1024 && vw > 768) {{
        console.log('  → Portfolio grid needs 5-6 columns at this width');
        console.log('  → Cities grid needs 5-6 columns at this width');
    }} else if (vw <= 768) {{
        console.log('  → Portfolio grid needs 3-4 columns at this width');
        console.log('  → Cities grid needs 3-4 columns at this width');
    }} else if (vw >= 1024 && vw <= 1200) {{
        console.log('  → Consider reducing to 6-7 columns');
    }} else {{
        console.log('  → Current layout should be fine');
    }}
}}

// Debug diagnostics - call logResponsiveDiagnostics() manually in console if needed
// logResponsiveDiagnostics();
// window.addEventListener('resize', logResponsiveDiagnostics);
</script>'''


# =============================================================================
# TEST
# =============================================================================

if __name__ == '__main__':
    # Quick test with mock data
    from src.data.loader import load_all_data

    config = {
        'aws_bucket': 'https://nationwide-odcv-images.s3.us-east-2.amazonaws.com',
        'mapbox_token': 'pk.eyJ1IjoiZm1pbGxlcnJ6ZXJvIiwiYSI6ImNtY2NnZGl6dTAxMzkya29qeHl6c2tibDgifQ.8h1GAYRfrv-fldoXorqFlw',
        'google_api_key': 'AIzaSyDvGee7gI4jQO3OjGXhtkMmWRP865F2kAU',
        'firebase_config': {
            'apiKey': 'AIzaSyDJlvljO528jQV30jUofDYLqWo9zSY46JY',
            'authDomain': 'nyc-odcv-prospector.firebaseapp.com',
            'projectId': 'nyc-odcv-prospector',
            'storageBucket': 'nyc-odcv-prospector.appspot.com',
            'messagingSenderId': '847399012345',
            'appId': '1:847399012345:web:abcd1234'
        }
    }

    data = load_all_data()
    generator = NationwideHTMLGenerator(config, data)
    html, data_files = generator.generate()

    # Save the HTML file using config paths
    from src.config import HTML_OUTPUT_DIR, DATA_OUTPUT_DIR, PORTFOLIOS_OUTPUT_DIR
    output_dir = str(HTML_OUTPUT_DIR)
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, 'index.html')
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    # Save data files using config paths
    data_dir = str(DATA_OUTPUT_DIR)
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(str(PORTFOLIOS_OUTPUT_DIR), exist_ok=True)
    for filename, content in data_files.items():
        filepath = os.path.join(data_dir, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Saved {filename}: {os.path.getsize(filepath) / 1024:.1f} KB")

    print(f"Generated {len(html):,} characters of HTML")
    print(f"Saved to: {output_path}")
    print(f"File size: {os.path.getsize(output_path) / 1024:.1f} KB")
    print(f"Portfolios: {len(data['portfolios'])}")
    print(f"Buildings: {len(data['all_buildings'])}")
